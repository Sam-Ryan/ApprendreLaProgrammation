Pour terminer, nous allons ajouter un système de sauvegarde/restauration à notre programme.

Durant une partie, un utilisateur doit pouvoir demander à sauvegarder le jeu courant ou de charger une ancienne partie en lieu et place d’entrer un numéro de colonne.

À vous de voir comment organiser les données au sein d’un fichier et comment les récupérés depuis votre programme. ;)