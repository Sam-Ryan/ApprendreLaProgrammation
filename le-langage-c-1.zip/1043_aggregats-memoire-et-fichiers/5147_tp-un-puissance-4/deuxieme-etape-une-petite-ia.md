# Introduction

Dans cette seconde partie, votre objectif va être de construire une petite intelligence artificielle. Votre programme va donc devoir demander si un ou deux joueurs sont présents et jouer à la place du second joueur s’il n’y en a qu’un seul.

Afin de vous aider dans la réalisation de cette tâche, nous allons vous présenter un algorithme simple que vous pourrez mettre en œuvre. Le principe est le suivant : pour chaque emplacement possible (il y en aura toujours au maximum sept), nous allons calculer combien de pièces composeraient la ligne si nous jouions à cet endroit *sans tenir compte de notre couleur* (autrement dit, le jeton que nous jouons est considéré comme étant des *deux* couleurs). Si une valeur est plus élevée que les autres, l’emplacement correspondant sera choisi. Si en revanche il y a plusieurs nombres égaux, une des cases sera choisie « au hasard » (nous y reviendrons).

Cet algorithme connait toutefois une exception : s’il s’avère lors de l’analyse qu’un coup permet à l’ordinateur de gagner, alors le traitement s’arrêtera là et le mouvement est immédiatement joué.

Par exemple, dans la grille ci-dessous, il est possible de jouer à sept endroits (indiqués à l’aide d’un point d’interrogation).

```text
  1   2   3   4   5   6   7  
+---+---+---+---+---+---+---+
|   |   |   | ? |   |   |   |
+---+---+---+---+---+---+---+
|   |   |   | O | ? |   |   |
+---+---+---+---+---+---+---+
|   |   |   | O | X | ? |   |
+---+---+---+---+---+---+---+
|   |   |   | O | O | X |   |
+---+---+---+---+---+---+---+
|   | ? | ? | X | O | O | ? |
+---+---+---+---+---+---+---+
| ? | X | O | O | X | X | X |
+---+---+---+---+---+---+---+
  1   2   3   4   5   6   7  
```

Si nous appliquons l’algorithme que nous venons de décrire, nous obtenons les valeurs suivantes.

```text
  1   2   3   4   5   6   7  
+---+---+---+---+---+---+---+
|   |   |   | 4 |   |   |   |
+---+---+---+---+---+---+---+
|   |   |   | O | 2 |   |   |
+---+---+---+---+---+---+---+
|   |   |   | O | X | 2 |   |
+---+---+---+---+---+---+---+
|   |   |   | O | O | X |   |
+---+---+---+---+---+---+---+
|   | 2 | 2 | X | O | O | 3 |
+---+---+---+---+---+---+---+
| 2 | X | O | O | X | X | X |
+---+---+---+---+---+---+---+
  1   2   3   4   5   6   7  
```

Le programme jouera donc dans la colonne quatre, cette dernière ayant la valeur la plus élevée (ce qui tombe bien puisque l’autre joueur gagnerait si l’ordinateur jouait ailleurs :p ).

[[information]]
| Pour effectuer le calcul, vous pouvez vous aider des fonctions `long_colonne()`, `long_ligne()` et `long_oblique()` de la correction précédente.

# Tirage au sort

Nous vous avons dit que si l’ordinateur doit choisir entre des valeurs identiques, ce dernier devrait en choisir une « au hasard ». Cependant, un ordinateur est en vérité incapable d’effectuer cette tâche (c’est pour cela que nous employons des guillemets). Pour y remédier, il existe des algorithmes qui permettent de produire des suites de nombres dits *pseudo-aléatoires*, c’est-à-dire qui s’approchent de suites aléatoires sur le plan statistique.

La plupart de ceux-ci fonctionnent à partir d’une *graine*, c’est-à-dire un nombre de départ qui va déterminer tout le reste de la suite. C’est ce système qui a été choisi par la bibliothèque standard du C. Deux fonctions vous sont dès lors proposées : `srand()` et `rand()` (elles sont déclarées dans l’en-tête `<stdlib.h>`).

```c
void srand(unsigned int seed);
int rand(void);
```

La fonction `srand()` est utilisée pour initaliser la génération de nombres à l’aide de la graine fournie en argument (un entier non signé en l’espèce). Le plus souvent vous ne l’appellerez qu’une seule fois au début de votre programme sauf si vous souhaitez réinitialiser la génération de nombres.

La fonction `rand()` retourne un nombre pseudo-aléatoire compris entre zéro et `RAND_MAX` (qui est une constante également définie dans l’en-tête `<stdlib.h>`) suivant la graine fournie à la fonction `srand()`.

Toutefois, il y a un petit bémol : étant donné que l’algorithme de génération se base sur la graine fournie pour construire la suite de nombres, une même graine donnera *toujours la même suite* ! Dès lors, comment faire pour que les nombres générés ne soient pas identiques entre deux exécutions du programme ? Pour que cela soit possible, nous devrions fournir un nombre différent à `srand()` à chaque fois, mais comment obtenir un tel nombre ? 

C’est ici que la fonction `time()` (déclarée dans l’en-tête `<time.h>`) entre en jeu.

```c
time_t time(time_t *t);
```

La fonction `time()` retourne la date actuelle sous forme d’une valeur de type `time_t` (qui est un nombre entier ou flottant). Le plus souvent, il s’agit du nombre de secondes écoulé depuis une date fixée arbitrairement appelée [Epoch](https://fr.wikipedia.org/wiki/Epoch) en anglais. Cette valeur peut également être stockée dans une variable de type `time_t` dont l’adresse lui est fournie en argument (un pointeur nul peut lui être envoyé si cela n’est pas nécessaire). En cas d’erreur, la fonction retourne la valeur `-1` convertie vers le type `time_t`.

Pour obtenir des nombres différents à chaque exécution, nous pouvons donc appelé `srand()` avec le retour de la fonction `time()` converti en entier non signé. L’exemple suivant génère donc une suite de trois nombres pseudo-aléatoires différents à chaque exécution (en vérité à chaque exécution espacée d’une seconde).

```c
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int main(void)
{
    time_t t;

    if (time(&t) == (time_t)-1)
    {
        fprintf(stderr, "Impossible d'obtenir la date courante\n");
        return EXIT_FAILURE;
    }

    srand((unsigned)t);
    printf("1 : %d\n", rand());
    printf("2 : %d\n", rand());
    printf("3 : %d\n", rand());
    return 0;
}
```

## Tirer un nombre dans un intervalle donné

Il est possible de générer des nombres dans un intervalle précis en procédant en deux temps. Tout d'abord, il nous est nécessaire d'obtenir un nombre compris entre zéro inclus et un exclus. Pour ce faire, nous pouvons diviser le nombre pseudo-aléatoire obtenu par la plus grande valeur qui peut être retournée par la fonction `rand()` augmentée de un. Celle-ci nous est fournie via la macroconstante `RAND_MAX` qui est définie dans l'en-tête `<stdlib.h>`.

```c
double nb_aleatoire(void)
{
    return rand() / (RAND_MAX + 1.);
}
```

Notez que nous avons bien indiqué que la constante `1.` est un nombre flottant afin que le résultat de l'opération soit de type `double`.

Ensuite, il nous suffit de multiplier le nombre obtenu par la différence entre le maximum et le minimum augmenté de un et d'y ajouter le minimum.

```c
int nb_aleatoire_entre(int min, int max)
{
    return nb_aleatoire() * (max - min + 1) + min;
}
```

Afin d'illustrer ce qui vient d'être dit, le code suivant affiche trois nombres pseudo-aléatoires compris entre zéro et dix inclus.

```c
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


static double nb_aleatoire(void)
{
    return rand() / (RAND_MAX + 1.);
}


static int nb_aleatoire_entre(int min, int max)
{
    return nb_aleatoire() * (max - min + 1) + min;
}


int main(void)
{
    time_t t;

    if (time(&t) == (time_t)-1)
    {
        fprintf(stderr, "Impossible d'obtenir la date courante\n");
        return EXIT_FAILURE;
    }

    srand((unsigned)t);
    printf("1 : %d\n", nb_aleatoire_entre(0, 10));
    printf("2 : %d\n", nb_aleatoire_entre(0, 10));
    printf("3 : %d\n", nb_aleatoire_entre(0, 10));
    return 0;
}
```

À présent, c’est à vous ! :)