Dans cette première partie, vous allez devoir réaliser un « Puissance 4 » pour deux joueurs *humains*. Le programme final devra ressembler à ceci.

```text
  1   2   3   4   5   6   7  
+---+---+---+---+---+---+---+
|   |   |   |   |   |   |   |
+---+---+---+---+---+---+---+
|   |   |   |   |   |   |   |
+---+---+---+---+---+---+---+
|   |   |   |   |   |   |   |
+---+---+---+---+---+---+---+
|   |   |   |   |   |   |   |
+---+---+---+---+---+---+---+
|   |   |   |   |   |   |   |
+---+---+---+---+---+---+---+
|   |   |   |   |   |   |   |
+---+---+---+---+---+---+---+
  1   2   3   4   5   6   7  

Joueur 1 : 1

  1   2   3   4   5   6   7  
+---+---+---+---+---+---+---+
|   |   |   |   |   |   |   |
+---+---+---+---+---+---+---+
|   |   |   |   |   |   |   |
+---+---+---+---+---+---+---+
|   |   |   |   |   |   |   |
+---+---+---+---+---+---+---+
|   |   |   |   |   |   |   |
+---+---+---+---+---+---+---+
|   |   |   |   |   |   |   |
+---+---+---+---+---+---+---+
| O |   |   |   |   |   |   |
+---+---+---+---+---+---+---+
  1   2   3   4   5   6   7  

Joueur 2 : 7

  1   2   3   4   5   6   7  
+---+---+---+---+---+---+---+
|   |   |   |   |   |   |   |
+---+---+---+---+---+---+---+
|   |   |   |   |   |   |   |
+---+---+---+---+---+---+---+
|   |   |   |   |   |   |   |
+---+---+---+---+---+---+---+
|   |   |   |   |   |   |   |
+---+---+---+---+---+---+---+
|   |   |   |   |   |   |   |
+---+---+---+---+---+---+---+
| O |   |   |   |   |   | X |
+---+---+---+---+---+---+---+
  1   2   3   4   5   6   7  

Joueur 1 :
```

Pour ceux qui ne connaissent pas le jeu Puissance 4, ce dernier se joue à l’aide d’une grille verticale de sept colonnes sur six lignes. Chaque joueur dispose de vingt et un jetons d’une couleur (le plus souvent, rouge et jaune traduit dans notre exemple par les caractères « O » et « X ») et place ceux-ci au sein de la grille à tour de rôle.

Pour gagner le jeu, un joueur doit aligner quatre jetons verticalement, horizontalement ou en oblique. Il s’agit donc du même principe que le Morpion à une différence prêt : la grille est *verticale* ce qui signifie que les jetons tombent au fond de la colonne choisie par le joueur. Pour plus de détails, je vous renvoie à [l’article dédié sur Wikipédia](https://fr.wikipedia.org/wiki/Puissance_4).

Maintenant que vous savez cela, il est temps de passer à la réalisation de celui-ci.  
Bon travail ! ;)