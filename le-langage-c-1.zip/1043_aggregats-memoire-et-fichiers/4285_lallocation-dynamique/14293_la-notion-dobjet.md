Jusqu’à présent, nous avons toujours recouru au système de types et de variables du langage C pour stocker nos données sans jamais vraiment nous soucier de ce qui se passait « en-dessous ». Il est à présent temps de lever une partie de ce voile en abordant la notion d’**objet**.

En C, un objet est une zone mémoire pouvant contenir des données et est composé d’une suite contiguë d’un ou plusieurs multiplets. En fait, tous les types du langage C manipulent des objets. La différence entre les types tient simplement en la manière dont ils répartissent les données au sein de ces objets, ce qui est appelé leur **représentation** (celle-ci sera abordée dans la troisième partie du cours). Ainsi, la valeur 1 n’est pas représentée de la même manière dans un objet de type `int` que dans un objet de type `double`.

Un objet étant une suite contiguë de multiplets, il est possible d’en examiner le contenu en lisant ses multiplets un à un. Ceci peut se réaliser en C à l’aide de l’adresse de l’objet et d’un pointeur sur `unsigned char`, le type `char` du C ayant *toujours* la taille d’un multiplet. Notez qu’il est *impératif* d’utiliser la version non signée du type `char` afin d’éviter des problèmes de conversions.

L’exemple ci-dessous affiche les multiplets composant un objet de type `int` et un objet de type `double` en hexadécimal.

```c
#include <stdio.h>


int main(void)
{
    int n = 1;
    double f = 1.;
    unsigned char *byte;
    unsigned i;

    byte = (unsigned char *)&n;

    for (i = 0; i < sizeof n; ++i)
        printf("%x ", byte[i]);

    printf("\n");
    byte = (unsigned char *)&f;

    for (i = 0; i < sizeof f; ++i)
        printf("%x ", byte[i]);

    printf("\n");
    return 0;
}
```

```text
1 0 0 0 
0 0 0 0 0 0 f0 3f 
```

[[information]]
| Il se peut que vous n’obteniez pas le même résultat que nous, ce dernier dépends de votre machine.

Comme vous le voyez, la représentation de la valeur 1 n’est pas du tout la même entre le type `int` et le type `double`.