L’allocation de tableaux multidimensionnels est un petit peu plus complexe que celles des autres objets. Techniquement, il existe deux solutions : l’allocation d’un seul bloc de mémoire (comme pour les tableaux simples) et l’allocation de plusieurs tableaux eux-mêmes référencés par les éléments d’un autre tableau.

# Allocation en un bloc

Comme pour un tableau simple, il vous est possible d’allouer un bloc de mémoire dont la taille correspond à la multiplication des longueurs de chaque dimension, elle-même multipliée par la taille d’un élément. Toutefois, cette solution vous contraint à effectuer une partie du calcul d’adresse vous-même puisque vous allouez en fait un seul tableau.

L’exemple ci-dessous illustre ce qui vient d’être dit en allouant un tableau à deux dimensions de trois fois trois `int`.

```c
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    int *p;
    unsigned i;
    unsigned j;

    p = malloc(3 * 3 * sizeof(int));

    if (p == NULL)
    {
        printf("Échec de l'allocation\n");
        return EXIT_FAILURE;
    }

    for (i = 0; i < 3; ++i)
        for (j = 0; j < 3; ++j)
        {
            p[(i * 3) + j] = (i * 3) + j;
            printf("p[%u][%u] = %d\n", i, j, p[(i * 3) + j]);
        }

    free(p);
    return 0;
}
```

```text
p[0][0] = 0
p[0][1] = 1
p[0][2] = 2
p[1][0] = 3
p[1][1] = 4
p[1][2] = 5
p[2][0] = 6
p[2][1] = 7
p[2][2] = 8
```

Comme vous le voyez, une partie du calcul d’adresse doit être effectué en multipliant le premièr indice par la longueur de la première dimension, ce qui permet d’arriver à la bonne « ligne ». Ensuite, il ne reste plus qu’à sélectionner le bon élément de la ligne à l’aide du second indice.

Bien qu’un petit peu plus complexe quant à l’accès aux éléments, cette solution à l’avantage de n’effectuer qu’une seule allocation de mémoire.

# Allocation de plusieurs tableaux

La seconde solution consiste à allouer plusieurs tableaux plus un autre qui les référencera. Dans le cas d’un tableau à deux dimensions, cela signifie allouer un tableau de pointeurs dont chaque élément se verra affecter l’adresse d’un tableau également alloué dynamiquement. Cette technique nous permet d’accéder aux éléments des différents tableaux de la même manière que pour un tableau multidimensionnel puisque nous utilisons cette fois plusieurs tableaux.

L’exemple ci-dessous revient au même que le précédent, mais utilise le procédé qui vient d’être décrit. Notez que puisque nous réservons un tableau de pointeurs sur `int`, l’adresse de celui-ci doit être stockée dans un pointeur de pointeur sur `int` (rappelez-vous la règle générale lors de la présentation de la fonction `malloc()`).

```c
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    int **p;
    unsigned i;
    unsigned j;

    p = malloc(3 * sizeof(int *));

    if (p == NULL)
    {
        printf("Échec de l'allocation\n");
        return EXIT_FAILURE;
    }

    for (i = 0; i < 3; ++i)
    {
        p[i] = malloc(3 * sizeof(int));

        if (p[i] == NULL)
        {
            printf("Échec de l'allocation\n");
            return EXIT_FAILURE;
        }
    }

    for (i = 0; i < 3; ++i)
        for (j = 0; j < 3; ++j)
        {
            p[i][j] = (i * 3) + j;
            printf("p[%u][%u] = %d\n", i, j, p[i][j]);
        }

    for (i = 0; i < 3; ++i)
        free(p[i]);

    free(p);
    return 0;
}
```

Si cette solution permet de faciliter l’accès aux différents éléments, elle présente toutefois l’inconvénient de réaliser plusieurs allocations et donc de nécessiter plusieurs appels à la fonction `free()`.