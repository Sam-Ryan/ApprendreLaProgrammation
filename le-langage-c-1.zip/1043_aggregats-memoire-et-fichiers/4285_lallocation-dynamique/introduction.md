Il est à présent temps d’aborder la troisième et dernière utilisation majeure des pointeurs : l’allocation dynamique de mémoire.

Comme nous vous l’avons dit dans le chapitre sur les pointeurs, il n’est pas toujours possible de savoir quelle quantité de mémoire sera utilisée par un programme. Par exemple, si vous demandez à l’utilisateur de vous fournir un tableau, vous devrez lui fixer une limite, ce qui pose deux problèmes :

* la limite en elle-même, qui ne convient peut-être pas à votre utilisateur ;
* l’utilisation excessive de mémoire du fait que vous réservez un tableau d’une taille fixée à l’avance.

De plus, si vous utilisez un tableau de classe de stockage statique, alors cette quantitée de mémoire superflue sera inutilisable jusqu’à la fin de votre programme.

Or, un ordinateur ne dispose que d’une quantité limitée de mémoire vive, il est donc important de ne pas en réserver abusivement. L’allocation dynamique permet de réserver une partie de la mémoire vive inutilisée pour stocker des données et de libérer cette même partie une fois qu’elle n’est plus nécessaire.