La bibliothèque standard fourni trois fonctions vous permettant d’allouer de la mémoire : `malloc()`, `calloc()` et `realloc()` et une vous permettant de la libérer : `free()`. Ces quatres fonctions sont déclarées dans l’en-tête `<stdlib.h>`.

# malloc

```c
void *malloc(size_t taille);
```

La fonction `malloc()` vous permet d’allouer un objet de la taille fournie en argument (qui représente un nombre de multiplets) et retourne l’adresse de cet objet sous la forme d’un pointeur générique. En cas d’échec de l’allocation, elle retourne un pointeur nul.

[[attention]]
| Vous devez *toujours* vérifier le retour d’une fonction d’allocation afin de vous assurer que vous manipulez bien un pointeur valide.

## Allocation d’un objet

Dans l’exemple ci-dessous, nous réservons un objet de la taille d’un `int`, nous y stockons ensuite la valeur dix et l’affichons. Pour cela, nous utilisons un pointeur sur `int` qui va se voir affecter l’adresse de l’objet ainsi alloué et qui va nous permettre de le manipuler comme nous le ferions s’il référençait une variable de type `int`.

```c
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    int *p;

    p = malloc(sizeof(int));

    if (p == NULL)
    {
        printf("Échec de l'allocation\n");
        return EXIT_FAILURE;
    }

    *p = 10;
    printf("%d\n", *p);
    return 0;
}
```

```text
10
```

## Allocation d’un tableau

Pour allouer un tableau, vous devez réserver un bloc mémoire de la taille d’un élément multiplié par le nombre d’éléments composant le tableau. L’exemple suivant alloue un tableau de dix `int`, l’initialise et affiche son contenu.

```c
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    int *p;
    unsigned i;

    p = malloc(sizeof(int) * 10);

    if (p == NULL)
    {
        printf("Échec de l'allocation\n");
        return EXIT_FAILURE;
    }

    for (i = 0; i < 10; ++i)
    {
        p[i] = i * 10;
        printf("p[%u] = %d\n", i, p[i]);
    }

    return 0;
}
```

```text
p[0] = 0
p[1] = 10
p[2] = 20
p[3] = 30
p[4] = 40
p[5] = 50
p[6] = 60
p[7] = 70
p[8] = 80
p[9] = 90
```

[[information]]
| Autrement dit et de manière plus générale : pour allouer dynamiquement un objet de type **T**, il vous faut créer un pointeur sur le type **T** qui conservera son adresse.

[[erreur]]
| La fonction `malloc()` n’effectue *aucune* initialisation, le contenu du bloc alloué est donc indéterminé.

# free

```c
void free(void *ptr);
```

La fonction `free()` libère le bloc précédemment alloué par une fonction d’allocation dont l’adresse est fournie en argument. Dans le cas où un pointeur nul lui est fourni, elle n’effectue aucune opération.

[[attention]]
| Retenez bien la règle suivante : à chaque appel à une fonction d’allocation doit correspondre un appel à la fonction `free()`.

Dès lors, nous pouvons compléter les exemples précédents comme suit.

```c hl_lines="19"
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    int *p;

    p = malloc(sizeof(int));

    if (p == NULL)
    {
        printf("Échec de l'allocation\n");
        return EXIT_FAILURE;
    }

    *p = 10;
    printf("%d\n", *p);
    free(p);
    return 0;
}
```

```c hl_lines="24"
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    int *p;
    unsigned i;

    p = malloc(sizeof(int) * 10);

    if (p == NULL)
    {
        printf("Échec de l'allocation\n");
        return EXIT_FAILURE;
    }

    for (i = 0; i < 10; ++i)
    {
        p[i] = i * 10;
        printf("p[%u] = %d\n", i, p[i]);
    }

    free(p);
    return 0;
}
```

[[information]]
| Remarquez que même si le deuxième exemple alloue un tableau, il n’y a bien eu qu’*une seule* allocation. Un seul appel à la fonction `free()` est donc nécessaire.

# calloc

```c
void *calloc(size_t nombre, size_t taille);
```

La fonction `calloc()` attends deux arguments : le nombre d’éléments à allouer et la taille de chacun de ces éléments. Techniquement, elle revient au même que d’appelé `malloc()` comme suit.

```c
malloc(nombre * taille);
```

à un détail près : *le bloc de mémoire ainsi alloué est initialisé à zéro*.

[[erreur]]
| Faites attention : cette initialisation n’est pas similaire à celle des variables de classe de stockage statique ! À l’inverse de ces dernières qui seront soit initialisées à zéro, soit seront des pointeurs nuls, l’initialisation réalisée par la fonction `calloc()` ne s’applique qu’aux entiers ou aux chaînes de caractères (nous verrons cela plus en détails dans la troisième partie du cours).

# realloc

```c
void *realloc(void *p, size_t taille);
```

La fonction `realloc()` libère un bloc de mémoire précédemment alloué, en réserve un nouveau de la taille demandée et copie le contenu de l’ancien objet dans le nouveau. Dans le cas où la taille demandée est inférieure à celle du bloc d’origine, le contenu de celui-ci sera copié à hauteur de la nouvelle taille. À l’inverse, si la nouvelle taille est supérieure à l’ancienne, l’excédant n’est pas initialisé.

La fonction attends deux arguments : l’adresse d’un bloc précédemment alloué à l’aide d’une fonction d’allocation et la taille du nouveau bloc à allouer. Elle retourne l’adresse du nouveau bloc ou un pointeur nul en cas d’erreur.

L’exemple ci-dessous alloue un tableau de dix `int` et utilise `realloc()` pour agrandir celui-ci à vingt `int`.

```c
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    int *p;
    int *tmp;
    unsigned i;

    p = malloc(sizeof(int) * 10);

    if (p == NULL)
    {
        printf("Échec de l'allocation\n");
        return EXIT_FAILURE;
    }

    for (i = 0; i < 10; ++i)
        p[i] = i * 10;

    tmp = realloc(p, sizeof(int) * 20);

    if (tmp == NULL)
    {
        printf("Échec de l'allocation\n");
        return EXIT_FAILURE;
    }
    
    p = tmp;

    for (i = 10; i < 20; ++i)
        p[i] = i * 10;

    for (i = 0; i < 20; ++i)
        printf("p[%u] = %d\n", i, p[i]);
  
    free(p);
    return 0;
}
```

```text
p[0] = 0
p[1] = 10
p[2] = 20
p[3] = 30
p[4] = 40
p[5] = 50
p[6] = 60
p[7] = 70
p[8] = 80
p[9] = 90
p[10] = 100
p[11] = 110
p[12] = 120
p[13] = 130
p[14] = 140
p[15] = 150
p[16] = 160
p[17] = 170
p[18] = 180
p[19] = 190
```

Remarquez que nous avons utilisé une autre variable, `tmp`, pour vérifier le retour de la fonction `realloc()`. En effet, si nous avions procéder comme ceci.

```c
p = realloc(p, sizeof(int) * 20);
```

il nous aurait été impossible de libérer le bloc mémoire référencé par `p` en cas d’erreur puisque celui-ci serait devenu un pointeur nul. Il est donc *impératif* d’utiliser une seconde variable afin d’éviter des [fuites de mémoire](http://fr.wikipedia.org/wiki/Fuite_de_mémoire).