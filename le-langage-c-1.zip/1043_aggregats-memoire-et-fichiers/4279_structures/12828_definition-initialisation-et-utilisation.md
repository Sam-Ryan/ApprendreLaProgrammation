# Définition d’une structure

Une structure étant un regroupement d’objets, la première chose à réaliser est la description de celle-ci (techniquement, sa **définition**), c’est-à-dire préciser de quel(s) objet(s) cette dernière va se composer.

La syntaxe de toute définition est la suivante.

```c
struct étiquette
{
    /* Objet(s) composant(s) la structure. */
};
```

Prenons un exemple concret : vous souhaitez demander à l’utilisateur deux mesures de temps sous la forme heure(s):minute(s):seconde(s).milliseconde(s) et lui donner la différence entre les deux en seconde. Vous pourriez utiliser six variables pour stocker ce que vous fourni l’utilisateur, toutefois cela reste assez lourd. À la place, nous pourrions représenter chaque mesure à l’aide d’une structure composée de trois objets : un pour les heures, un pour les minutes et un pour les secondes.

```c
struct temps {
    unsigned heures;
    unsigned minutes;
    double secondes;
};
```

Comme vous le voyez, nous avons donner un nom (plus précisémment, une **étiquette**) à notre structure : « temps ». Les règles à respecter sont les même que pour les noms de variable et de fonction.

Pour le reste, la composition de la structure est décrite à l’aide d’une suite de déclarations de variable. Ces différentes déclarations constituent les **membres** ou **champs** de la structure. Notez bien qu’il s’agit de *déclarations* et non de définitions, l’utilisation d’initialisations est donc exclue. 

Enfin, notez la présence d’un point-virgule *obligatoire* à la fin de la définition de la structure.

[[information]]
| Une structure ne peut pas comporter plus de cent vingt-sept membres.

# Définition d’une variable de type structure

Une fois notre structure décrite, il ne nous reste plus qu’à créer une variable de ce type. Pour ce faire, la syntaxe est la suivante.

```c
struct étiquette identificateur;
```

La méthode est donc la même que pour définir n’importe quelle variable, si ce n’est que le type de la variable est précisé à l’aide du mot-clé `struct` et de l’étiquette de la structure. Avec notre exemple de la structure `temps`, cela donne ceci.

```c
#include <stdio.h>

struct temps {
    unsigned heures;
    unsigned minutes;
    double secondes;
};


int main(void)
{
    struct temps t;

    return 0;
}
```

# Initialisation

Comme pour n’importe quelle autre variable, il est possible d’initialiser une variable de type structure dès sa définition. Toutefois, à l’inverse des autres, l’initialisation s’effectue à l’aide d’une liste fournissant une valeur pour chaque membre de la structure.

L’exemple ci-dessous initialise le membre `heures` à 1, `minutes` à 45 et `secondes` à 30.560.

```c
struct temps t = { 1, 45, 30.560 };
```

[[attention]]
| Dans le cas où vous ne fournissez pas un nombre suffisant de valeurs, les membres oubliés seront initialisés à zéro ou, s’il s’agit de pointeurs, seront des pointeurs nuls.

# Accès à un membre

L’accès à un membre d’une structure se réalise à l’aide de la variable de type structure et de l’opérateur `.` suivi du nom du champ visé.

```c
variable.membre
```

Cette syntaxe peut être utilisée aussi bien pour obtenir la valeur d’un champ que pour en modifier le contenu. L’exemple suivant effectue donc la même action que l’initialisation présentée précédemment.

```c
t.heures = 1;
t.minutes = 45;
t.secondes = 30.560;
```

# Exercice

Afin d’assimiler tout ceci, voici un petit exercice.  
Essayez de réaliser ce qui a été décrit plus haut : demandez à l’utilisateur de vous fournir deux mesures de temps sous la forme heure(s):minute(s):seconde(s).milliseconde(s) et donnez lui la différence en seconde entre celles-ci.

Voici un exemple d’utilisation.

```text
Première mesure (hh:mm:ss.xxx) : 12:45:50.640
Deuxième mesure (hh:mm:ss.xxx) : 13:30:35.480
Il y 2684.840 seconde(s) de différence.
```

## Correction

[[secret]]
|```c
| #include <stdio.h>
| #include <stdlib.h>
| 
| struct temps {
|     unsigned heures;
|     unsigned minutes;
|     double secondes;
| };
| 
| 
| int main(void)
| {
|     struct temps t1;
|     struct temps t2;
| 
|     printf("Première mesure (hh:mm:ss) : ");
|
|     if (scanf("%u:%u:%lf", &t1.heures, &t1.minutes, &t1.secondes) != 3)
|     {
|         printf("Mauvaise saisie\n");
|         return EXIT_FAILURE;
|     }
|
|     printf("Deuxième mesure (hh:mm:ss) : ");
|
|     if (scanf("%u:%u:%lf", &t2.heures, &t2.minutes, &t2.secondes) != 3)
|     {
|         printf("Mauvaise saisie\n");
|         return EXIT_FAILURE;
|     }
| 
|     t1.minutes += t1.heures * 60;
|     t1.secondes += t1.minutes * 60;
|     t2.minutes += t2.heures * 60;
|     t2.secondes += t2.minutes * 60;
| 
|     printf("Il y a %.3f seconde(s) de différence.\n",
|     t2.secondes - t1.secondes);
|     return 0;
| }
|```