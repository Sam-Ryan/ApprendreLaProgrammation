[[question]]
| Savez-vous comment sont représentées les structures en mémoire ? 

Les membres d’une structure sont placés les uns après les autres en mémoire. Par exemple, prenons cette structure.

```c
struct exemple
{
    double flottant;
    char lettre;
    unsigned entier;
};
```

Si nous supposons qu’un ```double``` a une taille de huit octets, un ```char``` de  un octet, et un ```unsigned int``` de quatre octets, voici ce que devrait donner cette structure en mémoire.

![Représentation en mémoire de la structure](http://zestedesavoir.com/media/galleries/1501/7b81d3ea-a124-4c6a-86a5-99ca0ce86ca8.png.960x960_q85.png)

[[information]]
| Les adresses spécifiées dans le schéma sont fictives et ne servent qu’à titre d’illustration.

# L’opérateur sizeof

Voyons à présent comment déterminer cela de manière plus précise, en commençant par la taille des types. L’opérateur `sizeof` permet de connaître la taille en multiplets (*bytes* en anglais) de son opérande. Cet opérande peut être soit un type (qui doit alors être entre parenthèses), soit une expression (auquel cas les parenthèses sont facultatives).

Le résultat de cet opérateur est de type `size_t`. Il s’agit d’un type entier *non signé* défini dans l’en-tête `<stddef.h>` qui est capable de contenir la taille de n’importe quel objet. L’exemple ci-dessous utilise l’opérateur `sizeof` pour obtenir la taille des types de bases.

```c
#include <stddef.h>
#include <stdio.h>


int main(void)
{
    double f;

    printf("char: %u\n", (unsigned)sizeof(char));
    printf("short: %u\n", (unsigned)sizeof(short));
    printf("int : %u\n", (unsigned)sizeof(int));
    printf("long : %u\n", (unsigned)sizeof(long));
    printf("float : %u\n", (unsigned)sizeof(float));
    printf("double : %u\n", (unsigned)sizeof(double));
    printf("long double : %u\n", (unsigned)sizeof(long double));

    printf("int : %u\n", (unsigned)sizeof 5);
    printf("double : %u\n", (unsigned)sizeof f);
    return 0;
}
```

```text
char : 1
short : 2
int : 4
long : 8
float : 4
double : 8
long double : 16
int : 4
double : 8
```

[[information]]
| Le type `char` a *toujours* une taille de un multiplet.

Malheureusement pour nous, la fonction `printf()` ne fourni pas d’indicateur de conversion pour le type `size_t`[^indicateur_zu]. Dès lors, nous devons recourir à une conversion explicite afin de pouvoir utiliser un autre indicateur. En l’occurrence, nous avons choisi le type `unsigned int` étant donné que la taille des types de base est très petite et qu’il n’y a en conséquence pas de risque de dépasser sa capacité.

Remarquez que les parenthèses ne sont pas obligatoires dans le cas où l’opérande de l’opérateur `sizeof` est une expression (dans notre exemple : 5 et `f`).

[[information]]
| Il est parfaitement possible que vous n’obteniez pas les même valeurs que nous, celles-ci dépendent de votre machine.

Ceci étant fait, voyons à présent ce que donne la taille de la structure présentée plus haut. En toute logique, elle devrait être égale à la somme des tailles de ses membres, chez nous : 13 (8 + 1 + 4).

```c
#include <stddef.h>
#include <stdio.h>

struct exemple
{
    double flottant;
    char lettre;
    unsigned int entier;
};


int main(void)
{
    printf("struct exemple : %u\n", (unsigned)sizeof(struct exemple));
    return 0;
}
```

```text
struct exemple : 16
```

*Ah* ! Il semble que nous avons loupé quelque chose… :-°

Pourquoi obtenons nous seize et non treize, comme attendu ? Pour répondre à cette question, nous allons devoir plonger un peu dans les entrailles de notre machine.

# Alignement en mémoire

Le processeur et la mémoire vive communiquent entre eux à l’aide d’un canal appelé un **bus mémoire**. Les communications à travers le bus mémoire s’opèrent à l’initiative du processeur qui dispose d’instructions spécifiques pour déplacer des données de la mémoire vers un registre et inversement. Ce canal dispose d’une capacité de transport limitée et ne peut en conséquence transmettre qu’un nombre fixé de multiplets. 

Toutefois, bien que la mémoire vive soit composée de multiplets, le processeur utilise *toujours* la capacité maximale du bus et lit ou écrit dans celle-ci par blocs de la taille du bus. Dès lors, le processeur ne va pas voir la mémoire vive comme une suite de multiplets, mais comme une suite de blocs de la taille du bus qui sont le plus souvent appelés des **mots**.

Quel rapport avec notre structure me direz-vous ? Supposons que notre processeur lise des blocs de quatre octets à la fois. Si notre structure faisait treize octets, voici comment le processeur la verrai.

![Vue de la mémoire par le processeur](http://zestedesavoir.com/media/galleries/1501/12733c0a-38e6-4dac-8030-8c50f9457eb5.png.960x960_q85.png)

Le premier champ est réparti sur plusieurs mots et remplit complètement ces mots. Cette situation ne pose pas de problèmes : soit le processeur charge la donnée en plusieurs fois (ce que la plupart des processeurs savent faire automatiquement), soit le compilateur prévoit plusieurs instructions de chargements.

Par contre, le membre de type `unsigned int` est problématique : vu que sa taille est égale à celle d’un mot, son transfert devrait être réalisé en une seule fois. Toutefois, dans notre exemple, le membre est à califourchon sur deux mots. De ce fait, pour obtenir sa valeur, le processeur devrait : 

* charger le troisième mot et en extraire les bons octets ;
* charger le quatrième mot et en extraire le bon octet ;
* et, enfin, combiner le tout pour obtenir la valeur correcte.

C’est plus lent, sans compter que quelques rares processeurs ne gèrent pas ce genre d’opérations et se contentent de signaler une erreur.

[[question]]
| Mais, comment le processeur sait-il que le dernier champ est à cheval sur deux mots ?

À cause de son adresse. Dans notre exemple, le membre de type `unsigned int` est situé à l’adresse 1017. Étant donné qu’un `unsigned int` a une taille de quatre octets et que le processeur lit des mots de quatre octets, il sait que si une donnée de ce type n’est pas à une adresse multiple de quatre, alors elle est forcément à califourchon sur deux mots.

Pour éviter ces problèmes, les compilateurs ajoutent des multiplets dit « de bourrage » (*padding* en anglais), afin d’**aligner** les données sur les bonnes adresses. Dans le cas de notre structure, le compilateur a ajouté trois octets de bourrage juste après le membre de type `char` afin que le dernier champ soit forcément à une adresse multiple de quatre.

![La structure correctement alignée](http://zestedesavoir.com/media/galleries/1501/c5ed9d79-1d16-480d-a148-dce8e3e8b44c.png.960x960_q85.png)

# La macrofonction offsetof

Il vous est possible de connaître les **contraintes d’alignement** d’un type (c’est-à-dire le nombre dont doivent être multiple les adresses d’un type) à l’aide de la **macrofonction** `offsetof()`[^alignof] qui est définie dans l’en-tête `<stddef.h>` (nous verrons plus tard ce qu’est une macrofonction lorsque nous aborderons le préprocesseur). Cette dernière attends deux arguments : une définition de structure ou un type de structure et le nom d’un membre de celle-ci. Elle retourne le nombre de multiplets qui précède ce champ au sein de la structure. Son retour est de type `size_t`, comme pour l’opérateur `sizeof`.

Étant donné que le type `char` prends un multiplet, si le premier champ d’une structure est de ce type alors le membre suivant sera forcément précédé du nombre de multiplets de bourrage nécessaire pour qu’il soit bien aligné. Ainsi, le code suivant vous donne les contraintes d’alignement pour chaque type de base.

```c
#include <stddef.h>
#include <stdio.h>


int main(void)
{
    printf("short: %u\n", (unsigned)offsetof(struct { char c; short n; }, n));
    printf("int : %u\n", (unsigned)offsetof(struct { char c; int n; }, n));
    printf("long : %u\n", (unsigned)offsetof(struct { char c; long n; }, n));
    printf("float : %u\n", (unsigned)offsetof(struct { char c; float f; }, f));
    printf("double : %u\n", (unsigned)offsetof(struct { char c; double f; }, f));
    printf("long double : %u\n", (unsigned)offsetof(struct { char c; long double f; }, f));
    return 0;
}
```

```text
short: 2
int : 4
long : 8
float : 4
double : 8
long double : 16
```

[[information]]
| Le type `char` ayant une taille de un multiplet, il peut *toujours* être contenu dans un mot. Il n’a donc pas de contraintes d’alignement.

Pour chaque type, nous définissons une structure composée d’un premier membre de type `char` et d’un second membre d’un type dont nous souhaitons connaître les contraintes d’alignement. Cette définition est utilisée comme premier argument de la macrofonction `offsetof()`, le deuxième étant le nom du second membre de la structure. Pour le reste, le nombre retourné étant de type `size_t`, nous opérons à nouveau une conversion vers le type `unsigned int`.

[^indicateur_zu]: Depuis la norme C99, il existe un indicateur de conversion `zu` qui permet d'afficher une expression de type `size_t`.
[^alignof]: La norme C11 a introduit un nouvel opérateur `_Alignof` (et un synonyme `alignof` fournit par l'en-tête `<stdalign.h>`) qui donne les contraintes d'alignement du type de son opérande. Il s'utilise de la même manière que l'opérateur `sizeof` et retourne lui aussi une valeur entière de type `size_t`.