Certains d’entre vous s’en étaient peut-être doutés : s’il existe un objet d’un type, il doit être possible de créer un pointeur vers un objet de ce type. Si oui, sachez que vous aviez raison. :)

```c
struct temps *p;
```

La définition ci-dessus créer un pointeur `p` vers un objet de type `struct temps`.

# Accès via un pointeur

L’utilisation d’un pointeur sur structure est un peu plus complexe que celle d’un pointeur vers un type de base. En effet, il y a deux choses à gérer : l’accès via le pointeur et l’accès à un membre. Intuitivement, vous combineriez sans doute les opérateurs `*` et `.` comme ceci.

```c
*p.heures = 1;
```

Toutefois, cette syntaxe ne correspond pas à ce que nous voulons car l’opérateur `.` s’applique *prioritairement* à l’opérateur `*`. Autrement dit, le code ci-dessus accède au champ `heures` et tente de lui appliquer l’opérateur d’indirection, ce qui est incorrect puisque le membre `heures` est un entier non signé.

Pour résoudre ce problème, nous devons utiliser des parenthèses afin que l’opérateur `.` soit appliqué *après* le déréférencement, ce qui donne la syntaxe suivante.

```c
(*p).heures = 1;
```

Cette écriture étant un peu lourde, le C fourni un autre opérateur qui combine ces deux opérations : l’opérateur `->`.

```c
p->heures = 1;
```

Le code suivant initialise donc la structure `t` via le pointeur `p`.

```c
struct temps t;
struct temps *p = &t;

p->heures = 1;
p->minutes = 45;
p->secondes = 30.560;
```

# Adressage

Il est important de préciser que l’opérateur d’adressage peut s’appliquer aussi bien à une structure qu’à un de ses membres. Ainsi, dans l’exemple ci-dessous, nous définissons un pointeurs `p` pointant sur la structure `t` et un pointeur `q` pointant sur le champ `heures` de la structure `t`.

```c
struct temps t;
struct temps *p = &t;
int *q = &t.heures;
```

# Pointeurs sur structures et fonctions

Indiquons enfin que l’utilisation de pointeurs est particulièrement propice dans le cas du passage de structures à des fonctions. En effet, rappelez-vous, lorsque vous fournissez un argument lors d’un appel de fonction, la valeur de celui-ci est affectée au paramètre correspondant. Cette règle s’applique également aux structures : la valeur de chacun des membres est copiée une à une. Dès lors, si la structure passée en argument comporte beaucoup de champs, la copie risque d’être longue. L’utilisation d’un pointeur évite ce problème puisque seule la valeur du pointeur (autrement dit, l’adresse vers la structure) sera copiée et non toute la structure.