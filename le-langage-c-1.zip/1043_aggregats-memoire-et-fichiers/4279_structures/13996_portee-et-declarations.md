# Portée

Dans les exemples précédents, nous avons toujours placés notre définition de structure en dehors de toute fonction. Cependant, sachez que celle-ci peut être circonscrite à un bloc de sorte de limiter sa **portée**, comme pour les définitions de variables et les déclarations de variables et fonctions.

Dans l’exemple ci-dessous, la structure `temps` ne peut être utilisée que dans le bloc de la fonction `main()` et les éventuels sous-blocs qui la composent.

```c
int main(void)
{
    struct temps {
        unsigned heures;
        unsigned minutes;
        double secondes;
    };

    struct temps t;

    return 0;
}
```

Notez qu’il est possible de combiner une définition de structure et une définition de variable. En effet, une définition de structure n’étant rien d’autre que la définition d’un nouveau type, celle-ci peut être placée là où est attendu un type dans une définition de variable. Avec l’exemple précédent, cela donne ceci.

```c
int main(void)
{
    struct temps {
        unsigned heures;
        unsigned minutes;
        double secondes;
    } t1;
    struct temps t2;

    return 0;
}
```

Il y a trois définitions dans ce code : celle du type `struct temps` , celle de la variable `t1` et celle de la variable `t2`. Après sa définition, le type `struct temps` peut tout à fait être utilisé pour définir d’autres variables de ce type, ce qui est le cas de `t2`.

[[information]]
| Notez qu’il est possible de condenser la définition du type `struct temps` et de la variable `t1` sur une seule ligne, comme ceci.
|
|```c
| struct temps { unsigned heures; unsigned minutes; double secondes; } t1;
|```

S’agissant d’une définition de variable, il est également parfaitement possible de l’initialiser.

```c
int main(void)
{
    struct temps {
        unsigned heures;
        unsigned minutes;
        double secondes;
    } t1 = { 1, 45, 30.560 };
    struct temps t2;

    return 0;
}
```

Enfin, précisions que l’étiquette d’une structure peut être omise lors de sa définition. Néanmoins, cela ne peut avoir lieu que si la définition de la structure est combinée avec une définition de variable. C’est assez logique étant donné qu’il ne peut pas être fait référence à cette définition à l’aide d’une étiquette.

```c
int main(void)
{
    struct {
        unsigned heures;
        unsigned minutes;
        double secondes;
    } t;

    return 0;
}
```

# Déclarations

Jusqu’à présent, nous avons parlé de définitions de structures, toutefois, comme pour les variables et les fonctions, il existe également des déclarations de structures. Une déclaration de structure est en fait une définition sans le corps de la structure.

```c
struct temps;
```

Quel est l’intérêt de la chose me direz-vous ? Résoudre deux types de problèmes : les structures interdépendantes et les structures comportant un ou des membres qui sont des pointeurs vers elle-même.

## Les structures interdépendantes

Deux structures sont interdépendantes lorsque l’une comprend un pointeur vers l’autre et inversément.

```c
struct a {
    struct b *p;
};

struct b {
    struct a *p;
};
```

Voyez-vous le problème ? Si le type `struct b` ne peut être utilisé qu’après sa définition, alors le code ci-dessus est faux et le cas de structures interdépendantes est insoluble. Heureusement, il est possible de **déclarer** le type `struct b` afin de pouvoir l’utiliser *avant* sa définition.

[[erreur]]
| Une déclaration de structure crée un type dit **incomplet** (comme le type `void`). Dès lors, il ne peut pas être utilisé pour définir une variable (puisque les membres qui composent la structure sont inconnus). Ceci n’est utilisable que pour définir des pointeurs.

Le code ci-dessous résoud le « problème » en déclarant le type `struct b` avant son utilisation.

```c
struct b;

struct a {
    struct b *p;
};

struct b {
    struct a *p;
};
```

Nous avons entouré le mot « problème » de guillemets car le premier code que nous vous avons montré n’en pose en fait aucun et compile sans sourciller. :-°

En fait, afin d’éviter ce genre d’écritures, le langage C prévoit l’ajout de **déclarations implicites**. Ainsi, lorsque le compilateur recontre un pointeur vers un type de structure qu’il ne connaît pas, il ajoute implicitement une déclaration de cette structure juste avant. Ainsi, le premier et le deuxième code sont équivalents si ce n’est que le premier comporte une déclaration implicite et non une déclaration explicite.

## Structure qui pointe sur elle-même

Le deuxième cas où les déclarations de structure s’avèrent nécessaires est celui d’une structure qui comporte un pointeur vers elle-même.

```c
struct a {
    struct a *p;
};
```

De nouveau, si le type `struct a` n’est utilisable qu’après sa définition, c’est grillé. Toutefois, comme pour l’exemple précédent, le code est correct, mais pas tout à fait pour les même raisons. Dans ce cas ci, le type `struct a` est connu car nous sommes en train de le définir. Techniquement, dès que la définition commence, le type est déclaré.

[[information]]
| Notez que, comme les définitions, les déclarations (implicites ou non) ont une portée.