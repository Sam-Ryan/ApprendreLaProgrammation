Dans le chapitre précédent, nous vous avions dit que les pointeurs étaient entre autres utiles pour manipuler des données complexes. Les structures sont les premières que nous allons étudier.

Une **structure** est un regroupement de plusieurs objets, de types différents ou non. *Grosso modo*, une structure est finalement une boîte qui regroupe plein de données différentes.