Vous le savez, certaines (beaucoup) de fonctions standards peuvent échouer. Toutefois, en plus de signaler à l’utilisateur qu’une de ces fonctions a échoué, cela serait bien de lui spécifier *pourquoi*. C’est ici qu’entre en jeu les fonctions `sterror()` et `perror()`.

```c
char *strerror(int num);
```

La fonction `strerror()` (déclarée dans l’en-tête `<string.h>`) retourne une chaîne de caractères correspondant à la valeur entière fournie en argument. Cette valeur sera en fait *toujours* celle de la variable `errno`. Ainsi, il vous est possible d’obtenir plus de détails quand une fonction standard rencontre un problème. L’exemple suivant illustre l’utilisation de cette fonction en faisant appel à la fonction `fopen()` afin d’ouvrir un fichier qui n’existe pas (ce qui provoque une erreur).

```c
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main(void)
{
    FILE *fp;

    fp = fopen("nawak.txt", "r");

    if (fp == NULL)
    {
        fprintf(stderr, "fopen: %s\n", strerror(errno));
        return EXIT_FAILURE;
    }

    fclose(fp);
    return 0;
}
```

```text
fopen: No such file or directory
```

Comme vous le voyez, nous avons obtenu des informations supplémentaires : la fonction a échoué parce que le fichier « nawak.txt » n’existe pas.

[[information]]
| Notez que les messages d’erreur retournés par la fonction `strerror()` sont le plus souvent en anglais.

```c
void perror(char *message);
```

La fonction `perror()` (déclarée dans l’en-tête `<stdio.h>`) écrit sur le flux d’erreur standard (`stderr`, donc) la chaîne de caractères fournie en argument, suivie du caractère `:`, d’un espace et du retour de la fonction `strerror()` avec comme argument la valeur de la variable `errno`. Autrement dit, cette fonction revient au même que l’appel suivant.

```c
fprintf(stderr, "message: %s\n", strerror(errno));
```

L’exemple précédent peut donc également s’écrire comme suit.

```c
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    FILE *fp;

    fp = fopen("nawak.txt", "r");

    if (fp == NULL)
    {
        perror("fopen");
        return EXIT_FAILURE;
    }

    fclose(fp);
    return 0;
}
```

```text
fopen: No such file or directory
```