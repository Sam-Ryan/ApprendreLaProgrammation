# La macrofonction assert

Une des utilisation majeure de la fonction `abort()` est réalisée via la macrofonction `assert()` (définie dans l’en-tête `<assert.h>`). Cette dernière est utilisée pour placer des tests à certains points d’un programme. Dans le cas où un de ces tests s’avère faux, un message d’erreur est affiché (ce dernier comprend la condition dont l’évaluation est fausse, le nom du fichier et la ligne courante) après quoi la fonction `abort()` est appelée afin de produire une image mémoire.

Cette technique est très utile pour détecter rapidement des erreurs au sein d’un programme lors de sa phase de développement. Généralement, les assertions sont placées en début de fonction afin de vérifier un certains nombres de conditions. Par exemple, si nous reprenons la fonction `long_colonne()` du TP sur le Puissance 4.

```c
static unsigned long_colonne(unsigned joueur, unsigned col, unsigned ligne, unsigned char (*grille)[6])
{
    unsigned i;
    unsigned n = 1;

    for (i = ligne + 1; i < 6; ++i)
    {
        if (grille[col][i] == joueur)
            ++n;
        else
            break;
    }

    return n;
}
```

Nous pourrions ajouter quatre assertions vérifiant si :

* le numéro du joueur est un ou deux ;
* le numéro de la colonne est compris entre zéro et six inclus ;
* le numéro de la ligne est compris entre zéro et cinq ;
* le pointeur `grille` n’est pas nul.

Ce qui nous donne le code suivant.

```c
static unsigned long_colonne(unsigned joueur, unsigned col, unsigned ligne, unsigned char (*grille)[6])
{
    unsigned i;
    unsigned n = 1;

    assert(joueur == 1 || joueur == 2);
    assert(col < 7);
    assert(ligne < 6);
    assert(grille != NULL);

    for (i = ligne + 1; i < 6; ++i)
    {
        if (grille[col][i] == joueur)
            ++n;
        else
            break;
    }

    return n;
}
```

Ainsi, si nous ne respectons pas une de ces conditions pour une raison ou pour une autre, l’exécution du programme s’arrêtera et nous aurons droit à un message du type (dans le cas où la première assertion échoue).

```text
a.out: main.c:71: long_colonne: Assertion `joueur == 1 || joueur == 2' failed.
Aborted
```

Comme vous le voyez, le nom du programme est indiqué, suivi du nom du fichier, du numéro de ligne, du nom de la fonction et de la condition qui a échoué. Intéressant, non ? :)

# Suppression des assertions

Une fois votre programme développé et dûment testé, les assertions ne vous sont plus vraiment utiles étant donné que celui-ci fonctionne. Les conserver alourdirait l’exécution de votre programme en ajoutant des vérifications. Toutefois, heureusement, il est possible de supprimer ces assertions *sans modifier votre code* en ajoutant simplement l’option `-DNDEBUG` lors de la compilation.

```text
$ zcc -DNDEBUG main.c
```