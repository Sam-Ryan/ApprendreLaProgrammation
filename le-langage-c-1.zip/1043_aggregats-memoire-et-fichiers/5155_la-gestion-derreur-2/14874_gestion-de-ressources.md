# Allocation de ressources

Dans cette deuxième partie, nous avons découvert l’allocation dynamique de mémoire et la gestion de fichiers. Ces deux sujets ont un point en commun : il est nécessaire de passer par une fonction d’allocation et par une fonction de libération lors de leur utilisation. Il s’agit d’un processus commun en programmation appellé la **gestion de ressources**. Or, celle-ci pose un problème particulier dans le cas de la gestion d’erreurs. En effet, regardez de plus près ce code simplifié permettant l’allocation dynamique d’un tableau multidimensionnel de trois fois trois `int`.

```c
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    int **p;
    unsigned i;

    p = malloc(3 * sizeof(int *));

    if (p == NULL)
    {
        fprintf(stderr, "Échec de l'allocation\n");
        return EXIT_FAILURE;
    }

    for (i = 0; i < 3; ++i)
    {
        p[i] = malloc(3 * sizeof(int));

        if (p[i] == NULL)
        {
            fprintf(stderr, "Échec de l'allocation\n");
            return EXIT_FAILURE;
        }
    }

    /* ... */
    return 0;
}
```

Vous ne voyez rien d’anormal dans le cas de la seconde boucle ? Celle-ci quitte le programme en cas d’échec de la fonction `malloc()`. Oui, mais nous avons *déjà* fait appel à la fonction `malloc()` auparavant, ce qui signifie que si nous quittons le programme à ce stade, nous le ferons *sans avoir libéré certaines ressources* (ici de la mémoire).

Seulement voilà, comment faire cela sans rendre le programme bien plus compliqué et bien moins lisible ? C’est ici que l’utilisation de l’instruction `goto` devient pertinente et d’une aide précieuse. La technique consiste à placer la libération de ressources en fin de fonction et de se rendre au bon endroit de cette zone de libération à l’aide de l’instruction `goto`. Autrement dit, voici ce que cela donne avec le code précédent.

```c
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    int **p;
    unsigned i;
    int status = EXIT_FAILURE;

    p = malloc(3 * sizeof(int *));

    if (p == NULL)
    {
        fprintf(stderr, "Échec de l'allocation\n");
        goto fin;
    }

    for (i = 0; i < 3; ++i)
    {
        p[i] = malloc(3 * sizeof(int));

        if (p[i] == NULL)
        {
            fprintf(stderr, "Échec de l'allocation\n");
            goto liberer_p;
        }
    }

    status = 0;

    /* Zone de libération */
liberer_p:
    while (i > 0)
    {
        --i;
        free(p[i]);
    }

    free(p);
fin:
    return status;
}
```

Comme vous le voyez, nous avons placé deux étiquettes : une référençant l’instruction `return` et une autre désignant la première instruction de la zone de libération. Ainsi, nous quittons la fonction en cas d’échec de la première allocation, mais nous libérons les ressources auparavant dans le cas des allocations suivantes. Notez que nous avons ajouté une variable `status` afin de pouvoir retourner la bonne valeur suivant qu’une erreur est survenue ou non.

# Utilisation de ressources

Si le problème se pose dans le cas de l’allocation de ressources, il se pose également dans le cas de leur utilisation.

```c
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    FILE *fp;

    fp = fopen("texte.txt", "w");

    if (fp == NULL)
    {
        fprintf(stderr, "Le fichier texte.txt n'a pas pu être ouvert\n");
        return EXIT_FAILURE;
    }
    if (fputs("Au revoir !\n", fp) == EOF)
    {
        fprintf(stderr, "Erreur lors de l'écriture d'une ligne\n");
        return EXIT_FAILURE;
    }
    if (fclose(fp) == EOF)
    {
        fprintf(stderr, "Erreur lors de la fermeture du flux\n");
        return EXIT_FAILURE;        
    }

    return 0;
}
```

Dans le code ci-dessus, l’exécution du programme est stoppée en cas d’erreur de la fonction `fputs()`. Cependant, l’arrêt s’effectue alors qu’une ressource n’a pas été libérée (en l’occurrence le flux `fp`). Aussi, il est nécessaire d’appliquer la solution présentée juste avant pour rendre ce code correct.

```c
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    FILE *fp;
    int status = EXIT_FAILURE;

    fp = fopen("texte.txt", "w");

    if (fp == NULL)
    {
        fprintf(stderr, "Le fichier texte.txt n'a pas pu être ouvert\n");
        goto fin;
    }
    if (fputs("Au revoir !\n", fp) == EOF)
    {
        fprintf(stderr, "Erreur lors de l'écriture d'une ligne\n");
        goto fermer_flux;
    }
    if (fclose(fp) == EOF)
    {
        fprintf(stderr, "Erreur lors de la fermeture du flux\n");
        goto fin;   
    }

    status = 0;

fermer_flux:
    fclose(fp);
fin:
    return status;
}
```

Nous attirons votre attention sur deux choses :

* En cas d’échec de la fonction `fclose()`, le programme est arrêté immédiatement. Étant donné que c’est la fonction `fclose()` qui pose problème, il n’y a pas lieu de la rappeler (notez que cela n’est toutefois pas une erreur de l’appeler une seconde fois).
* Le retour de la fonction `fclose()` n’est pas vérifié en cas d’échec de la fonction `fputs()` étant donné que nous sommes *déjà* dans un cas d’erreur.