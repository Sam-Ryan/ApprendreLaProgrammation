Vous le savez, l’exécution de votre programme se termine lorsque celui-ci quitte la fonction `main()`. Toutefois, que se passe-t-il exactement lorsque celui-ci s’arrête ? En fait, un petit bout de code appelé **épilogue** est exécuté afin de réaliser quelques tâches. Parmis celles-ci figure la vidange et la fermeture de tous les flux encore ouvert. Une fois celui-ci exécuté, la main est rendue au système d’exploitation qui, le plus souvent, se chargera de libérer toutes les ressources qui étaient encore allouées.

[[question]]
| Mais ?! Vous venez de nous dire qu’il était nécessaire de libérer les ressources avant l’arrêt du programme. Du coup, pourquoi s’amuser à appeler les fonctions `fclose()` ou `free()` alors que l’épilogue ou le système d’exploitation s’en charge ?

Pour quatre raisons principales :

1. Afin de libérer des ressources pour les autres programmes. En effet, si vous ne libérerez les ressources allouées qu’à la fin de votre programme alors que celui-ci n’en a plus besoin, vous gaspillez des ressources qui pourraient être utilisées par d’autres programmes.
2. Pour être à même de détecter des erreurs, de prévenir l’utilisateur en conséquence et d’éventuellement lui proposer des solutions.
3. En vue de rendre votre code plus facilement modifiable par après et d’éviter les oublis.
4. Parce qu’il n’est pas garanti que les ressources seront effectivement libérées par le système d’exploitaion.

[[attention]]
|Aussi, de manière générale :
|
|* considérez que l’objectif de l’épilogue est de fermer *uniquement* les flux `stdin`, `stdout` et `stderr` ;
|* *ne* comptez *pas* sur votre système d’exploitation pour la libération de quelques ressources que ce soit (et notamment la mémoire) ;
|* libérez vos ressources le plus tôt possible, autrement dit dès que votre programme n’en a plus l’utilité.

# Terminaison normale

Le passage par l’épilogue est appelée la **terminaison normale** du programme. Il est possible de s’y rendre directement en appelant la fonction `exit()` qui est déclarée dans l’en-tête `<stdlib.h>`.

```c
void exit(int status);
```

Appeler cette fonction revient au même que de quitter la fonction `main()` à l’aide de l’instruction `return`. L’argument attendu est une expression entière identique à celle fournie comme opérande de l’instruction `return`. Ainsi, il vous est possible de mettre fin directement à l’exécution de votre programme *sans* retourner jusqu’à la fonction `main()`.

```c
#include <stdio.h>
#include <stdlib.h>


void fin(void)
{
    printf("C'est la fin du programme\n");
    exit(0);
}


int main(void)
{
    fin();
    printf("Retour à la fonction main\n");
    return 0;
}
```

```text
C'est la fin du programme
```

Comme vous le voyez l’exécution du programme se termine une fois que la fonction `exit()` est appelée. La fin de la fonction `main()` n’est donc *jamais* exécutée.

# Terminaison anormale

Il est possible de terminer l’exécution d’un programme *sans passer par l’épilogue* à l’aide de la fonction `abort()` (définie également dans l’en-tête `<stdlib.h>`). Dans un tel cas, il s’agit d’une **terminaison anormale** du programme.

```c
void abort(void);
```

Une terminaison anormale signifie qu’une condition *non prévue* par le programmeur est survenue. Elle est donc à distinguer d’une terminaison normale survenue suite à une erreur qui, elle, était prévue (comme une erreur lors d’une saisie de l’utilisateur). De manière générale, la terminaison anormale est utilisée lors de la phase de développement d’un logiciel afin de faciliter la détection d’erreurs de programmation, celle-ci entraînant le plus souvent la production d’une **image mémoire** (*core dump* en anglais) qui pourra être analysée à l’aide d’un **débogueur** (*debugger* en anglais).

[[information]]
| Une image mémoire est en fait un fichier contenant l’état des registres et de la mémoire d’un pogramme lors de la survenance d’un problème..