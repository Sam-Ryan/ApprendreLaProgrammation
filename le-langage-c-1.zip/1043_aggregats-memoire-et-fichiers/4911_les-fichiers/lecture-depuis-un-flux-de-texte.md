# Récupérer un caractère

```c
int getc(FILE *flux);
int fgetc(FILE *flux);
int getchar(void);
```

Les fonctions `getc()` et `fgetc()` sont les exacts miroirs des fonctions `putc()` et `fputc()` : elles récupèrent un caractère depuis le flux fourni en argument. Il s’agit de l’opération de lecture la plus basique sur laquelle reposent toutes les autres fonctions de lecture. Ces deux fonctions retournent soit le caractère lu, soit `EOF` si la fin de fichier est rencontrée *ou* si une erreur est rencontrée. La fonction `getchar()`, quant à elle, est identique à ces deux fonctions si ce n’est qu’elle récupère un caractère depuis le flux `stdin`.

[[information]]
| Comme `putc()`, la fonction `getc()` est le plus souvent une macrofonction. Utilisez donc plutôt la fonction `fgetc()` pour le moment.

L’exemple ci-dessous lit un caractère provenant du fichier `texte.txt`.

```c
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    FILE *fp;
    int ch;

    fp = fopen("texte.txt", "r");

    if (fp == NULL)
    {
        fprintf(stderr, "Le fichier texte.txt n'a pas pu être ouvert\n");
        return EXIT_FAILURE;
    }
    if ((ch = fgetc(fp)) != EOF)
        printf("%c\n", ch);
    if (fclose(fp) == EOF)
    {
        fprintf(stderr, "Erreur lors de la fermeture du flux\n");
        return EXIT_FAILURE;        
    }

    return 0;
}
```

[[information]]
| Notez que nous utilisons une affectation comme premier opérande de l’opérateur `!=`. Une affectation étant une expression en C, ce genre d’écriture est tout à fait valide. Vous en rencontrerez fréquemment comme expression de contrôle de boucles.

# Récupérer une ligne

```c
char *fgets(char *tampon, int taille, FILE *flux);
```

La fonction `fgets()` lit une ligne depuis le flux `flux` et la stocke dans le tableau `tampon`. Cette dernière lit au plus un nombre de caractères égal à `taille` diminué de un afin de laisser la place pour le caractère nul, qui est automatiquement ajouté. Dans le cas où elle rencontre un caractère de fin de ligne : *celui-ci est conservé au sein du tableau*, un caractère nul est ajouté et la lecture s’arrête.

La fonction retourne l’adresse du tableau `tampon` en cas de succès et un pointeur nul si la fin du fichier est atteinte *ou si une erreur est survenue*.

L’exemple ci-dessous réalise donc la même opération que le code précédent, mais en utilisant la fonction `fgets()`.

[[information]]
| Étant donné que la norme nous garanti qu’une ligne peut contenir jusqu’à 254 caractères (caractère de fin de ligne inclus), nous utilisons un tableau de 255 caractères pour les contenir (puisqu’il est nécessaire de prévoir un espace pour le caractère nul).

```c
#include <stdio.h>

int main(void)
{
    char buf[255];
    FILE *fp;

    fp = fopen("texte.txt", "r");

    if (fp == NULL)
    {
        fprintf(stderr, "Le fichier texte.txt n'a pas pu être ouvert\n");
        return EXIT_FAILURE;
    }
    if (fgets(buf, sizeof buf, fp) != NULL)
        printf("%s\n", buf);
    if (fclose(fp) == EOF)
    {
        fprintf(stderr, "Erreur lors de la fermeture du flux\n");
        return EXIT_FAILURE;        
    }

    return 0;
}
```

Toutefois, il y a un petit problème : la fonction `fgets()` conserve le caractère de fin de ligne qu’elle rencontre. Dès lors, nous affichons deux retours à la ligne : celui contenu dans la chaîne `buf` et celui affiché par `printf()`. Aussi, il serait préférable d’en supprimer un, de préférence celui de la chaîne de caractères. Pour ce faire, nous pouvons faire appel à une petite fonction (que nous appellerons `chomp()` en référence à la fonction éponyme du langage Perl) qui se chargera de remplacer le caractère de fin de ligne par un caractère nul.

```c
void chomp(char *s)
{
    while (*s != '\n' && *s != '\0')
        ++s;

    if (*s == '\n')
        *s = '\0';
}
```

# La fonction fscanf

```c
int fscanf(FILE *flux, char *format, ...);
```

La fonction `fscanf()` est identique à la fonction `scanf()` si ce n’est qu’elle récupère les données depuis le flux fourni en argument (au leu de `stdin` pour `scanf()`).

[[information]]
| Le flux `stdin` étant le plus souvent mémorisé par lignes, ceci vous explique pourquoi nous lisions les caractères restant après un appel à `scanf()` jusqu’à rencontrer un caractère de fin de ligne : pour vider le tampon du flux `stdin`.

La fonction `fscanf()` retourne le nombre de conversions réussies (voire zéro, si aucune n’est demandée ou n’a pu être réalisée) ou `EOF` si une erreur survient *avant* qu’une conversion n’ait eu lieu.