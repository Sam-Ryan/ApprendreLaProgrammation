# Écrire un multiplet

```c
int putc(int ch, FILE *flux);
int fputc(int ch, FILE *flux);
```

Comme pour les flux de texte, il vous est possible de recourir aux fonctions `putc()` et `fputc()`. Dans le cas d’un flux binaire, ces fonctions écrivent un multiplet (sous la forme d’un `int` converti en `unsigned char`) dans le flux spécifié.

# Écrire une suite de multiplets

```c
size_t fwrite(void *ptr, size_t taille, size_t nombre, FILE *flux);
```

La fonction `fwrite()` écrit le tableau référencé par `ptr` composé de `nombre` éléments de `taille` multiplets dans le flux `flux`. Elle retourne une valeur égale à `nombre` en cas de succès et une valeur inférieure en cas d’échec.

L'exemple suivant écrit le contenu du tableau `tab` dans le fichier `binaire.bin`. Dans le cas où un `int` fait 4 octets, 20 octets seront donc écrits.

```c
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    int tab[5] = { 1, 2, 3, 4, 5 };
    const size_t n = sizeof tab / sizeof tab[0];
    FILE *fp;

    fp = fopen("binaire.bin", "wb");

    if (fp == NULL)
    {
        fprintf(stderr, "Le fichier binaire.bin n'a pas pu être ouvert\n");
        return EXIT_FAILURE;
    }
    if (fwrite(&tab, sizeof tab[0], n, fp) != n)
    {
            fprintf(stderr, "Erreur lors de l'écriture du tableau\n");
            return EXIT_FAILURE;
    }
    if (fclose(fp) == EOF)
    {
        fprintf(stderr, "Erreur lors de la fermeture du flux\n");
        return EXIT_FAILURE;        
    }

    return 0;
}
```