# La fonction fopen

```c
FILE *fopen(char *chemin, char *mode);
```

La fonction `fopen()` permet d’ouvrir un flux. Celle-ci attend deux arguments : un **chemin d’accès** vers un fichier qui sera associé au flux et un **mode** qui détermine le type de flux (texte ou binaire) et la nature des opérations qui seront réalisées sur le fichier via le flux (lecture, écriture ou les deux). Elle retourne un pointeur vers un flux en cas de succès et un pointeur nul en cas d’échec.

## Le mode

Le mode est une chaîne de caractères composée d’une ou plusieurs lettres qui décrit le type du flux et la nature des opérations qu’il doit réaliser. 

Cette chaîne commence *obligatoirement* par la seconde de ces informations. Il existe six possibilités reprises dans le tableau ci-dessous.

+-------------------------+-------------------------+-------------------------+
| Mode                    | Type(s) d’opération(s)  | Effets                  |
+=========================+=========================+=========================+
| `r`                     | Lecture                 | Néant                   |
|                         |                         |                         |
|                         |                         |                         |
|                         |                         |                         |
|                         |                         |                         |
+-------------------------+-------------------------+-------------------------+
| `r+`                    | Lecture et écriture     | Néant                   |
|                         |                         |                         |
|                         |                         |                         |
|                         |                         |                         |
|                         |                         |                         |
+-------------------------+-------------------------+-------------------------+
| `w`                     | Écriture                | Si le fichier n’existe  |
|                         |                         | pas, il est créé.       |
|                         |                         |                         |
|                         |                         | Si le fichier existe,   |
|                         |                         | son contenu est effacé. |
+-------------------------+-------------------------+-------------------------+
| `w+`                    | Lecture et écriture     | *Idem*                  |
|                         |                         |                         |
|                         |                         |                         |
|                         |                         |                         |
|                         |                         |                         |
+-------------------------+-------------------------+-------------------------+
| `a`                     | Écriture                | Si le fichier n’existe  |
|                         |                         | pas, il est créé.       |
|                         |                         |                         |
|                         |                         | Place les données à la  |
|                         |                         | fin du fichier          |
+-------------------------+-------------------------+-------------------------+
| `a+`                    | Lecture et écriture     | *Idem*                  |
|                         |                         |                         |
|                         |                         |                         |
|                         |                         |                         |
|                         |                         |                         |
+-------------------------+-------------------------+-------------------------+

Par défaut, les flux sont des flux de textes. Pour obtenir un flux binaire, il suffit d’ajouter la lettre `b` à la fin de la chaîne décrivant le mode.

## Exemple

Le code ci-dessous tente d’ouvrir un fichier nommé « texte.txt » en lecture seule dans le dossier courant. Notez que dans le cas où il n’existe pas, la fonction `fopen()` retournera un pointeur nul (seul le mode `r` permet de produire ce comportement).

```c
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    FILE *fp;

    fp = fopen("texte.txt", "r");

    if (fp == NULL)
    {
        printf("Le fichier texte.txt n'a pas pu être ouvert\n");
        return EXIT_FAILURE;
    }

    printf("Le fichier texte.txt existe\n");
    return 0;
}
```

# La fonction fclose

```c
int fclose(FILE *flux);
```

La fonction `fclose()` termine l’association entre un flux et un fichier. S’il reste des données temporisées, celles-ci sont écrites. La fonction retourne zéro en cas de succès et `EOF` en cas d’erreur.

[[information]]
| `EOF` est une constante définie dans l’en-tête `<stdio.h>` et est utilisée par les fonctions déclarées dans ce dernier pour indiquer soit l’arrivée à la fin d’un fichier (nous allons y venir) soit la survenance d’une erreur. La valeur de cette constante est *toujours* un entier *négatif*.

Nous pouvons désormais compléter l’exemple précédent comme suit.

```c hl_lines="19-23"
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    FILE *fp;

    fp = fopen("texte.txt", "r");

    if (fp == NULL)
    {
        printf("Le fichier texte.txt n'a pas pu être ouvert\n");
        return EXIT_FAILURE;
    }

    printf("Le fichier texte.txt existe\n");

    if (fclose(fp) == EOF)
    {
        printf("Erreur lors de la fermeture du flux\n");
        return EXIT_FAILURE;        
    }

    return 0;
}
```

[[attention]]
| Veillez qu’à chaque appel à la fonction `fopen()` corresponde un appel à la fonction `fclose()`.