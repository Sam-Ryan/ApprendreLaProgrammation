# Écrire un caractère

```c
int putc(int ch, FILE *flux);
int fputc(int ch, FILE *flux);
int putchar(int ch);
```

Les fonctions `putc()` et `fputc()` écrivent un caractère dans un flux. Il s’agit de l’opération d’écriture la plus basique sur laquelle reposent toutes les autres fonctions d’écriture. Ces deux fonctions retournent soit le caractère écrit, soit `EOF` si une erreur est rencontrée. La fonction `putchar()`, quant à elle, est identique aux fonctions `putc()` et `fputc()` si ce n’est qu’elle écrit dans le flux `stdout`.

[[information]]
| Techniquement, `putc()` et `fputc()` sont identiques, si ce n’est que `putc()` est en fait le plus souvent une macrofonction. Étant donné que nous n’avons pas encore vu de quoi il s’agit, préférez utiliser la fonction `fputc()` pour l’instant.

L’exemple ci-dessous écrit le caractère « C » dans le fichier « texte.txt ». Étant donné que nous utilisons le mode `w`, le fichier est soit créé s’il n’existe pas, soit vidé de son contenu s’il existe (revoyer le tableau des modes à la section précédente si vous êtes perdus).

```c
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    FILE *fp;
    
    fp = fopen("texte.txt", "w");

    if (fp == NULL)
    {
        printf("Le fichier texte.txt n'a pas pu être ouvert\n");
        return EXIT_FAILURE;
    }
    if (fputc('C', fp) == EOF)
    {
        printf("Erreur lors de l'écriture d'un caractère\n");
        return EXIT_FAILURE;
    }
    if (fclose(fp) == EOF)
    {
        printf("Erreur lors de la fermeture du flux\n");
        return EXIT_FAILURE;        
    }

    return 0;
}
```

# Écrire une ligne

```c
int fputs(char *ligne, FILE *flux);
int puts(char *ligne);
```

La fonction `fputs()` écrit une ligne dans le flux `flux`. La fonction retourne un nombre positif ou nul en cas de succès et `EOF` en cas d’erreurs. La fonction `puts()` est identique si ce n’est qu’elle ajoute automatiquement un caractère de fin de ligne et qu’elle écrit sur le flux `stdout`.

[[information]]
| Maintenant que nous savons comment écrire une ligne dans un flux précis, nous allons pouvoir diriger nos messages d’erreurs vers le flux `stderr` afin que ceux-ci soient affichés le plus rapidement possible.

L’exemple suivant écrit le mot « Bonjour » suivi d’un caractère de fin de ligne au sein du fichier « texte.txt ».

```c
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    FILE *fp;
    
    fp = fopen("texte.txt", "w");

    if (fp == NULL)
    {
        fputs("Le fichier texte.txt n'a pas pu être ouvert\n", stderr);
        return EXIT_FAILURE;
    }
    if (fputs("Bonjour\n", fp) == EOF)
    {
        fputs("Erreur lors de l'écriture d'une ligne\n", stderr);
        return EXIT_FAILURE;
    }
    if (fclose(fp) == EOF)
    {
        fputs("Erreur lors de la fermeture du flux\n", stderr);
        return EXIT_FAILURE;        
    }

    return 0;
}
```

[[attention]]
| La norme[^max_ligne] vous garanti qu’une ligne peut contenir jusqu’à 254 caractères (caractère de fin de ligne inclus). Aussi, veillez à ne pas écrire de ligne d’une taille supérieure à cette limite.

# La fonction fprintf

```c
int fprintf(FILE *flux, char *format, ...);
```

La fonction `fprintf()` est la même que la fonction `printf()` si ce n’est qu’il est possible de lui spécifier sur quel flux écrire (au lieu de `stdout` pour `printf()`). Elle retourne le nombre de caractères écrits ou une valeur négative en cas d’échec.

[^max_ligne]: Programming Language C, X3J11/88-090, § 4.9.2, Streams, al. 4