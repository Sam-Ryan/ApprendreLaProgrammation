La bibliothèque standard vous fourni différentes fonctions pour manipuler les fichiers, toutes déclarées dans l’en-tête `<stdio.h>`. Toutefois, celles-ci manipulent non pas des fichiers, mais des **flux** de données en provenance ou à destination de fichiers. Ces flux peuvent être de deux types :

* des flux de textes qui sont des suites de caractères terminées par un caractère de fin de ligne (`\n`) et formant ainsi des lignes ;
* des flux binaires qui sont des suites de multiplets.

# Pourquoi utiliser des flux ?

Pourquoi recourir à des flux plutôt que de manipuler directement des fichiers nous demanderez-vous ? Pour deux raisons : les disparités entre système d’exploitation quant à la représentation des lignes et la lourdeur des opérations de lecture et d’écriture.

## Disparités entre systèmes d’exploitation

Les différents systèmes d’exploitation ne représentent pas les lignes de la même manière :

* sous Mac OS (avant Mac OS X), la fin d’une ligne était indiquée par le caractère `\r` ;
* sous Windows, la fin de ligne est indiquée par la suite de caractères `\r\n` ;
* sous Unixoïdes (GNU/Linux, \*BSD, Mac OS X, Solaris, etc.), la fin de ligne est indiquée par le caractère `\n`.

Aussi, si nous manipulions directement des fichiers, nous devrions prendre en compte ces disparités, ce qui rendrait notre code nettement plus pénible à rédiger. En passant par les fonctions de la bibliothèque standard, nous évitons ce casse-tête car celle-ci remplace le ou les caractères de fin de ligne par un `\n` (ce que nous avons pu expérimenter avec les fonctions `printf()` et `scanf()`) et inversément.

## Lourdeur des opérations de lecture et d’écriture

Lire depuis un fichier ou écrire dans un fichier signifie le plus souvent accéder au disque dur. Or, rappelez-vous, il s’agit de la mémoire la plus lente d’un ordinateur. Dès lors, si pour lire une ligne il était nécessaire de récupérer les caractères un à un depuis le disque dur, cela prendrait un temps fou.

Pour éviter ce problème, les flux de la bibliothèque standard recourent à un mécanisme appelé la **temporisation** ou **mémorisation** (*buffering* en anglais). La bibliothèque standard fournit deux types de temporisation :

- la temporisation par blocs ; 
- et la temporisation par lignes.

Avec la **temporisation par blocs**, les données sont récupérées depuis le fichier et écrites dans le fichier sous forme de blocs d’une taille déterminée. L’idée est la suivante : plutôt que de lire les caractères un à un, nous allons demander un bloc de données d’une taille déterminée que nous conserverons en mémoire vive pour les accès suivants. Cette technique est également utilisée lors des opérations d’écritures : les données sont stockées en mémoire jusqu’à ce qu’elles atteignent la taille d’un bloc. Ainsi, le nombre d’accès au disque dur sera limité à la taille totale du fichier à lire (ou des données à écrire) divisée par la taille d’un bloc.

La **temporisation par lignes**, comme son nom l’indique, se contente de mémoriser une ligne. Techniquement, celle-ci est utilisée lorsque le flux est associé à un périphérique interactif comme un terminal. En effet, si nous appliquions la temporisation par blocs pour les entrées de l’utilisateur, ce dernier devrait entrer du texte jusqu’à atteindre la taille d’un bloc. Pareillement, nous devrions attendre d’avoir écrit une quantité de données égale à la taille d’un bloc pour que du texte soit affiché à l’écran. Cela serait assez gênant et peu interactif… À la place, c’est la temporisation par lignes qui est utilisée : les données sont stockées jusqu’à ce qu’un caractère de fin de ligne soit rencontré (`\n`, donc) ou jusqu’à ce qu’une taille maximale soit atteinte.

La bibliothèque standard vous permet également de ne pas temporiser les données en provenance ou à destination d’un flux.

# stdin, stdout et stderr

Par défaut, trois flux *de texte* sont ouverts lors du démarrage d’un programme et sont déclarés dans l’en-tête `<stdio.h>` : `stdin`, `stdout` et `stderr`.

* `stdin` correspond à l’**entrée standard**, c’est-à-dire le flux depuis lequel vous pouvez récupérer les informations fournies par l’utilisateur.
* `stdout` correspond à la **sortie standard**, il s’agit du flux vous permettant de transmettre des informations à l’utilisateur qui seront le plus souvent affichées dans le terminal.
* `stderr` correspond à la **sortie d’erreur standard**, c’est ce flux que vous devez privilégier lorsque vous souhaitez transmettre des messages d’erreurs ou des avertissements à l’attention de l’utilisateur (nous verrons comment l’utiliser un peu plus tard dans ce chapitre). Comme pour `stdout`, ces données sont le plus souvent affichées dans le terminal.

Les flux `stdin` et `stdout` sont temporisés par lignes (sauf s’ils sont associés à des fichiers au lieu de périphériques interactifs, auxquels cas ils seront temporisés par blocs) tandis que le flux `stderr` est *au plus* temporisé par lignes (ceci afin que les informations soient transmises le plus rapidement possible à l’utilisateur).