En informatique, un fichier est un ensemble d’informations stockées sur un support, réuni sous un même nom et manipulé comme une unité. 

# Extension de fichier

Le contenu de chaque fichier est lui-même organisé suivant un format qui dépend des données qu’il contient. Il en existe une pléthore pour chaque type de données :

* audio : Ogg, MP3, MP4, FLAC, Wave, etc. ;
* vidéo : Ogg, WebM, MP4, AVI, etc. ;
* documents : ODT, DOC et DOCX, XLS et XLSX, PDF, Postscript, etc.

Afin d’aider l’utilisateur, ces formats sont le plus souvent indiqués à l’aide d’une **extension** qui se traduit par un suffixe ajouter au nom de fichier. Toutefois, cette extension est purement *indicative* et *facultative*, elle n’influence *en rien* le contenu du fichier. Son seul objectif est d’aider à déterminer le type de contenu d’un fichier.

# Système de fichiers

Afin de faciliter leur localisation et leur gestion, les fichiers sont classés et organisés sur leur support suivant un **système de fichiers**. C’est lui qui permet à l’utilisateur de répartir ses fichiers dans une arborescence de dossiers et de localiser ces derniers à partir d’un chemin d’accès. 

## Le chemin d’accès

Le chemin d’accès d’un fichier est une suite de caractères décrivant la position de celui-ci dans le système de fichiers. Un chemin d’accès se compose au minimum du nom du fichier visé et au maximum de la suite de tous les dossiers qu’il est nécessaire de traverser pour l’atteindre depuis le **répertoire racine**. Ces éventuels dossiers à traverser sont séparés par un caractère spécifique qui est `/` sous Unixoïde et `\` sous Windows.

La **racine** d’un système de fichier est le point de départ de l’arborescence des fichiers et dossiers. Sous Unixoïdes, il s’agit du répertoire `/` tandis que sous Windows, chaque lecteur est une racine (comme `C:` par exemple). Si un chemin d’accès commence par la racine, alors celui-ci est dit **absolu** car il permet d’atteindre le fichier depuis n’importe quelle position dans l’arborescence. Si le chemin d’accès ne commence pas par la racine, il est dit **relatif** et ne permet de parvenir au fichier que depuis un point précis dans la hiérarchie de fichiers.

Ainsi, si nous souhaitons accéder à un fichier nommé « texte.txt » situé dans le dossier « documents » lui-même situé dans le dossier « utilisateur » qui est à la racine, alors le chemin d’accès absolu vers ce fichier serait `/utilisateur/documents/texte.txt` sous Unixoïde et `C:\utilisateur\documents\texte.txt` sous Windows (à supposer qu’il soit sur le lecteur `C:`). Toutefois, si nous sommes déjà dans le dossier « utilisateur », alors nous pouvons y accéder à l’aide du chemin relatif `documents/texte.txt` ou `documents\texte.txt`. Néanmoins, ce chemin relatif n’est utilisable que si nous sommes dans le dossier « utilisateur ».

## Métadonnées

Également, le système de fichier se charge le plus souvent de conserver un certain nombre de données concernant chaque fichier comme :

* sa taille ;
* ses droits d’accès (les utilisateurs autorisés à le manipuler) ;
* la date de dernier accès ;
* la date de dernière modification ;
* etc.