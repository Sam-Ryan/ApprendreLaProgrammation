# Lire un multiplet

```c
int getc(FILE *flux);
int fgetc(FILE *flux);
```

Lors de la lecture depuis un flux binaire, les fonctions `fgetc()` et `getc()` permettent de récupérer un multiplet (sous la forme d’un `unsigned char` converti en `int`) depuis un flux.

# Lire une suite de multiplets

```c
size_t fread(void *ptr, size_t taille, size_t nombre, FILE *flux);
```

La fonction `fread()` est l’inverse de la fonction `fwrite()` : elle lit `nombre` éléments de `taille` multiplets depuis le flux `flux` et les stocke dans l’objet référencé par `ptr`. Elle retourne une valeur égale à `nombre` en cas de succès ou une valeur inférieure en cas d’échec.

Dans le cas où nous disposons du fichier `binaire.bin` produit par l'exemple de la section précédente, nous pouvons reconstituer le tableau `tab`.

```c
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    int tab[5] = { 1, 2, 3, 4, 5 };
    const size_t n = sizeof tab / sizeof tab[0];
    FILE *fp;
    unsigned i;

    fp = fopen("binaire.bin", "rb");

    if (fp == NULL)
    {
        fprintf(stderr, "Le fichier binaire.bin n'a pas pu être ouvert\n");
        return EXIT_FAILURE;
    }
    if (fread(&tab, sizeof tab[0], n, fp) != n)
    {
            fprintf(stderr, "Erreur lors de la lecture du tableau\n");
            return EXIT_FAILURE;
    }
    if (fclose(fp) == EOF)
    {
        fprintf(stderr, "Erreur lors de la fermeture du flux\n");
        return EXIT_FAILURE;        
    }

    for (i = 0; i < n; ++i)
        printf("tab[%u] = %d\n", i, tab[i]);

    return 0;
}
```

```text
tab[0] = 1
tab[1] = 2
tab[2] = 3
tab[3] = 4
tab[4] = 5
```