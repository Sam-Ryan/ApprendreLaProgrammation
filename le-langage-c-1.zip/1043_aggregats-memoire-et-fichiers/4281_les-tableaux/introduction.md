Poursuivons notre tour d’horizon des données complexes avec les **tableaux**.

Comme les structures, les tableaux sont des regoupements de plusieurs objets. Cependant, à l’inverse de celles-ci, les tableaux regroupe des données de *même type* et de manière *contiguë* (ce qui exclut la présence de multiplets de bourrage).

![Représentation d’un tableau en mémoire](http://zestedesavoir.com/media/galleries/1501/8d2dab24-30b3-4fd0-8ff9-1d7ee85f2362.png.960x960_q85.png)

Un tableau est donc un gros bloc de mémoire de *taille finie* qui commence à une adresse déterminée : celle de son premier élément.