# Somme des éléments

Réalisez une fonction qui calcule la somme de tous les éléments d’un tableau de `int`.

[[secret]]
|```c
| int somme(int *tab, unsigned taille)
| {
|     unsigned i;
|     int res = 0 ;
| 
|     for (i = 0; i < taille; ++i)
|         res += tableau[i];
| 
|     return res;
| }
|```

# Maximum et minimum

Créez deux fonctions : une qui retourne le plus petit élément d’un tableau de `int` et une qui renvoie le plus grand élément d’un tableau de `int`.

[[secret]]
|```c
| int minimum(int *tab, unsigned taille)
| {
|     unsigned i;
|     int min = tab[0];
| 
|     for (i = 1; i < taille; ++i)
|         if (tab[i] < min)
|             min = tab[i];
| 
|     return min;
| }
| 
| 
| int maximum(int *tab, unsigned taille)
| {
|     unsigned i;
|     int max = tab[0];
| 
|     for (i = 1; i < taille; ++i)
|         if (tab[i] > max)
|             max = tab[i];
| 
|     return max
| }
|```

# Recherche d’un élément

Construisez une fonction qui teste la présence d’une valeur dans un tableau de `int`. Celle-ci retournera 1 si un ou plusieurs éléments du tableau sont égaux à la valeur recherchée, 0 sinon.

[[secret]]
| ```c
| int find(int * tab, unsigned taille, int val)
| {
|     unsigned i;
| 
|     for (i = 0; i < taille; ++i)
|         if (tab[i] == val) 
|             return 1;
|
|     return 0;
| }
| ```

# Inverser un tableau

Produisez une fonction qui inverse le contenu d’un tableau (le premier élément devient le dernier, l’avant dernier le deuxième et ainsi de suite).

## Indice

[[secret]]
| Pensez à la fonction `swap()` présentée dans le chapitre sur les pointeurs.

## Correction

[[secret]]
| ```c
| void swap(int *pa, int *pb)
| {
|     int tmp;
|
|     tmp = *pa;
|     *pa = *pb;
|     *pb = tmp;
| }
|
|
| void invert(int *tab , unsigned taille)
| {
|     unsigned i;
| 
|     for (i = 0; i < (taille / 2); ++i)
|         swap(tab + i , tab + taille - 1 - i);
|     }
| }
| ```

# Produit des lignes

Composez une fonction qui calcul le produit de la somme des éléments de chaque ligne d’un tableau de `int` à deux dimensions (ce tableau comprend cinq lignes et cinq colonnes).

[[secret]]
|```c
| int produit(int (*tab)[5])
| {
|     unsigned i;
|     unsigned j;
|     int res = 1;
|
|     for (i = 0; i < 5; ++i)
|     {
|         int tmp = 0;
|
|         for (j = 0; j < 5; ++j)
|             tmp += tab[i][j];
|
|         res *= tmp;
|     }
|
|     return res;
| }
|```

# Triangle de Pascal

Les triangles de Pascal sont des objets mathématiques amusants. Voici une petite animation qui vous expliquera le fonctionnement de ceux-ci.

![Explication des triangles de Pascal en image](http://upload.wikimedia.org/wikipedia/commons/0/0d/PascalTriangleAnimated2.gif)

Votre objectif va être de réaliser un programme qui affiche un triangle de Pascal de la taille souhaitée par l’utilisateur. Pour ce faire, nous allons diviser le triangle en lignes afin de pouvoir le représenter sous la forme d’un tableau à deux dimensions. Chaque élément du tableau se verra attribué soit une valeur du triangle soit zéro pour signaler qu’il n’est pas utilisé.

La première chose que nous allons faire est donc définir un tableau à deux dimensions (nous fixerons la taille des dimensions à dix) dont tous les éléments sont initialisés à zéro. Ensuite, nous allons demandés à l’utilisateur d’entrer la taille du triangle qu’il souhaite obtenir (celle-ci ne devra pas être supérieure aux dimensions du tableau).

À présent, passons à la fonction de création du triangle de Pascal. Celle-ci devra mettre en œuvre l’algorithme suivant.

```console
N = taille du triangle de Pascal fournie par l’utilisateur

Mettre la première case du tableau à 1

Pour i = 1, i < N, i = i + 1
    Mettre la première case de la ligne à 1

    Pour j = 1, j < i, j = j + 1
         La case [i,j] prend la valeur [i - 1, j - 1] + [i - 1, j]

    Mettre la dernière case de la ligne à 1
```

Enfin, il vous faudra écrire une petite fonction pour afficher le tableau ainsi créer.  
Bon courage ! ;)

[[secret]]
|```c
| #include <stdio.h>
| #include <stdlib.h>
| 
| 
| void triangle_pascal(int (*tab)[10], unsigned taille)
| {
|     unsigned i;
|     unsigned j;
| 
|     tab[0][0] = 1;
| 
|     for (i = 1; i < taille; ++i)
|     {
|         tab[i][0] = 1;
| 
|         for (j = 1; j < i; ++j)
|             tab[i][j] = tab[i - 1][j - 1] + tab[i - 1][j];
| 
|         tab[i][i] = 1;
|     }
| }
| 
| 
| void print_triangle(int (*tab)[10], unsigned taille)
| {
|     unsigned i;
|     unsigned j;
|     int sp;
| 
|     for (i = 0; i < taille; ++i)
|     {
|         for (sp = taille - 1 - i; sp > 0; --sp)
|             printf(" ");
| 
|         for (j = 0; j < taille; ++j)
|             if (tab[i][j] != 0)
|                 printf("%d ", tab[i][j]);
| 
|         printf("\n");
|     }
| }
| 
| 
| int main(void)
| {
|     int tab[10][10] = { { 0 } };
|     unsigned taille;
| 
|     printf("Taille du triangle: ");
| 
|     if (scanf("%u", &taille) != 1)
|     {
|         printf("Mauvaise saisie\n");
|         return EXIT_FAILURE;
|     }
|     else if (taille > 10)
|     {
|         printf("La taille ne doit pas être supérieure à 10\n");
|         return EXIT_FAILURE;
|     }
| 
|     triangle_pascal(tab, taille);
|     print_triangle(tab, taille);	
|     return 0;
| }
|```