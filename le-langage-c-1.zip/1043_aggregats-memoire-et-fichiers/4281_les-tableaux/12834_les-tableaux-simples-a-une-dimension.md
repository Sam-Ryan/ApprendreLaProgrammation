# Définition

La définition d’un tableau nécessite trois informations : 

* le type des éléments du tableau (rappelez-vous : un tableau est une suite de données de *même type*) ;	
* le nom du tableau (en d’autres mots, son identificateur) ;	
* **la longueur** du tableau (le nombre d’éléments qui le composent). Cette dernière doit *obligatoirement* être une constante entière.

```text
type identificateur[longueur];
```

Comme vous le voyez, la syntaxe de la déclaration d’un tableau est similaire à celle d’une variable, la seule différence étant qu’il vous est nécessaire de préciser le nombre d’éléments entre crochets à la suite de l’identificateur du tableau.

Ainsi, si nous souhaitons par exemple définir un tableau contenant vingt ```int```, nous devons procéder comme suit.

```c
int tab[20];
```

# Initialisation

Comme pour les variables, il est possible d’initialiser un tableau ou, plus précisément, tout ou partie de ses éléments.

## Initialisation avec une longueur explicite

L’initialisation se réalise de la même manière que pour les structures, c’est-à-dire à l’aide d’une liste d’initialisation.

```c
int tab[3] = { 1, 2, 3 };
```

L’exemple ci-dessus initialise les trois membres du tableau avec les valeurs 1, 2 et 3.

[[attention]]
| Comme pour les structures, dans le cas où vous ne fournissez pas un nombre suffisant de valeurs, les éléments oubliés seront initialisés à zéro ou, s’il s’agit de pointeurs, seront des pointeurs nuls.

Pour un tableau de structures, la liste d’initialisation comportera elle-même une liste d’initialistation pour chaque structure composant le tableau.

```c
struct temps tab[2] = { { 12, 45, 50.6401 }, { 13, 30, 35.480 } } ; 
```

[[information]]
| Notez que, inversément, une structure peut comporter des tableaux comme membres.

## Initialisation avec une longueur implicite

Lorsque vous initialisez un tableau, il vous est permis d’omettre la longueur de celui-ci, car le compilateur sera capable d’en déterminer la taille en comptant le nombre d’éléments présents dans la liste d’initialisation. Ainsi, l’exemple ci-dessous est correct et défini un tableau de trois `int` valant respectivement 1, 2 et 3.

```c
int tab[] = { 1, 2, 3 };
```

# Accès aux éléments d’un tableau

L’accès aux éléments d’un tableau se réalise à l’aide d’un **indice**, un nombre entier correspondant à la position de chaque élément dans le tableau (premier, deuxième, troisième, etc). Cependant, il y a une petite subtilité : *les indices commencent toujours à zéro*.

Ceci tient au fait que l’accès aux différents éléments est réalisé à l’aide de l’adresse du premier élément à laquelle est ajouté l’indice (qui doit donc être nul pour conserver l’adresse du premier élément). Étant donné que tous les éléments ont la même taille et se suivent en mémoire, leurs adresses peuvent effectivement se calculer à l’aide de l’adresse du premier élément et d’un décalage par rapport à celle-ci (l’indice, donc).

Prenons un exemple avec un tableau composés de `int` (ayant une taille de quatre octets) et dont le premier élément est placé à l’adresse 1008. Si vous déterminez à la main les adresses de chaque élèment, vous obtiendrez ceci.

Indice | Adresse de l’élément
---------- | --------------------
0 | 1008 (1008 + 0)
1 | 1012 (1008 + 4)
2 | 1016 (1008 + 8)
3 | 1020 (1008 + 12)
4 | 1024 (1008 + 16)
5 | 1028 (1008 + 20)
… | …

En fait, il est possible de reformuler ceci à l’aide d’une multiplication entre l’indice et la taille d’un `int`.
  
Indice | Adresse de l’élément
---------- | --------------------
0 | 1008 (1008 + (0 * 4))
1 | 1012 (1008 + (1 * 4))
2 | 1016 (1008 + (2 * 4))
3 | 1020 (1008 + (3 * 4))
4 | 1024 (1008 + (4 * 4))
5 | 1028 (1008 + (5 * 4))
… | …

Nous pouvons désormais formaliser mathématiquement tout ceci en posant $T$ la taille d’un élément du tableau, $i$ l’indice de cet élément, et $A$  l’adresse de début du tableau (l’adresse du premier élément, donc). L’adresse de l’élément d’indice $i$ s’obtient en calculant $A + T \times i$. Ceci étant posé, voyons à présent comment mettre tout cela en œuvre en C.

## Le premier élément

Pour commencer, nous avons besoin de l’adresse du premier élément du tableau. Celle-ci s’obtient en fait d’une manière plutôt contre-intuitive : lorsque vous utilisez une variable de type tableau dans une expression, celle-ci est convertie implicitement en un pointeur *constant* sur son premier élément. Comme vous pouvez le constater dans l’exemple qui suit, nous pouvons utiliser la variable `tab` comme nous l’aurions fait s’il s’agissait d’un pointeur.

```c
#include <stdio.h>

int main(void)
{
    int tab[3] = { 1, 2, 3 };

    printf("Premier élément : %d\n", *tab);
    return 0;
}
```

```text
Premier élément : 1
```

Notez que comme il s’agit d’une conversion implicite vers un pointeur constant, il n’est pas possible d’affecter une valeur à une variable de type tableau. Ainsi, le code suivant est incorrect.

```c
int t1[3];
int t2[3];

t1 = t2; /* Incorrect. */
```

La règle de conversion implicite comprends néanmoins deux exceptions : l’opérateur `&` et l’opérateur `sizeof`.

Lorsqu’il est appliqué à une variable de type tableau, l’opérateur `&` produit comme résultat l’adresse du premier élément du tableau. Si vous exécutez le code ci-dessous, vous constaterez que les deux expressions donnent un résultat identique.

```c
#include <stdio.h>


int main(void)
{
    int tab[3];

    printf("%p == %p\n", (void *)tab, (void *)&tab);
    return 0;
}
```

Dans le cas où une expression de type tableau est fournie comme opérande de l’opérateur `sizeof`, le résultat de celui-ci sera bien la taille totale du tableau (en multiplets) et non la taille d’un pointeur.

```c
#include <stdio.h>


int main(void)
{
    int tab[3];
    int *ptr;

    printf("sizeof tab = %u\n", (unsigned)sizeof tab);
    printf("sizeof ptr = %u\n", (unsigned)sizeof ptr);
    return 0;
}
```

```text
sizeof tab = 12
sizeof ptr = 8
```

Cette propriété vous permet d’obtenir le nombre d’éléments d’un tableau à l’aide de l’expression suivante.

```c
sizeof tab / sizeof tab[0]
```

## Les autres éléments

Pour accéder aux autres éléments, il va nous falloir ajouter la position de l’élément voulu à l’adresse du premier élément et ensuite utiliser l’adresse obtenue. Toutefois, recourir à la formule présentée au-dessus ne marchera pas car, en C, les pointeurs sont typés. Dès lors, lorsque vous additionnez un nombre à un pointeur, le compilateur multiplie automatiquement ce nombre par la taille du type d’objet référencé par le pointeur. Ainsi, pour un tableau de `int`, l’expression `tab + 1` est implicitement convertie en `tab + sizeof(int)`.

Voici un exemple affichant la valeur de tous les éléments d’un tableau.

```c
#include <stdio.h>


int main(void)
{
    int tab[3] = { 1, 2, 3 };

    printf("Premier élément : %d\n", *tab);
    printf("Deuxième élément : %d\n", *(tab + 1));
    printf("Troisième élément : %d\n", *(tab + 2));
    return 0;
}
```

```text
Premier élément : 1
Deuxième élément : 2
Troisième élément : 3
```

L’expression `*(tab + i)` étant quelque peu lourde, il existe un opérateur plus concis pour réaliser cette opération : l’opérateur `[]`. Celui-ci s’utilise de cette manière.

```text
expression[indice]
```

Ce qui est équivalent à l’expression suivante.

```text
*(expression + indice)
```

L’exemple suivant est donc identique au précédent.

```c
#include <stdio.h>


int main(void)
{
    int tab[3] = { 1, 2, 3 };

    printf("Premier élément : %d\n", tab[0]);
    printf("Deuxième élément : %d\n", tab[1]);
    printf("Troisième élément : %d\n", tab[2]);
    return 0;
}
```

# Parcours et débordement

Une des erreurs les plus fréquente en C consiste à dépasser la taille d’un tableau, ce qui est appelé un cas de **débordement** (*overflow* en anglais). En effet, si vous tentez d’accéder à un objet qui ne fait pas partie de votre tableau, vous réalisez un accès mémoire non autorisé, ce qui provoquera un comportement indéfini. Cela arrive généralement lors d’un parcours de tableau à l’aide d’une boucle.

```c
#include <stdio.h>


int main(void)
{
    int tableau[5] = {784, 5, 45, -12001, 8};
    int somme = 0;
    unsigned i; 

    for (i = 0; i <= 5; ++i)
        somme += tableau[i];
    
    printf("%d\n", somme);
    return 0;
}
```

Le code ci-dessus est volontairement erroné et tente d’accéder à un élément qui se situe au-delà du tableau. Ceci provient de l’utilisation de l’opérateur `<=` à la place de l’opérateur `<` ce qui entraîne un tour de boucle avec `i` qui est égal à 5, alors que le dernier indice du tableau doit être quatre.

[[attention]]
| N’oubliez pas : les indices d’un tableau commencent *toujours* à zéro. En conséquence, les indices valides d’un tableau de $n$ éléments vont de 0 à $n-1$.

# Tableaux et fonctions

## Passage en argument

Étant donné qu’un tableau peut être utilisé comme un pointeur sur son premier élément, lorsque vous passer un tableau en argument d’une fonction, celle-ci reçoit un pointeur vers le premier élément du tableau. Le plus souvent, il vous sera nécessaire de passer également la taille du tableau afin de pouvoir le parcourir.

Le code suivante utilise une fonction pour parcourir un tableau d’entier et afficher la valeur de chacun de ses éléments.

```c
#include <stdio.h>


void affiche_tableau(int *tab, unsigned taille)
{
    unsigned i;

    for (i = 0; i < taille; ++i)
        printf("tab[%u] = %d\n", i, tab[i]);
}


int main(void)
{
    int tab[5] = { 2, 45, 67, 89, 123 };

    affiche_tableau(tab, 5);
    return 0;
}
```

```text
tab[0] = 2
tab[1] = 45
tab[2] = 67
tab[3] = 89
tab[4] = 123
```

[[information]]
| Notez qu’il existe une syntaxe alternative pour déclarer un paramètre de type tableau héritée du langage B (voyez la dernière section).
|
|```c
| void affiche_tableau(int tab[], unsigned taille)
|```
|
| Toutefois, nous vous conseillons de recourir à la première écriture, cette dernière étant plus explicite.

## Retour de fonction

De la même manière que pour le passage en argument, retourner un tableau revient à retourner un pointeur sur le premier élément de celui-ci. Toutefois, n’oubliez pas les problématiques de classe de stockage ! Si vous retournez un tableau de classe de stockage automatique, vous fournissez à la fonction appelante un pointeur vers un objet qui n’existe plus (puisque l’exécution de la fonction appelée est terminée).

```c
#include <stdio.h>


int *tableau(void)
{
    int tab[5] = { 1, 2, 3, 4, 5 };

    return tab;
}


int main(void)
{
    int *p = tableau(); /* Incorrect. */

    printf("%d\n", p[0]);
    return 0;
}
```