Nous vous avons dit qu’une variable de type tableau pouvait être utilisée comme un pointeur constant sur son premier élément. Cependant, ce n’est pas tout à fait vrai.

# Un peu d'histoire

Le prédécesseur du langage C était le langage B. Lorsque le développement du C a commencé, un des objectifs était de le rendre autant que possible compatible avec le B, afin de ne pas devoir (trop) modifier les codes existants (un code écrit en B pourrait ainsi être compilé avec un compilateur C sans ou avec peu de modifications). Or, en B, un tableau se définissait comme suit.

```c
auto tab[3];
```

[[information]]
| Le langage B était un langage non typé, ce qui explique l’absence de type dans la définition. Le mot-clé `auto` (toujours présent en langage C, mais devenu obsolète) servait à indiquer que la variable définie était de classe de stockage automatique.

Toutefois, à la différence du langage C, cette définition créée un tableau de trois éléments *et* un pointeur initialisé avec l’adresse du premier élément. Ainsi, pour créer un pointeur, il suffisait de définir une variable comme un tableau de taille nulle.

```c
auto ptr[];
```

Le langage C, toujours en gestation, avait repris ce mode de fonctionnement. Cependant, les structures sont arrivées et les problèmes avec. En effet, prenez ce bout de code.

```c
#include <stdio.h>

struct exemple {
    int tab[3];
};


struct exemple exemple_init(void)
{
    struct exemple init = { { 1, 2, 3 } };

    return init;
}


int main(void)
{
    struct exemple s = exemple_init();

    printf("%d\n", s.tab[0]);
    return 0;
}
```

La fonction `exemple_init()` retourne une structure qui est utilisée pour initialiser la variable de la fonction `main()`. Dans un tel cas, comme pour n’importe quelle variable, le contenu de la première structure sera intégralement copié dans la deuxième. Le souci, c'est que si une définition de tableau créer un tableau *et* un pointeur initialisé avec l’adresse du premier élément de celui-ci, alors il est nécessaire de modifier le champ `tab` de la structure `s` lors de la copie sans quoi son champ `tab` pointera vers le tableau de la structure `init` (qui n'existera plus puisque de classe de stockage automatique) et non vers le sien. Voilà qui complexifie la copie de structures, particulièrement si sa définition comprend plusieurs tableaux possiblement imbriqués...

Pour contourner ce problème, les concepteurs du langage C ont imaginé une solution (tordue) qui est à l’origine d’une certaine confusion dans l’utilisation des tableaux : une variable de type tableau *ne sera plus un pointeur*, mais sera *convertie en un pointeur sur son premier élément lors de son utilisation*.

# Conséquences de l’absence d’un pointeur

Étant donné qu’il n’y a plus de pointeur alloué, la copie de structures s'en trouve simplifiée et peut être réalisée sans opération particulière (ce qui était l’objectif recherché).

Toutefois, cela entraîne une autre conséquence : il n’est plus possible d’assigner une valeur à une variable de type tableau, seuls ses éléments peuvent se voir affecter une valeur. Ainsi, le code suivant est incorrect puisqu’il n’y a aucun pointeur pour recevoir l’adresse du premier élément du tableau `t2`.

```c
int t1[3];
int t2[3];

t1 = t2; /* Incorrect. */
```

Également, puisqu’une variable de type tableau n’est plus un pointeur, celle-ci n’a pas d’adresse. Dès lors, lorsque l’opérateur `&` est appliqué à une variable de type tableau, le résultat sera l’adresse du premier élément du tableau puisque seuls les éléments du tableau ont une adresse.