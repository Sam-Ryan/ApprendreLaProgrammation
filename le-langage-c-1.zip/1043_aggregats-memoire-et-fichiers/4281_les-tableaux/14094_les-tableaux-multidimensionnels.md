Jusqu’à présent, nous avons travaillés avec des tableaux linéaires, c’est-à-dire dont les éléments se suivaient les uns à la suite des autres. Il s’agit de tableaux dit à une dimension ou **unidimensionnels**.

Cependant, certaines données peuvent être représentées plus simplement sous la forme de tableaux à deux dimensions (autrement dit, organisées en lignes et en colonnes). C’est par exemple le cas des images (non vectorielles) qui sont des matrices de pixels ou, plus simplement, d’une grille de Sudoku qui est organisée en neuf lignes et en neuf colonnes.

Le langage C vous permet de créer et de gérer ce type de tableaux dit **multidimensionnels** (en fait, des tableaux de tableaux) et ce, bien au-delà de deux dimensions.

# Définition

La définition d’un tableau multidimensionnel se réalise de la même manière que celle d’un tableau unidimensionnel si ce n’est que vous devez fournir la taille des différentes dimensions.

Par exemple, si nous souhaitons définir un tableau de `int` de vingt lignes et trente-cinq colonnes, nous procèderons comme suit.

```c
int tab[20][35];
```

De même, pour un tableau de `double` à trois dimensions.

```c
double tab[3][4][5];
```

# Initialisation

## Initialisation avec une longueur explicite

Comme pour les tableaux de structures, l’initialisation d’un tableau multidimensionnel s’effectue à l’aide d’une liste d’initialisation comprenant elle-même des listes d’initialisations.

```c
int t1[2][2] = { { 1, 2 }, { 3, 4 } };
int t2[2][2][2] = { { { 1, 2 }, { 3, 4 } }, { { 5, 6 }, { 7, 8 } } };
```

[[attention]]
| Comme pour les tableaux unidimensionnel, dans le cas où vous ne fournissez pas un nombre suffisant de valeurs, les éléments omis seront initialisés à zéro ou, s’il s’agit de pointeurs, seront des pointeurs nuls.

## Initialisation avec une longueur implicite

Lorsque vous initialisez un tableau multidimensionnel, il vous est permis d’omettre la taille de la *première dimension*. La taille des autres dimensions doit en revanche être spécifiée, le compilateur ne pouvant déduire la taille de toutes les dimensions.

```c
int t1[][2] = { { 1, 2 }, { 3, 4 } };
int t2[][2][2] = { { { 1, 2 }, { 3, 4 } }, { { 5, 6 }, { 7, 8 } } };
```

# Utilisation

Techniquement, un tableau multidimensionnel est un tableau dont les éléments sont eux-mêmes des tableaux. Dès lors, vous avez besoin d’autant d’indices qu’il y a de dimensions. Par exemple, pour un tableau à deux dimensions, vous avez besoin d’un premier indice pour accéder à l’élément souhaité du premier tableau, mais comme cet élément est lui-même un tableau, vous devez utiliser un second indice pour sélectionner un élément de celui-ci. Illustration.

```c
#include <stdio.h>


int main(void)
{
    int tab[2][2] = { { 1, 2 }, { 3, 4 } };

    printf("tab[0][0] = %d\n", tab[0][0]);
    printf("tab[0][1] = %d\n", tab[0][1]);
    printf("tab[1][0] = %d\n", tab[1][0]);
    printf("tab[1][1] = %d\n", tab[1][1]);
    return 0;
}
```

```text
tab[0][0] = 1
tab[0][1] = 2
tab[1][0] = 3
tab[1][1] = 4
```

## Représentation en mémoire

Techniquement, les données d’un tableau multidimensionnel sont stockées les unes à coté des autres en mémoire : elles sont rassemblées dans un tableau à une seule dimension. Si les langages comme le FORTRAN mémorisent les colonnes les unes après les autres (*column-major order* en anglais), le C mémorise les tableaux lignes par lignes (*row-major order*).

![Exemple de tableau en deux dimensions](http://zestedesavoir.com/media/galleries/1501/c089c3ba-416b-4d84-b96e-52a21a6dda56.png.960x960_q85.jpg)

![Column-major order](http://zestedesavoir.com/media/galleries/1501/6a2b8faf-dab4-4404-83fd-68aada78b6d2.png.960x960_q85.jpg)

![Row-major order](http://zestedesavoir.com/media/galleries/1501/a73a2375-5e83-46cd-a090-7729e117e6de.png.960x960_q85.jpg)

Le calcul d’adresse à effectuer est une généralisation du calcul vu au chapitre précédent.

# Parcours

Le même exemple peut être réalisé à l’aide de deux boucles imbriquées afin de parcourir le tableau.

```c
#include <stdio.h>


int main(void)
{
    int tab[2][2] = { { 1, 2 }, { 3, 4 } };
    unsigned i;
    unsigned j;

    for (i = 0; i < 2; ++i)
        for (j = 0; j < 2; ++j)
            printf("tab[%u][%u] = %d\n", i, j, tab[i][j]);

    return 0;
}
```

# Tableaux multidimensionnels et fonctions

## Passage en argument

Souvenez-vous : sauf exceptions, un tableau est converti en un pointeur sur son premier élément. Dès lors, qu’obtenons-nous lors du passage d’un tableau à deux dimensions en argument d’une fonction ? Le premier élément du tableau est un tableau, donc un pointeur sur… Un tableau (*hé* oui). :p

La syntaxe d’un pointeur sur tableau est la suivante.

```text
type (*identificateur)[taille];
```

Vous remarquerez la présence de parenthèses autour du symbole `*` et de l’identificateur afin de signaler au compilateur qu’il s’agit d’un pointeur sur un tableau et non d’un tableau de pointeurs. Également, notez que la taille du tableau référencé doit être spécifiée. En effet, sans celle-ci, le compilateur ne pourrait pas opérer correctement le calcul d’adresses puisqu’il ne connaîtrait pas la taille des éléments composant le tableau référencé par le pointeur.

La même logique peut-être appliquée pour créer des pointeur sur des tableaux de tableaux.

```text
type (*identificateur)[N][M];
```

Et ainsi de suite jusqu’à ce que mort s’en suive… :-°

L’exemple ci-dessous illustre ce qui vient d’être dit en utilisant une fonction pour afficher le contenu d’un tableau à deux dimensions de `int`.

```c
#include <stdio.h>


void affiche_tableau(int (*tab)[2], unsigned n, unsigned m)
{
    unsigned i;
    unsigned j;

    for (i = 0; i < n; ++i)
        for (j = 0; j < m; ++j)
            printf("tab[%u][%u] = %d\n", i, j, tab[i][j]);
}


int main(void)
{
    int tab[2][2] = { { 1, 2 }, { 3, 4 } };

    affiche_tableau(tab, 2, 2);
    return 0;
}
```

## Retour de fonction

Même remarque que pour les tableaux unidimensionnels : attention à la classe de stockage ! Pour le reste, nous vous laissons admirer la syntaxe particulièrement dégoûtante d’une fonction retournant un pointeur sur un tableau de deux `int`.

```c
#include <stdio.h>


int (*tableau(void))[2] /* Ouh ! Que c'est laid ! */
{
    int tab[2][2] = { { 1, 2 }, { 3, 4 } };

    return tab;
}


int main(void)
{
    int (*p)[2] = tableau(); /* Incorrect. */

    printf("%d\n", p[0][0]);
    return 0;
}
```