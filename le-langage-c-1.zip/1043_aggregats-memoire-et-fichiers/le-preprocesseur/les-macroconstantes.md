Comme nous l'avons dit dans l'introduction, le préprocesseur permet la définition de macros, c'est-à-dire de substituts à des morceaux de code. Une macro est constituée des éléments suivants.

 - La directive `#define`.
 - Le nom de la macro qui, par convention, est souvent écrit en majuscules. Notez que vous pouvez choisir le nom que vous voulez, à condition de respecter les mêmes règles que pour les noms de variable ou de fonction.
 - Une liste *optionnelle* de paramètres.
 - La définition, c'est-à-dire le code par lequel la macro sera remplacée.

Dans le cas particulier où la macro n'a pas de paramètre, on parle de __macroconstante__ (ou constante de préprocesseur). Leur substitution donne toujours le même résultat (d'où l'adjectif « constante »).

# Substitutions de constantes

Par exemple, pour définir une macroconstante `TAILLE` avec pour valeur `100`, nous utiliserons le code suivant.

```c
#define TAILLE 100
```

L'exemple qui suit utilise cette macroconstante afin de ne pas multiplier l'usage de constantes entières. À chaque fois que la macroconstante `TAILLE` est utilisée, le préprocesseur remplacera celle-ci par sa définition, à savoir `100`.

```c
#include <stdio.h>
#define TAILLE 100

int main(void)
{
    int variable = 5;

    /* On multiplie par TAILLE */
    variable *= TAILLE;
    printf("Variable vaut : %d\n", variable);

    /* On additionne TAILLE */
    variable += TAILLE;
    printf("Variable vaut : %d\n", variable);
    return 0;
}
```

Ce code sera remplacé, après le passage du préprocesseur, par celui ci-dessous.

```c
int main(void)
{
    int variable = 5;

    variable *= 100;
    printf("Variable vaut : %d\n", variable);
    variable += 100;
    printf("Variable vaut : %d\n", variable);
    return 0;
}
```

Nous n'avons pas inclus le contenu de `<stdio.h>` car celui-ci est trop long et trop compliqué pour le moment. Néanmoins, l'exemple permet d'illustrer le principe des macros et surtout de leur avantage : il suffit de changer la définition de la macroconstante `TAILLE` pour que le reste du code s'adapte.

[[question]]
| D'accord, mais je peux aussi très bien utiliser une variable constante, non ?

Dans certains cas (comme dans l'exemple ci-dessus), utiliser une variable constante donnera le même résultat. Toutefois, une variable nécessitera le plus souvent de réserver de la mémoire et, si celle-ci doit être partagée par différents fichiers, de jouer avec les déclarations et les définitions.

De plus, les macroconstantes peuvent être employées pour définir la longueur d'un tableau, alors que ceci est impossible avec une variable, même constante.

[[information]]
| Notez qu'il vous est possible de définir une macroconstante lors de la compilation à l'aide de l'option `-D`.
|
|```text
| zcc -DTAILLE=100
|```
|
| Ceci recient à définir une macroconstante `TAILLE` au début de chaque fichier qui sera substituée par `100`.

# Substitutions d'instructions

Si les macroconstantes sont souvent utilisées en vue de substituer des constantes, il est toutefois aussi possible que leur définition comprenne des suites d'instructions. L'exemple ci-dessous défini une macroconstante `BONJOUR` qui sera remplacée par `puts("Bonjour !")`.

```c
#include <stdio.h>

#define BONJOUR  puts("Bonjour !")

int main(void)
{
    BONJOUR;
    return 0;
}
```

Notez que nous n'avons pas placé de point-virgule dans la définitions de la macroconstante, tout d'abord afin de pouvoir en placer un lors de son utilisation, ce qui est plus naturel et, d'autre part, pour éviter des doublons qui peuvent s'avérer facheux.

En effet, si nous ajoutons un point virgule à la fin de la définition, il ne faut pas en rajouter un lors de l'appel, sous peine de risquer des erreurs de syntaxe.

```c
#include <stdio.h>

#define BONJOUR puts("Bonjour !");
#define AUREVOIR puts("Au revoir !");

int main(void)
{
    if (1)
        BONJOUR; /* erreur ! */
    else
        AUREVOIR;

    return 0;
}
```

Le code donnant en réalité ceci.

```c
int main(void)
{
    if (1)
        puts("Bonjour !");;
    else
        puts("Au revoir !");;

    return 0;
}
```

Ce qui est incorrect. Pour faire simple : le corps d'une condition ne peut comprendre qu'une instruction, or `puts("Bonjour !");` en est une, le point-virgule seul (`;`) en est une autre. Dès lors, il y a une instruction entre le `if` et le `else`, ce qui n'est pas permis. L'exemple ci-dessous pose le même problème en étant un peu plus limpide.

```c
#include <stdio.h>


int main(void)
{
    if (1)
        puts("Bonjour !");

    puts("Je suis une instruction mal placee !");

    else
        puts("Au revoir !");

    return 0;
}
```

# Macros dans d'autres macros

La définition d'une macro peut parfaitement comprendre une ou plusieurs autres macros (qui, à leur tour, peuvent également comprendre des macros dans leur définition et ainsi de suite). L'exemple suivant illustre ceci en définissant une macroconstante `NB_PIXELS` correspondant à la multiplication entre les deux macrococonstantes `LONGUEUR` et `HAUTEUR`.

```c
#define LONGUEUR 1024
#define HAUTEUR 768
#define NB_PIXELS (LONGUEUR * LARGEUR)
```

La règle suivante permet d'éviter de répéter les opérations de remplacement « à l'infini » :

[[erreur]]
| Une macro n'est pas substituée si elle est utilisée dans sa propre définition.

Ainsi, dans le code ci-dessous, `LONGUEUR` donnera `LONGUEUR * 2 / 2` et `HAUTEUR` sera substituée par `HAUTEUR / 2 * 2`. En effet, lors de la substitution de la macroconstante `LONGUEUR`, la macroconstante `HAUTEUR` est remplacée par sa définition : `LONGUEUR * 2`. Or, comme nous sommes en train de substituer la macroconstante `LONGUEUR`, `LONGUEUR` sera laissé tel quel. Le même raisonnement peut être appliqué pour la macroconstante `HAUTEUR`.

```c
#define LONGUEUR (HAUTEUR / 2)
#define HAUTEUR (LONGUEUR * 2)
```

# Définition sur plusieurs lignes

La définition d'une macro doit normalement tenir sur une seule ligne. C'est-à-dire que dès que la fin de ligne est atteinte, la définition est considérée comme terminée. Ainsi, dans le code suivant, la définition de la macroconstante `BONJOUR_AUREVOIR` ne comprend en fait que `puts("Bonjour");`.

```c
#define BONJOUR_AUREVOIR puts("Bonjour");
puts("Au revoir")
```

Pour que cela fonctionne, nous sommes donc contraints de la rédiger comme ceci.

```c
#define BONJOUR_AUREVOIR puts("Bonjour"); puts("Au revoir")
```

Ce qui est assez peu lisible et peu pratique si notre définition doit comporter une multitude d'instructions ou, pire, des blocs d'instructions... Heureusement, il est possible d'indiquer au préprocesseur que plusieurs lignes doivent être fusionnées. Cela se fait à l'aide du symbole `\`, que nous placons en fin de ligne.

```c
#define BONJOUR_AUREVOIR puts("Bonjour");\
puts("Au revoir")
```

Lorsque le préprocesseur rencontre une barre oblique inverse (`\`) suivie d'une fin de ligne, celles-ci sont supprimées et la ligne qui suit est fusionnée avec la ligne courante.

[[attention]]
| Notez bien qu'*aucun espace* n'est ajouté durant l'opération !
|
|```c
| #define BONJOUR_AUREVOIR\
| puts("Bonjour");\
| puts("Au revoir")
|```
|
| Le code ci-dessus est donc incorrect car il donne en vérité ceci.
|
|```c
| #define BONJOUR_AUREVOIRputs("Bonjour");puts("Au revoir")
|```

[[information]]
| L'utilisation de la fusion ne se limite pas aux définitions de macros, il est possible de l'employer n'importe où dans le code source. Bien que cela ne soit pas obligatoire (une instruction pouvant être répartie sur plusieurs lignes), il est possible d'y recourir pour couper une ligne un peu trop longue tout en indiquant cette césure de manière claire.
|
|```c
|printf("Une phrase composée de plusieurs résultats à présenter : %d, %f, %f, %d, %d\n",\
|a, b, c, d, e, f);
|```

Si vous souhaitez inclure un bloc d'instructions au sein d'une définition, ne perdez pas de vue que celui-ci constitue une instruction et donc que vous retomberez sur le problème exposé plus haut.

```c
#include <stdio.h>

#define BONJOUR\
    {\
        puts("Bonjour !");\
    }
#define AUREVOIR\
    {\
        puts("Au revoir !");\
    }

int main(void)
{
    if (1)
        BONJOUR; /* erreur ! */
    else
        AUREVOIR;

    return 0;
}
```

Une solution fréquente à ce problème consiste à recourir à une boucle `do {} while` avec une condition nulle (de sorte qu'elle ne soit exécutée qu'une seule fois), celle-ci ne constituant qu'une seule instruction *avec* le point-virgule final.

```c
#include <stdio.h>

#define BONJOUR\
    do {\
        puts("Bonjour !");\
    } while(0)
#define AUREVOIR\
    do {\
        puts("Au revoir !");\
    } while(0)

int main(void)
{
    if (1)
        BONJOUR; /* ok */
    else
        AUREVOIR;

    return 0;
}
```

## Définition nulle

Sachez que le corps d'une macro peut parfaitement être vide.

```c
#define MACRO
```

Dans un tel cas, la macro ne sera tout simplement pas substituée par quoi que ce soit. Bien que cela puisse paraître étrange, cette technique est souvent utilisée, notamment pour la compilation conditionnelle que nous verrons bientôt.

# Annuler une définition

Enfin, une définition peut être annulée à l'aide de la directive `#undef` en lui spécifiant le nom de la macro qui doit être détruite.

```c 
#define TAILLE 100
#undef TAILLE

/* TAILLE n'est à présent plus utilisable. */
```