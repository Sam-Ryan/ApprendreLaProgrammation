Le préprocesseur dispose de cinq directives conditionnelles : `#if`, `#ifdef`, `#ifndef`, `#elif` et `#else`. Ces dernières permettent de conserver ou non une potion de code en fonction de la validité d'une condition (si la condition est vraie, le code est gardé sinon il est passé). Chacune de ces directives (ou suite de directives) doit être terminée par une directive `#endif`.

# Les directives #if, #elif et #else

## Les directives #if et #elif

Les directives `#if` et `#elif`, comme l'instruction `if`, attendent une expression conditionelle ; toutefois, celle-ci sont plus restreintes étant donné que nous sommes dans le cadre du préprocesseur. Ce dernier se contentant d'effectuer des substitutions, il n'a par exemple aucune connaissance des mots-clés du langage C ou des variables qui sont employées.

Ainsi, les conditions ne peuvent comporter que des expressions *entières* (ce qui exclut les nombres flottants et les pointeurs) et *constantes* (ce qui exclut l'utilisation d'opérateurs à effets de bord comme `=`). Aussi, les mots-clés et autres identificateurs (hormis les macros) présent dans la définition *sont ignorés* (plus précisément, ils sont remplacés par `0`).

L'exemple ci-dessous explicite ceci.

```c
#if 1.89 > 1.88 /* Incorrect, ce ne sont pas des entiers */
#if sizeof(int) == 4 /* Équivalent à 0(0) == 4, `sizeof' et `int' étant des mots-clés */
#if (a = 20) == 20 /* Équivalent à (0 = 20) == 4, `a' étant un identificateur */
```

Techniquement, seuls les opérateurs suivant peuvent être utilisés : `+` (binaire ou unaire), `-` (binaire ou unaire), `*`, `/`, `%`, `==`, `!=`, `<=`, `<`, `>`, `>=`, `!`, `&&`, `||`, `,`, l'opérateur ternaire et les opérateurs de manipulations des *bits*, que nous verrons au chapitre suivant.

[[information]]
| Bien entendu, vous pouvez également utiliser des parenthèses afin de régler la priorité des opérations.

### L'opérateur defined

Le préprocesseur fourni un opérateur supplémentaire utilisable dans les condtions : `defined`. Celui-ci prend comme opérande un nom de macro et retourne 1 ou 0 suivant que ce nom correspond ou non à une macro définie.

```c
#if defined TAILLE
```

Celui-ci est fréquemment utilisé pour produire des programmes portables. En effet, chaque système et chaque compilateur définissent généralement une ou des macroconstantes qui lui sont propres propre. En vérifiant si une de ces constantes existe, nous pouvons déterminer sur quelle plate-forme et avec quel compilateur nous compilons et adapter le code en conséquence.

[[attention]]
| Notez que ces constantes sont propres à un système d'exploitation et/ou compilateur donné, elles ne sont donc pas spécifiées par la norme du langage C.

## La directive #else

La directive `#else` quant à elle, se comporte comme l'instruction éponyme.

## Exemple

Voici un exemple d'utilisation.

```c
#include <stdio.h>

#define A 2

int main(void)
{
#if A < 0
    puts("A < 0");
#elif A > 0
    puts("A > 0");
#else
    puts("A == 0");
#endif
    return 0;
}
```

```text
A > 0
```

[[information]]
| Notez que les directives conditionnelles peuvent être utilisées à la place des commentaires en vue d'empêcher la compilation d'un morceau de code. L'avantage de cette technique par rapport aux commentaires est qu'elle vous évite de produire des commentaires imbriqués.
|
|```c
| #if 0
| /* On multiplie par TAILLE */
| variable *= TAILLE;
| printf("Variable vaut : %d\n", variable);
| #endif
|```

# Les directives #ifdef et #ifndef

Ces deux directives sont en fait la contraction, respectivement, de la directive `#if defined` et `#if !defined`. Si vous n'avez qu'une seule constante à tester, il est plus rapide d'utiliser ces deux directives à la place de leur version longue.

## Protection des fichiers d'en-tête

Ceci étant dit, vous devriez à présent être en mesure de comprendre le fonctionnement des directives jusqu'à présent utilisées dans les fichiers en-têtes.

```c
#ifndef CONSTANTE_H
#define CONSTANTE_H

/* Les déclarations */

#endif
```

La première directive vérifie que la macroconstante CONSTANTE_H n'a pas encore été définie. Si ce n'est pas le cas, elle est définie (ici avec une valeur nulle) et le bloc de la condition (comprenant le contenu du fichier d'en-tête) est inclus. Si elle a déjà été définie, le bloc est sauté et le contenu du fichier n'est ainsi pas à nouveau inclus.

[[information]]
| Pour rappel, ceci est nécessaire pour éviter des problèmes d'inclusions multiples, par exemple lorsqu'un fichier A inclut un fichier B, qui lui-même inclut le fichier A.