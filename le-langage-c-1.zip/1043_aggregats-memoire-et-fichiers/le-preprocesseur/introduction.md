Le **préprocesseur** est un programme qui réalise des traitements sur le code source *avant* que ce dernier ne soit réellement compilé. Globalement, il a trois grands rôles :

* réaliser des **inclusions** (la fameuse directive `#include`) ;
* définir des **macros** qui sont des substituts à des morceaux de code. Après le passage du préprocesseur, tous les appels à ces macros seront remplacés par le code associé ;
* permettre la **compilation conditionnelle**, c'est-à-dire de moduler le contenu d'un fichier source suivant certaines conditions.