Pour l'instant, nous n'avons manipulé que des macroconstantes, c'est-à-dire des macros n'employant pas de paramètres. Comme vous vous en doutez, une **macrofonction** est une macro qui accepte des paramètres et les emploie dans sa définition.

```c
#define MACRO(paramètre, autre_paramètre) définition
```

Pour ce faire, le nom de la macro est suivi de parenthèses comprenant le nom des paramètres séparés par une virgule. Chacun d'eux peut ensuite être utilisé dans la définition de la macrofonction et sera remplacé par la suite fournie en argument lors de l'appel à la macrofonction.

[[erreur]]
| Notez bien que nous n'avons pas parlé de « valeur » pour les arguments. En effet, n'importe quelle suite de symboles peut-être passée en argument d'une macrofonction, y compris du code. C'est d'ailleurs ce qui fait la puissance du préprocesseur.

Illustrons ce nouveau concept avec un exemple : nous allons écrire deux macros : `EUR` qui convertira une somme en euro en francs (français) et `FRF` qui fera l'inverse. Pour rappel, un euro équivaut à 6,55957 francs français.

[[secret]]
|```c
|#include <stdio.h>
|
|#define EUR(x) ((x) / 6.55957)
|#define FRF(x) ((x) * 6.55957)
|
|int main(void)
|{
|    printf("Dix francs français valent %f euros.\n", EUR(10));
|    printf("Dix euros valent %f francs français.\n", FRF(10));
|    return 0;
|}
|```
|
|```text
|Dix francs français valent 1.524490 euros.
|Dix euros valent 65.595700 francs français.
|```

Appliquons encore ce concept avec un deuxième exercice : essayez de créer la macro `MIN` qui renvoie le minimum entre deux nombres.

[[secret]]
|```c
|#include <stdio.h>
|
|#define MIN(a, b)  ((a) < (b) ? (a) : (b))
|
|int main(void)
|{
|    printf("Le minimum entre 16 et 32 est %d.\n", MIN(16, 32));
|    printf("Le minimum entre 2+9+7 et 3*8 est %d.\n", MIN(2+9+7, 3*8));
|    return 0;
|}
|```
|
|```text
| Le minimum entre 16 et 32 est 16.
| Le minimum entre 2+9+7 et 3*8 est 18.
|```
|
|[[information]]
||Remarquez que nous avons utilisés des expressions composées lors de la deuxième utilisation de la macrofonction `MIN`.


# Priorité des opérations

Quelque chose vous a peut-être frappé dans les corrections : pourquoi écrire ```(x)``` et pas simplement ```x``` ? 

En fait, il s'agit d'une protection en vue d'éviter certaines ambiguïtés. En effet, si l'on n’y prend pas garde, on peut par exemple avoir des surprises dues à la priorité des opérateurs. Prenons l'exemple d'une macro `MUL` qui effectue une multiplication.

```c
#define MUL(a, b)  (a * b)
```

Tel quel, le code peut poser des problèmes. En effet, si nous appellons la macrofonction comme ceci.

```c
MUL(2+3, 4+5)
```

Nous obtenons comme résultat 19 (la macro sera remplacée par ```2 + 3 * 4 + 5```) et non 45, qui est le résultat attendu. Pour garantir la bonne marche de la macrofonction, nous devons rajouter des parenthèses.

```c
#define MUL(a, b)  ((a) * (b))
```

Dans ce cas, nous obtenons bien le résultat souhaité, c'est-à-dire 45 (```(2 + 3) * (4 + 5)```).

[[information]]
| Nous vous conseillons de rajouter des parenthèses en cas de doute pour éviter toute erreur.

# Les effets de bords

Pour finir, une petite mise en garde : évitez d'utiliser plus d'une fois un paramètre dans la définition d'une macro en vue d'éviter de multiplier d'éventuels **effets de bord**.

[[question]]
| Des effets de quoi ?

Un effet de bord est une modification du contexte d'exécution. Vous voilà bien avancé nous direz-vous... En fait, vous en avez déjà rencontré, l'exemple le plus typique étant une affectation.

```c
a = 10;
```

Dans cet exemple, le contexte d'exécution du programme (qui comprends ses variables) est modifié puisque la valeur d'une variable est changée. Ainsi, imaginez que la macro `MUL` soit appelée comme suit.

```c
MUL(a = 10, a = 20)
```

Après remplacement, celle-ci donnerait l'expression suivante : `((a = 10) * (a = 20))` qui est assez problématique... En effet, quelle sera la valeur de `a`, finalement ? 10 ou 20 ? Ceci est impossible à dire sans fixer une règle d'évaluation et... la norme n'en prévoit aucune dans ce cas ci. :-°

Aussi, pour éviter ce genre de problèmes tordus, veillez à n'utiliser chaque paramètre qu'*une seule fois*.