Nous avons vu dès le début du cours comment inclure des fichiers d'en-tête avec la directive ```#include```, sans toutefois véritablement expliquer son rôle. Son but est très simple : inclure le contenu d'un fichier dans un autre. Ainsi, si nous nous retrouvons par exemple avec deux fichiers comme ceux-ci avant la compilation.

```c
/* Fichier d'en-tête fichier.h */

#ifndef FICHIER_H
#define FICHIER_H

extern int glob_var;

extern void f1(int);
extern long f2(double, char);

#endif
```
```c
/* Fichier source fichier.c */

#include "fichier.h"

void f1(int arg)
{
    /* du code */
}

long f2(double arg, char c)
{
    /* du code */
}
```

Après le passage du préprocesseur et avant la compilation à proprement parler, le code obtenu sera le suivant :

```c
/* Fichier source fichier.c */

extern int glob_var;

extern void f1(int arg);
extern long f2(double arg, char c);

void f1(int arg)
{
    /* du code */
}

long f2(double arg, char c)
{
    /* du code */
}
```

Nous pouvons voir que les déclarations contenues dans le fichier « fichier.h » ont été incluses dans le fichier « fichier.c » et que toutes les directives du préprocesseur (les lignes commençant par le symbole `#`) ont disparu. 

[[information]]
| Vous pouvez utiliser l'option `-E` lors de la compilation pour requérir uniquement l'utilisation du préprocesseur. Ainsi, vous pouvez voir ce que donne votre code *après* son passage.
|
|```sh
|$ zcc -E fichier.c
|```