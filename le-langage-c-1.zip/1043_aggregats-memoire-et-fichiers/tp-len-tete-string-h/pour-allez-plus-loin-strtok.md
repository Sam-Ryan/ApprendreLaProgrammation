Pour les plus aventureux d'entre-vous, nous vous proposons de réaliser en plus la mise en œuvre de la fonction `strtok()` qui est un peu plus complexe que ses congénères. :)

```c
char *strtok(char *chaine, char *liste);
```

La fonction `strtok()` est un peu particulière : elle divise la chaîne `chaine` en une suite de sous-chaînes délimitée par *un* des caractères présent dans la chaîne `liste`. En fait, cette dernière remplace les caractères de la chaîne `liste` par des caractères nuls dans la chaîne `chaine` (elle modifie donc la chaîne `chaine` !) et renvoie les différentes sous-chaînes ainsi créées au fur et à mesure de ses appels.

Lors des appels subséquents, la chaîne `chaine` doit être un pointeur nul afin de signaler à `strtok()` que nous souhaitons la sous-chaîne suivante. S’il n’y a plus de sous-chaîne ou qu’aucun caractère de la chaîne `liste` n’est trouvé, celle-ci retourne un pointeur nul.

L’exemple ci-dessous tente de scinder la chaîne « un, deux, trois » en trois sous-chaînes.

```c
#include <stddef.h>
#include <stdio.h>
#include <string.h>


int main(void)
{
    char chaine[] = "un, deux, trois";
    char *p;
    unsigned i;

    p = strtok(chaine, ", ");

    for (i = 0; p != NULL; ++i)
    {
        printf("%u : %s\n", i, p);
        p = strtok(NULL, ", ");
    }

    return 0;
}
```

```text
0 : un
1 : deux
2 : trois
```

La fonction `strtok()` étant un peu plus complexe que les autres, voici une petite marche à suivre pour réaliser cette fonction.

* regarder si la chaîne fournie (ou la sous-chaîne suivante) contient, *à son début*, des caractères présent dans la seconde chaîne. Si oui, ceux-ci doivent être passés ;
* si la fin de la (sous-)chaîne est atteinte, retourner un pointeur nul ;
* parcourir la chaîne fournie (ou la sous-chaîne courante) jusqu’à rencontrer un des caractères composant la seconde chaîne. Si un caractère est rencontré, le remplacer par un caractère nul, conserver la position actuelle dans la chaîne et retourner la sous-chaîne ainsi créée (*sans* les éventuels caractères passés au début) ;
* si la fin de la (sous-)chaîne est atteinte, retourner la (sous-)chaîne (*sans* les éventuels caractères passés au début).

[[information]]
| Vous aurez besoin d’une variable de classe de stockage statique pour réaliser cette fonction. Également, l’instruction `goto` pourra vous être utile.

# Correction

[[secret]]
|```c
| char *xstrtok(char *chaine, char *liste)
| {
|     static char *dernier;
|     char *base = (chaine != NULL) ? chaine : dernier;
|     char *s;
|     char *t;
| 
|     if (base == NULL)
|         return NULL;
| 
| separateur_au_debut:
|     for (t = liste; *t != '\0'; ++t)
|         if (*base == *t)
|         {
|             ++base;
|             goto separateur_au_debut;
|         }
| 
|     if (*base == '\0')
|     {
|         dernier = NULL;
|         return NULL;
|     }
| 
|     for (s = base; *s != '\0'; ++s)
|         for (t = liste; *t != '\0'; ++t)
|             if (*s == *t)
|             {
|                 *s = '\0';
|                 dernier = s + 1;
|                 return base;
|             }
| 
|     dernier = NULL;
|     return base;
| }
|```