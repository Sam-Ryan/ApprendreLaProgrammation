Bien, l'heure de la correction est venue. :pirate:

# strlen

[[secret]]
|```c
| size_t xstrlen(char *chaine)
| {
|     size_t i;
|
|     for (i = 0; chaine[i] != '\0'; ++i)
|         ;
|
|     return i;
|}
|```

# strcpy

[[secret]]
|```c
| char *xstrcpy(char *destination, char *source)
| {
|     size_t i;
|
|     for (i = 0; source[i] != '\0'; ++i)
|         destination[i] = source[i];
|
|     destination[i] = '\0' /* N'oubliez pas le caractère nul final ! */
|     return destination;
| }
|```

# strcat

[[secret]]
|```c
| char *xstrcat(char *destination, char *source)
| {
|     size_t i;
|
|     while (*destination != '\0')
|         ++destination;
|
|     for (i = 0; source[i] != '\0'; ++i)
|         destination[i] = source[i];
|
|     destination[i] = '\0'; /* N'oubliez pas le caractère nul final ! */
|     return destination;
| }
|```   

# strcmp

[[secret]]
|```c
| int xstrcmp(char *chaine1, char *chaine2)
| {
|     while (*chaine1 == *chaine2)
|     {
|         if (*chaine1 == '\0')
|             return 0;
|
|         ++chaine1;
|         ++chaine2;
|     }
|
|     return (*chaine1 < *chaine2) ? -1 : 1;
| }
|```

# strchr

[[secret]]
|```c
| char *xstrchr(char *chaine, int ch)
| {
|     while (*chaine != '\0')
|         if (*chaine == ch)
|             return chaine;
|         else
|             ++chaine;
|
|     return NULL;
| }
|```

# strpbrk

[[secret]]
|```c
| char *xstrpbrk(char *chaine, char *liste)
| {
|     while (*chaine != '\0')
|     {
|         char *p = liste;
|
|         while (*p != '\0')
|         {
|             if (*chaine == *p)
|                 return chaine;
|
|             ++p;
|         }
|
|         ++chaine;
|     }
|
|     return NULL;
| }
|```

# strstr

[[secret]]
|```c
| char *xstrstr(char *chaine1, char *chaine2)
| {
|     while (*chaine1 != '\0')
|     {
|         char *s = chaine1;
|         char *t = chaine2;
| 
|         while (*s != '\0' && *t != '\0')
|         {
|             if (*s != *t)
|                 break;
|       
|             ++s;
|             ++t;
|         }
| 
|         if (*t == '\0')
|             return chaine1;
|
|         ++chaine1;
|     }
| 
|     return NULL;
| }
|```