Dans le chapitre précédent, nous vous avons dit qu’une chaîne de caractères se manipulait comme un tableau, à savoir en parcourant ses éléments un à un. Cependant, si cela s’arrêtait là, cela serait assez gênant. En effet, la moindre opération sur une chaîne nécessiterait d’accéder à ses différents éléments, que ce soit une modification, une copie, une comparaison, etc. Heureusement pour nous, la bibliothèque standard fourni une suite de fonction nous permettant de réaliser plusieurs opérations de base sur des chaînes de caractères. Ces fonctions sont déclarées dans l’en-tête `<string.h>`.

L’objectif de ce TP sera de réaliser une version pour chacune des fonctions de cet en-tête qui vont vous êtes présentées. :)

# strlen

```c
size_t strlen(char *chaine);
```

La fonction `strlen()` vous permet de connaître la taille d’une chaîne fournie en argument. Celle-ci retourne une valeur de type `size_t`. Notez bien que la longueur retournée ne comprend *pas* le caractère nul. L’exemple ci-dessous affiche la taille de la chaîne « Bonjour ».

```c
#include <stdio.h>
#include <string.h>


int main(void)
{
    printf("Longueur : %u\n", (unsigned)strlen("Bonjour"));
    return 0;
}
```

```text
Longueur : 7
```

# strcpy

```c
char *strcpy(char *destination, char *source);
```

La fonction `strcpy()` copie le contenu de la chaîne `source` dans la chaîne `destination`, caractère nul compris. La fonction retourne l’adresse de `destination`. L’exemple ci-dessous copie la chaîne « Au revoir » dans la chaîne `chaine`.

```c
#include <stdio.h>


int main(void)
{
    char chaine[25] = "Bonjour\n";

    strcpy(chaine, "Au revoir");
    printf("%s\n", chaine);
    return 0;
}
```

```text
Au revoir
```

[[erreur]]
| La fonction `strcpy()` n’effectue *aucune* vérifications. Vous devez donc vous assurer que la chaîne de destination dispose de suffisamment d’espace pour accueillir la chaîne qui doit être copiée (caractère nul compris !).

# strcat

```c
char *strcat(char *destination, char *source);
```

La fonction `strcat()` ajoute le contenu de la chaine `source` à celui de la chaîne `destination`, caractère nul compris. La fonction retourne l’adresse de `destination`. L’exemple ci-dessous ajoute la chaîne « tout le monde » au contenu de la chaîne `chaine`.

```c
#include <stdio.h>
#include <string.h>


int main(void)
{
    char chaine[25] = "Bonjour";

    strcat(chaine, " tout le monde");
    printf("%s\n", chaine);
    return 0;
}
```

```text
Bonjour tout le monde
```

[[erreur]]
| Comme `strcpy()`, la fonction `strcat()` n’effectue *aucune* vérifications. Vous devez donc vous assurer que la chaîne de destination dispose de suffisamment d’espace pour accueillir la chaîne qui doit être ajoutée (caractère nul compris !).

# strcmp

```c
int strcmp(char *chaine1, char *chaine2);
```

La fonction `strcmp()` compare deux chaines de caractères. Cette fonction retourne :

* une valeur positive si la première chaîne est « plus grande » que la seconde ;
* zéro si elles sont égales ;
* une valeur négative si la seconde chaîne est « plus grande » que la première.

[[information]]
| Ne vous inquiétez pas au sujet des valeurs positives et négatives, nous y reviendront en temps voulu lorsque nous aborderons les notions de jeux de caractères et d’encodages dans la troisième partie du cours. En attendant, effectuez simplement une comparaison entre les deux caractères qui diffèrent.

```c
#include <stdio.h>
#include <string.h>


int main(void)
{
    char chaine1[] = "Bonjour";
    char chaine2[] = "Au revoir";

    if (strcmp(chaine1, chaine2) == 0)
        printf("Les deux chaînes sont identiques\n");
    else
        printf("Les deux chaînes sont différentes\n");

    return 0;
}
```

```text
Les deux chaînes sont différentes
```

# strchr

```c
char *strchr(char *chaine, int ch);
```

La fonction `strchr()` recherche la présence du caractère `ch` dans la chaîne `chaine`. Si celui-ci est rencontré, la fonction retourne l’adresse de la première occurrence de celui-ci au sein de la chaîne. Dans le cas contraire, la fonction renvoie un pointeur nul.

```c
#include <stddef.h>
#include <stdio.h>
#include <string.h>


int main(void)
{
    char chaine[] = "Bonjour";
    char *p;
    
    p = strchr(chaine, 'o');

    if (p != NULL)
        printf("La chaîne `%s' contient la lettre %c\n", chaine, *p);

    return 0;
}
```

```text
La chaîne `Bonjour' contient la lettre o
```

# strpbrk

```c
char *strpbrk(char *chaine, char *liste);
```

La fonction `strpbrk()` recherche la présence *d’un* des caractères de la chaîne `liste` dans la chaîne `chaine`. Si un de ceux-ci est rencontré, la fonction retourne l’adresse de la première occurrence au sein de la chaîne. Dans le cas contraire, la fonction renvoie un pointeur nul.

```c
#include <stddef.h>
#include <stdio.h>
#include <string.h>


int main(void)
{
    char chaine[] = "Bonjour";
    char *p;
    
    p = strpbrk(chaine, "aeiouy");

    if (p != NULL)
        printf("La première voyelle de la chaîne `%s' est : %c\n", chaine, *p);

    return 0;
}
```

```text
La première voyelle de la chaîne `Bonjour' est : o
```

# strstr

```c
char *strstr(char *chaine1, char *chaine2);
```

La fonction `strstr()` recherche la présence de la chaîne `chaine2` dans la chaîne `chaine1`. Si celle-ci est rencontrée, la fonction retourne l’adresse de la première occurrence de celle-ci au sein de la chaîne. Dans le cas contraire, la fonction renvoie un pointeur nul.

```c
#include <stddef.h>
#include <stdio.h>
#include <string.h>


int main(void)
{
    char chaine[] = "Bonjour";
    char *p;

    p = strstr(chaine, "jour");

    if (p != NULL)
        printf("La chaîne `%s' contient la chaîne `%s'\n", chaine, p);

    return 0;
}
```

```text
La chaîne `Bonjour' contient la chaîne `jour'
```

Ceci étant dit, à vous de jouer. ;)

[[information]]
| Par convention, nous commencerons le nom de nos fonctions par la lettre « x » afin d’éviter des collisions avec ceux de l’en-tête `<string.h>`.