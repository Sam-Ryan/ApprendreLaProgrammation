S'il est possible d'afficher et récupérer une chaîne de caractères, il est également possible de lire depuis une chaîne et d'écrire dans une chaîne. À cette fin, deux fonctions qui devraient vous sembler familières existent : `sprintf()` et `sscanf()`.

# La fonction sprintf

```c
int sprintf(char *chaine, char *format, ...);
```

[[information]]
| Les trois petits points à la fin du prototype de la fonction signifient que celle-ci attend un nombre variable d’arguments. Nous verrons ce mécanisme plus en détail dans la troisième partie du cours.

La fonction `sprintf()` est identique à la fonction `printf()` mise à part que celle-ci écrit les données produites dans une chaîne de caractères au lieu de les afficher à l’écran. Celle-ci retourne le nombre de caractères écrit (sans compter le caractère nul final !) ou bien un nombre négatif en cas d’erreur. 

Cette fonction peut vous permettre, entre autres, d'écrire un nombre dans une chaîne de caractères.

```c
#include <stdio.h>

int main(void)
{
    char chaine[16];
    int n = 64;

    sprintf(chaine, "%d", n);
    printf("%s\n", chaine);
    return 0;
}
```

```text
64
```

[[attention]]
| La fonction `sprintf()` n’effectue *aucune* vérification quant à la taille de la chaîne de destination, vous devez donc vous assurer qu’elle dispose de suffisamment de place pour accueillir la chaîne finale (caractère nul compris !).

Comment dès lors s’assurer qu’il n’y aura aucun débordement ? Malheureusement, il n’est pas possible de spécifier une taille comme avec l’indicateur `s` de la fonction `scanf()`, aussi, deux solutions s’offrent à vous :

* vérifier que le nombre en question ne dépasse pas un certain seuil ;
* compter la quantité de chiffres composant le nombre avant d’appeler `sprintf()`.

Ainsi, l’exemple ci-dessous ne pose pas de problèmes puisque nous savons que si le nombre est inférieur ou égal à 999 999 999, il n’excèdera pas neuf caractères (*n’oubliez pas de compter le caractère nul final !*).

```c
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    char chaine[10];
    long n;

    printf("Entrez un nombre : ");

    if (scanf("%ld", &n) != 1 || n > 999999999L)
    {
        printf("Erreur lors de la saisie\n");
        return EXIT_FAILURE;
    }

    sprintf(chaine, "%ld", n);
    printf("%s\n", chaine);
    return 0;
}
```

```text
Entrez un nombre : 890765456789
Erreur lors de la saisie

Entrez un nombre : 5678
5678
```

# La fonction sscanf

```c
int sscanf(char *chaine, char *format, ...);
```

La fonction `sscanf()` est identique à la fonction `scanf()` si ce n’est que celle-ci extrait les données depuis une chaîne de caractères plutôt qu’en provenance d’une saisie de l’utilisateur. Cette dernière retourne le nombre de conversions réussies *ou* un nombre inférieur si elles n’ont pas toutes été réalisées *ou* enfin un nombre négatif en cas d’erreur.

Voici un exemple d’utilisation.

```c
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    char chaine[10];
    int n;

    if (sscanf("5 abcd", "%d %9s", &n, chaine) != 2)
    {
        printf("Erreur lors de l'examen de la chaîne\n");
        return EXIT_FAILURE;
    }

    printf("%d %s\n", n, chaine);
    return 0;
}
```

```text
5 abcd
```

[[information]]
| Notez que la fonction `sscanf()` ne souffre pas du même problème que `scanf()` en ce qui concerne de potentiels caractères non lus, nous y reviendrons un peu plus tard.