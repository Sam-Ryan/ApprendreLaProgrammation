Pour terminer cette partie théorique sur une note un peu plus légère, sachez que la bibliothèque standard fournie un en-tête `<ctype.h>` qui permet de classifier les caractères. Onze fonctions sont ainsi définies.

```c
int isalnum(int c);
int isalpha(int c);
int iscntrl(int c);
int isdigit(int c);
int isgraph(int c);
int islower(int c);
int isprint(int c);
int ispunct(int c);
int isspace(int c);
int isupper(int c);
int isxdigit(int c);
```

Chacune d'entre elles attend en argument un caractère et retourne un nombre positif ou zéro suivant que le caractère fourni appartienne ou non à la catégorie déterminée par la fonction.

| Fonction | Catégorie | Description | Par défaut
| -------- | --------- | ----------- | ------------------
| isupper | Majuscule | Détermine si le caractère entré est une lettre majuscule | `'A'`, `'B'`, `'C'`, `'D'`, `'E'`, `'F'`, `'G'`, `'H'`, `'I'`, `'J'`, `'K'`, `'L'`, `'M'`, `'N'`, `'O'`, `'P'`, `'Q'`, `'R'`, `'S'`, `'T'`, `'U'`, `'V'`, `'W'`, `'X'`, `'Y'` ou `'Z'`
| islower | Minuscule | Détermine si le caractère entré est une lettre minuscule | `'a'`, `'b'`, `'c'`, `'d'`, `'e'`, `'f'`, `'g'`, `'h'`, `'i'`, `'j'`, `'k'`, `'l'`, `'m'`, `'o'`, `'n'`, `'p'`, `'q'`, `'r'`, `'s'`, `'t'`, `'u'`, `'v'`, `'w'`, `'x'`, `'y'` ou `'z'`
| isdigit | Chiffre décimal | Détermine si le caractère entré est un chiffre décimal | `'0'`, `'1'`, `'2'`, `'3'`, `'4'`, `'5'`, `'6'`, `'7'`, `'8'` ou `'9'`
| isxdigit | Chiffre hexadécimal | Détermine si le caractère entré est un chiffre hexadécimal | `'0'`, `'1'`, `'2'`, `'3'`, `'4'`, `'5'`, `'6'`, `'7'`, `'8'`, `'9'`, `'A'`, `'B'`, `'C'`, `'D'`, `'E'`, `'F'`, `'a'`, `'b'`, `'c'`, `'d'`, `'e'` ou `'f'`
| isspace | Espace | Détermine si le caractère entré est un espace | `' '`, `'\f'`, `'\n'`, `'\r'`, `'\t'` ou `'\v'`
| iscntrl | Contrôle | Détermine si le caractère est un caractère dit « de contrôle » | `'\0'`, `'\a'`, `'\b'`, `'\f'`, `'\n'`, `'\r'`, `'\t'` ou `'\v'`
| ispunct | Ponctuation | Détermine si le caractère entré est un signe de ponctuation | `'!'`, `'"'`, `'#'`, `'%'`, `'&'`, `'''`, `'('`, `')'`, `'*'`, `'+'`, `','`, `'-'`, `'.'`, `'/'`, `':'`, `';'`, `'<'`, `'='`, `'>'`, `'?'`, `'['`, `'\'`, `']'`, `'^'`, `'_'`, `'{'`, `'<barre droite>'`, `'}'` ou `'~'`
| isalpha | Alphabétique | Détermine si le caractère entré est une lettre alphabétique | Les deux ensembles de caractères de `islower()` et `isupper()`
| isalnum | Alphanumérique | Détermine si le caractère entré est une lettre alphabétique ou un chiffre décimal | Les trois ensembles de caractères de `islower()`, `isupper()` et `isdigit()`
| isgraph | Graphique | Détermine si le caractère est représentable graphiquement | Tout sauf l'ensemble de `iscntrl()` et l'espace (`' '`)
| isprint | Affichable | Détermine si le caractère est « affichable » | Tout sauf l'ensemble de `iscntrl()`

[[information]]
| La suite `<barre_droite>` symbolise le caractère `|`.

Le tableau ci-dessous vous présente chacune de ces onze fonctions ainsi que les ensembles de caractères qu'elles décrivent. La colonne « par défaut » vous détail leur comportement en cas d'utilisation de la **_locale_** `C`. Nous reviendrons sur les *locales* dans la troisième partie de ce cours ; pour l'heure, considérez que ces fonctions ne retournent un nombre positif que si un des caractères de leur ensemble « par défaut » leur est fourni en argument.

L'exemple ci-dessous utilise la fonction `isdigit()` pour déterminer si l'utilisateur a bien entré une suite de chiffres.

```c
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* lire_ligne() */


int main(void)
{
	char suite[255];
	unsigned i;

	if (!lire_ligne(suite, sizeof suite))
	{
		printf("Erreur lors de la saisie.\n");
		return EXIT_FAILURE;
	}

	for (i = 0; suite[i] != '\0'; ++i)
		if (!isdigit(suite[i]))
		{
			printf("Veuillez entrer une suite de chiffres.\n");
			return EXIT_FAILURE;
		}

	printf("C'est bien une suite de chiffres.\n");
	return 0;
}
```

```text
122334
C'est bien une suite de chiffres.

5678a
Veuillez entre une suite de chiffres.
```

[[information]]
| Notez que cet en-tête fourni également deux fonctions : `tolower()` et `toupper()` retournant respectivement la version minuscule ou majuscule de la lettre entrée. Dans le cas où un caractère autre qu'une lettre est entré (ou que celle-ci est déjà en minuscule ou en majuscule), la fonction retourne celui-ci.