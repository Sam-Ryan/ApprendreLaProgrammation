# Définition

Définir une chaine de caractères, c’est avant tout définir un tableau de ```char```, ce que nous avons vu au chapitre précédent. L’exemple ci-dessous définit un tableau de vingt-cinq `char`.

```c
char tab[25];
```

# Initialisation

Il existe deux méthodes pour initialiser une chaîne de caractères :

- de la même manière qu’un tableau ;
- à l’aide d’une chaîne de caractères littérale.

## Avec une liste d’initialisation

### Initialisation avec une longueur explicite

Comme pour n’importe quel tableau, l’initialisation se réalise à l’aide d’une liste d’initialisation. L’exemple ci-dessous définit donc un tableau de vingt-cinq `char` et initialise les sept premiers avec la suite de lettres « Bonjour ».

```c
char chaine[25] = { 'B', 'o', 'n', 'j', 'o', 'u', 'r' };
```

Étant donné que seule une partie des éléments sont initialisés, les autres sont implicitement mis à zéro, ce qui nous donne une chaîne de caractères valides puisqu’elle est bien terminée par un caractère nul. Faites cependant attention à ce qu’il y ait *toujours* de la place pour un caractère nul.

### Initialisation avec une longueur implicite

Dans le cas où vous ne spécifiez pas de taille lors de la définition, il vous faudra ajouter le caractère nul à la fin de la liste d’initialisation pour obtenir une chaîne valide.

```c
char chaine[] = { 'B', 'o', 'n', 'j', 'o', 'u', 'r', '\0' };
```

## Avec une chaîne littérale

Bien que tout à fait valide, cette première solution est toutefois assez fastidieuse. Aussi, il en existe une seconde : recourir à une **chaîne de caractères littérales** pour initialiser un tableau. Une chaîne de caractères littérales est une suite de caractères entourée par le symbole `"`. Nous en avons déjà utilisé auparavant comme argument des fonctions `printf()` et `scanf()`.

Techniquement, une chaîne littérale est un tableau de `char` terminé par un caractère nul. Elles peuvent donc s’utiliser comme n’importe quel autre tableau. Si vous exécutez le code ci-dessous, vous remarquerez que l’opérateur `sizeof` retourne bien le nombre de caractères composant la chaîne littérale (n’oubliez pas de compter le caractère nul) et que l’opérateur `[]` peut effectivement leur être appliqué.

```c
#include <stdio.h>


int main(void)
{
    printf("%u\n", (unsigned)sizeof "Bonjour");
    printf("%c\n", "Bonjour"[3]);
    return 0;
}
```

```text
8
j
```

Ces chaînes de caractères littérales peuvent également être utilisées à la place des listes d’initialisation. En fait, il s’agit de la troisième et dernière exception à la règle de conversion implicite des tableaux.

### Initialisation avec une longueur explicite

Dans le cas où vous spécifiez la taille de votre tableau, faites bien attention à ce que celui-ci dispose de suffisamment de place pour accueillir la chaîne entière, c’est-à-dire les caractères qui la composent *et* le caractère nul. 

```c
char chaine[25] = "Bonjour";
```

### Initialisation avec une longueur implicite

L’utilisation d’une chaîne littérale pour initialiser un tableau dont la taille n’est pas spécifiée vous évite de vous soucier du caractère nul puisque celui-ci fait partie de la chaîne littérale.

```c
char chaine[] = "Bonjour";
```

## Utilisation de pointeurs

Nous vous avons dit que les chaînes littérales n’étaient rien d’autre que des tableaux de `char` terminés par un caractère nul. Dès lors, comme pour n’importe quel tableau, il vous est loisible de les référencer à l’aide de pointeurs.

```c
char *ptr = "Bonjour";
```

Néanmoins, les chaînes littérales sont des *constantes*, il vous est donc impossible de les modifier. L’exemple ci-dessous est donc incorrect.

```c
int main(void)
{
    char *ptr = "bonjour";

    ptr[0] = 'B'; /* Incorrect. */
    return 0;
}
```

[[attention]]
| Notez bien la différence entre les exemples précédents qui initialisent un tableau avec le contenu d’une chaîne littérale (il y a donc copie de la chaîne littérale) et cet exemple qui initialise un pointeur avec l’adresse du premier élément d’une chaîne littérale.

# Utilisation

Pour le reste, une chaîne de caractères s’utilise comme n’importe quel autre tableau. Aussi, pour modifier son contenu, il vous faudra accéder à ses éléments un à un.

```c
#include <stdio.h>


int main(void)
{
    char chaine[25] = "Bonjour";

    printf("%s\n", chaine);
    chaine[0] = 'A';
    chaine[1] = 'u';
    chaine[2] = ' ';
    chaine[3] = 'r';
    chaine[4] = 'e';
    chaine[5] = 'v';
    chaine[6] = 'o';
    chaine[7] = 'i';
    chaine[8] = 'r';
    chaine[9] = '\0'; /* N'oubliez pas le caractère nul ! */
    printf("%s\n", chaine);
    return 0;
}
```

```text
Bonjour
Au revoir
```