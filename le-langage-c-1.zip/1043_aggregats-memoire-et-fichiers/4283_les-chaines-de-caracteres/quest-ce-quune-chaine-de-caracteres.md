Dans le chapitre sur les variables, nous avions mentionné le type ```char```. Pour rappel, nous vous avions dit que le type `char` servait surtout au stockage de caractères, mais que comme ces derniers étaient stockés dans l’ordinateur sous forme de nombres, il était également possible d’utiliser ce type pour mémoriser des nombres.

Le seul problème, c’est qu’une variable de type ```char``` ne peut stocker qu’une seule lettre, ce qui est insuffisant pour stocker une phrase ou même un mot. Si nous voulons mémoriser un texte, nous avons besoin d’un outil pour rassembler plusieurs lettres dans un seul objet, manipulable dans notre langage. Cela tombe bien, nous en avons justement découvert un au chapitre précédent : les tableaux.

C’est ainsi que le texte est géré en C : sous forme de tableaux de `char` appelés **chaînes de caractères** (*strings* en anglais).

# Représentation en mémoire

Néanmoins, il y a une petite subtilité. Une chaîne de caractères est un plus qu’un tableau : c’est un objet à part entière qui doit être manipulable directement. Or, ceci n’est possible que si nous connaissons sa taille.

## Avec une taille intégrée

Dans certains langages de programmation, les chaines de caractères sont stockées sous la forme d’un tableau de ```char``` auquel est adjoint un entier pour indiquer sa longueur. Plus précisément, lors de l’allocation du tableau, le compilateur réserve un élément supplémentaire pour conserver la taille de la chaîne. Ainsi, il est aisé de parcourir la chaîne et de savoir quand la fin de celle-ci est atteinte. De telles chaines de caractères sont souvent appelées des *Pascal strings*, s’agissant d’une convention apparue avec le langage de programmation Pascal.

## Avec une sentinelle

Toutefois, une telle technique limite la taille des chaînes de caractères à la capacité du type entier utilisé pour mémoriser la longueur de la chaine. Dans la majorité des cas, il s’agit d’un `unsigned char`, ce qui donne une limite de 255 caractères maximum sur la plupart des machines. Pour ne pas subir cette limitation, les concepteurs du langage C ont adopté une autre solution : la fin de la chaîne de caractères sera indiquée par un caractère spécial, en l’occurrence zéro (noté `'\0'`). Les chaines de caractères qui fonctionnent sur ce principe sont appelées *null terminated strings*, ou encore *C strings*.

Cette solution a toutefois deux inconvénients :

* la taille de chaque chaîne doit être calculée en la parcourant jusqu’au caractère nul ;
* le programmeur doit s’assurer que chaque chaîne qu’il construit se termine bien par un caractère nul.