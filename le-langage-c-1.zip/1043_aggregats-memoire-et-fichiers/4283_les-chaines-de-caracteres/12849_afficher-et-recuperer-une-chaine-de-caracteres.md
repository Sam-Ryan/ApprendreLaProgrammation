Les chaînes littérales n’étant rien d’autre que des tableaux de `char`, il vous est possible d’utiliser des chaînes de caractères là où vous employiez des chaînes littérales. Ainsi, les deux exemples ci-dessous afficheront la même chose.

```c
#include <stdio.h>


int main(void)
{
    char chaine[] = "Bonjour\n";

    printf(chaine);
    return 0;
}
```

```c
#include <stdio.h>


int main(void)
{
    printf("Bonjour\n");
    return 0;
}
```

```text
Bonjour
```

Toutefois, les fonctions `printf()` et `scanf()` disposent d’un indicateur de conversion vous permettant d’afficher ou de demander une chaîne de caractères : `s`.

# Printf

L’exemple suivant illustre l’utilisation de cet indicateur de conversion avec `printf()` et affiche la même chose que les deux codes précédents.

```c
#include <stdio.h>


int main(void)
{
    char chaine[] = "Bonjour";

    printf("%s\n", chaine);
    return 0;
}
```

```text
Bonjour
```

# Scanf

Le même indicateur de conversion peut être utiliser avec `scanf()` pour demander à l’utilisateur d’entrer une chaîne de caractères. Cependant, un problème se pose : étant donné que nous devons créer un tableau de taille finie pour accueillir la saisie de l’utilisateur, nous devons impérativement limiter la longueur des données que nous fournit l’utilisateur.

Pour éviter ce problème, il est possible de spécifier une taille maximale à la fonction `scanf()`. Pour ce faire, il vous suffit de placer un nombre entre le symbole `%` et l’indicateur de conversion `s`. L’exemple ci-dessous demande à l’utilisateur d’entrer son prénom (limité à 254 caractères) et affiche ensuite celui-ci.

[[erreur]]
| La fonction `scanf()` ne décompte pas le caractère nul final de la limite fournie ! Il vous est donc nécessaire de lui indiquer la taille de votre tableau diminuée de un.

```c
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    char chaine[255];

    printf("Quel est votre prénom ? ");

    if (scanf("%254s", chaine) != 1)
    {
        printf("Erreur lors de la saisie\n");
        return EXIT_FAILURE;
    }

    printf("Bien le bonjour %s !\n", chaine);
    return 0;
}
```

```text
Quel est votre prénom ? Albert
Bien le bonjour Albert !
```

## Chaîne de caractères avec des espaces

Sauf qu'en fait, l’indicateur `s` signifie : « la plus longue suite de caractère ne comprenant *pas* d’espaces » (les espaces étant ici entendu comme une suite d’un ou plusieurs des caractères suivant : `' '`, `'\f'`, `'\n'`, `'\r'`, `'\t'`, `'\v'`)...

Autrement dit, si vous entrez « Bonjour tout le monde », la fonction `scanf()` va s’arrêter au mot « Bonjour », ce dernier étant suivi par un espace.

[[question]]
| Comment peut-on récupérer une chaîne complète alors ? :euh:

*Eh* bien, il va falloir nous débrouiller avec l'indicateur `c` de la fonction `scanf()` et réaliser nous même une fonction employant ce dernier au sein d'une boucle. Ainsi, nous pouvons par exemple créer une fonction recevant un pointeur sur `char` et la taille du tableau référencé qui lit un caractère jusqu'à être arrivé à la fin de la ligne ou à la limite du tableau.

[[question]]
| Et comment sait-on que la lecture est arrivée à la fin d'une ligne ?

La fin de ligne est indiquée par le caractère `\n`.  
Avec ceci, vous devriez pouvoir construire une fonction adéquate.  
Allez, *hop*, au boulot et faites gaffe aux retours d'erreur ! :pirate:

[[secret]]
|```c
| #include <stdio.h>
|
|
| int lire_ligne(char *chaine, size_t max)
| {
|     size_t i;
|     char c;
| 
|     for (i = 0; i < max - 1; ++i)
|     {
|         if (scanf("%c", &c) != 1)
|             return 0;
|         else if (c == '\n')
|             break;
| 
|         chaine[i] = c;
|     }
| 
|     chaine[i] = '\0';
|     return 1;
| }
|
|
| int main(void)
| {
|     char chaine[255];
|
|     printf("Quel est votre prénom ? ");
|
|     if (lire_ligne(chaine, sizeof chaine))
|         printf("Bien le bonjour %s !\n", chaine);
|
|     return 0;
| }
|```
|
| ```text
| Quel est votre prénom ? Charles Henri
| Bien le bonjour Charles Henri !
| ```

[[information]]
| Gardez bien cette fonction sous le coude, nous allons en avoir besoin pour la suite. ;)