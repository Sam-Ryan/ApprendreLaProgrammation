# Palindrome

Un palindrome est un texte identique lorsqu’il est lu de gauche à droite et de droite à gauche. Ainsi, le mot *radar* est un palindrome, de même que les phrases *engage le jeu que je le gagne* et *élu par cette crapule*. Normalement, il n’est pas tenu compte des accents, trémas, cédilles ou des espaces. Toutefois, pour cet exercice, nous nous contenterons de vérifier si un mot donné est un palindrome.

[[secret]]
|```c
| int palindrome(char *s)
| {
|     size_t len = 0;
|     size_t i;
|
|     while (s[len] != '\0')
|         ++len;
|
|     for (i = 0; i < len; ++i)
|         if (s[i] != s[len - 1 - i])
|             return 0;
|
|     return 1;
| }
|```

# Compter les parenthèses

Écrivez un programme qui lit une ligne et vérifie que chaque parenthèse ouvrante est bien refermée par la suite.

```text
Entrez une ligne : printf("%u\n", (unsigned)sizeof(int);
Il manque des parenthèses.
```

[[secret]]
|```c
| #include <stdio.h>
| #include <stdlib.h>
|
| /* lire_ligne() */
| 
| 
| int main(void)
| {
|     char s[255];
|     char *t;
|     long n = 0;
| 
|     printf("Entrez une ligne : ");
| 
|     if (!lire_ligne(s, sizeof s))
|     {
|         printf("Erreur lors de la saisie.\n");
|         return EXIT_FAILURE;
|     }
| 
|     for (t = s; *t != '\0'; ++t)
|         if (*t == '(')
|             ++n;
|         else if (*t == ')')
|             --n;
| 
|     if (n == 0)
|         printf("Le compte est bon.\n");
|     else
|         printf("Il manque des parenthèses.\n");
| 
|     return 0;
| }
|```