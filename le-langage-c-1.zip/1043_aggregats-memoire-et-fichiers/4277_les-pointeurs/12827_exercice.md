Pour le moment, tout ceci doit sans doute vous paraître quelques peu abstrait et sans doute inutile. Toutefois, rassurez-vous, cela vous semblera plus clair après les chapitres suivants.

En attendant, nous vous proposons un petit exercice mettant en pratique les pointeurs : programmez une fonction nommée « swap », dont le rôle est d’échanger la valeur de deux variables de type `int`. Autrement dit, la valeur de la variable « a » doit devenir celle de « b » et la valeur de « b », celle de « a ». 

# Correction

[[secret]]
| ```c
| #include <stdio.h>
| 
| void swap(int *, int *);
| 
|
| void swap(int *pa, int *pb)
| {
|     int tmp;
|
|     tmp = *pa;
|     *pa = *pb;
|     *pb = tmp;
| }
|
|
| int main(void)
| {
|     int a = 10;
|     int b = 20;
|
|     swap(&a, &b);
|     printf("a = %d, b = %d\n", a, b);
|     return 0;
| }
| ```