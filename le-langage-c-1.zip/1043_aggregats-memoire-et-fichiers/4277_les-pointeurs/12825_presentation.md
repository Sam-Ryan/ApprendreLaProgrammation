Avant de vous présenter le concept de pointeur, un petit rappel concernant la mémoire s’impose (n’hésitez pas à relire le chapitre sur les variables si celui-ci s’avère insuffisant).

Souvenez-vous : toute donnée manipulée par l’ordinateur est stockée dans sa **mémoire**, plus précisément dans une de ses différentes mémoires (registre(s), mémoire vive, disque(s) dur(s), etc.). Cependant, pour utiliser une donnée, nous avons besoin de savoir où elle se situe, nous avons besoin d’une **référence** vers cette donnée. Dans la plupart des cas, cette référence est en fait une **adresse mémoire** qui indique la position de la donnée dans la mémoire vive.

# Les pointeurs

Si l’utilisation des références peut être implicites (c’est par exemple le cas lorsque vous manipulez des variables), il est des cas où elle doit être explicite. C’est à cela que servent les **pointeurs** : ce sont des variables dont le contenu est une adresse mémoire (une référence, donc). 

![Exemple, avec une variable a qui est un pointeur sur une variable b](http://zestedesavoir.com/media/galleries/1501/4d619aef-6b64-4c47-aa6e-0aaa17b13ddf.png.960x960_q85.jpg)

# Utilité des pointeurs

Techniquement, il y a trois utilisations majeures des pointeurs en C :

* le passage de références à des fonctions ;
* la manipulation de données complexes ;
* l’allocation dynamique de mémoire.

## Passage de références à des fonctions

Rappelez-vous du chapitre sur les fonctions : lorsque vous fournissez un argument lors d’un appel, la valeur de celui-ci est affectée au paramètre correspondant, paramètre qui est une variable propre à la fonction appelée. Toutefois, il est parfois souhaitable de modifier une variable de la fonction *appelante*. Dès lors, plutôt que de passer la valeur de la variable en argument, c’est une référence vers celle-ci qui sera envoyée à la fonction.

## Manipulation de données complexes

Jusqu’à présent, nous avons manipulé des données simples :  ```int```, ```double```, ```char```, etc. Cependant, le C nous permet également d’utiliser des données plus complexes qui sont en fait des **agrégats** (un regroupement si vous préférez) de données simples. Or, il n’est possible de manipuler ces agrégats qu’en les parcourant données simples par données simples, ce qui requiert de disposer d’une référence vers les données qui le composent.

[[information]]
| Nous verrons les agrégats plus en détails lorsque nous aborderons les structures et les tableaux.

## L’allocation dynamique de mémoire

Il n’est pas toujours possible de savoir quelle quantité de mémoire sera utilisée par un programme. En effet, si vous prenez le cas d’un logiciel de dessin, ce dernier ne peut pas prévoir quelle sera la taille des images qu’il va devoir manipuler. Pour palier à ce problème, les programmes recours au mécanisme de l’**allocation dynamique de mémoire** : ils demandent de la mémoire au système d’exploitation lors de leur exécution. Pour que cela fonctionne, le seul moyen est que le système d’exploitation fournisse au programme une référence vers la zone allouée.