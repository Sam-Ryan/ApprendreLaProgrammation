# Indirection (ou déréférencement)

Maintenant que nous savons récupérer l’adresse d’un objet et l’affecter à un pointeur, voyons le plus intéressant : accéder à cet objet ou le modifier via le pointeur. Pour y parvenir, nous avons besoin de l’**opérateur d’indirection** (ou de déréférencement) : `*`.

[[question]]
| Le symbole `*` n’est pas celui de la multiplication ? :euh:

Si, c’est aussi le symbole de la multiplication. Toutefois, à l’inverse de l’opérateur de multiplication, l’opérateur d’indirection ne prends qu’un seul opérande (il n’y a donc pas de risque de confusion).

L’opérateur d’indirection attends un pointeur comme opérande et se place juste derrière celui-ci. Une fois appliqué, ce dernier nous donne accès à la valeur de l’objet référencé par le pointeur, aussi bien pour la lire que pour la modifier.

Dans l’exemple ci-dessous, nous accédons à la valeur de la variable `a` via le pointeur `p`.

```c
int a = 10;
int *p = &a;

printf("a = %d\n", *p);
```

```text
a = 10
```

À présent, modifions la variable `a` à l’aide du pointeur `p`.

```c
int a = 10;
int *p = &a;

*p = 20;
printf("a = %d\n", *p);
```

```text
a = 20
```

[[information]]
| Comme pour n’importe quelle variable, il est possible de déclarer un pointeur comme constant. Cependant, puisqu’un pointeur référence un objet, il peut également être déclaré comme un pointeur vers un objet constant. Pour ce faire, la position du mot-clé `const` est importante.
|
| Si le mot-clé est devant l’identificateur et derrière le symbole `*`, alors il s’agit d’un pointeur constant.
|
|```c
| int * const ptr; /* Un pointeur constant sur int. */
|```
|
| Si le mot-clé est devant le symbole `*` et derrière le type référencé, alors il s’agit d’un pointeur vers un objet constant.
|
|```c
| int const *ptr; /* Pointeur sur int constant. */
|```
|
| Enfin, ces deux notations peuvent être combinées pour créer un pointeur constant vers un objet constant.
|
|```c
| int const * const ptr; /* Pointeur constant sur int constant. */
|```

# Passage comme argument

Voici un exemple de passage de pointeurs en arguments d’une fonction.

```c
#include <stdio.h>

void test(int *pa, int *pb)
{
    *pa = 10;
    *pb = 20;
}


int main(void)
{
    int a;
    int b;
    int *pa = &a;
    int *pb = &b;

    test(&a, &b);
    test(pa, pb);
    printf("a = %d, b = %d\n", a, b);
    printf("a = %d, b = %d\n", *pa, *pb);
    return 0;
}
```

```text
a = 10, b = 20
a = 10, b = 20
```

Remarquez que les appels `test(&a, &b)` et `test(pa, pb)` réalisent la même opération.

# Retour de fonction

Pour terminer, sachez qu’une fonction peut également retourner un pointeur. Cependant, faites attention : *l’objet référencé par le pointeur doit toujours exister au moment de son utilisation* ! L’exemple ci-dessous est donc incorrect étant donnée que la variable `n` est de classe de stockage automatique et qu’elle n’existe donc plus après l’appel à la fonction `ptr()`.

```c
#include <stdio.h>


int *ptr(void)
{
    int n;

    return &n;
}


int main(void)
{
    int *p = ptr();

    *p = 10;
    printf("%d\n", *p);
    return 0;
}
```

L’exemple devient correct si `n` est de classe de stockage statique.

# Pointeur de pointeur

Au même titre que n’importe quel autre objet, un pointeur a lui aussi une adresse. Dès lors, il est possible de créer un objet pointant sur ce pointeur : un pointeur de pointeur.

```c
int a = 10;
int *pa = &a;
int **pp = &pa;
```

Celui-ci s’utilise de la même manière qu’un pointeur si ce n’est qu’il est possible d’opérer deux indirections : une pour atteindre le pointeur référencé et une seconde pour atteindre la variable sur laquelle pointe le premier pointeur.

```c
#include <stdio.h>


int main(void)
{
    int a = 10;
    int *pa = &a;
    int **pp = &pa;

    printf("a = %d\n", **pp);
    return 0;
}
```

[[information]]
| Ceci peut continuer à l’infini pour concevoir des pointeurs de pointeur de pointeur de pointeur de… Bref, vous avez compris le principe. :p