La syntaxe pour déclarer un pointeur est la suivante.

```c
type *nom_du_pointeur;
```

Par exemple, si nous souhaitons créer un pointeur sur ```int``` (c’est-à-dire un pointeur pouvant stocker l’adresse d’un objet de type ```int```) et que nous voulons le nommer « ptr », nous devons écrire ceci.

```c
int *ptr;
```

L’astérisque peut être entourée d’espaces et placée n’importe où entre le type et l’identificateur. Ainsi, les trois définitions suivantes sont identiques.

```c
int *ptr;
int * ptr;
int* ptr;
```

[[attention]]
| Notez bien qu’un pointeur est toujours typé. Autrement dit, vous aurez toujours un pointeur sur (ou vers) un objet d’un certain type (`int`, `double`, `char`, etc.).

# Initialisation

Un pointeur, comme une variable, ne possède pas de valeur par défaut, il est donc important de l’initialiser pour éviter d’éventuels problèmes. Pour ce faire, il est nécessaire de recourir à l’**opérateur d’adressage** (ou de référencement) : `&` qui permet d’obtenir l’adresse d’un objet. Ce dernier se place derrière l’objet dont l’adresse souhaite être obtenue. Par exemple comme ceci.

```c
int a = 10;
int *p;

p = &a;
```

Ou, plus directement, comme cela.

```c
int a = 10;
int *p = &a;
```

[[erreur]]
| Faites bien attention à ne pas mélanger différents types de pointeurs ! Un pointeur sur `int` n’est pas le même qu’un pointeur sur `long` ou qu’un pointeur sur `double`. De même, n’affectez l’adresse d’un objet qu’à un pointeur du même type.
|
|```c
| int a;
| double b;
| int *p = &b; /* faux */
| int *q = &a; /* correct */
| double *r = p; /* faux */
|```

# Pointeur nul

Vous souvenez-vous du chapitre sur la gestion d’erreur ? Dans ce dernier, nous vous avons dit que, le plus souvent, les fonctions retournaient une valeur particulière en cas d’erreur. *Quid* de celles qui retournent un pointeur ? Existe-t-il une valeur spéciale qui puisse représenter une erreur ou bien sommes-nous condamner à utiliser une variable globale comme `errno` ?

Heureusement pour nous, il existe un cas particulier : les pointeurs nuls. Un pointeur nul est tout simplement un pointeur contenant une adresse invalide. Cette adresse invalide dépend de votre système d’exploitation, mais elle est la même pour tous les pointeurs nuls. Ainsi, deux pointeurs nuls ont une valeur égale.

Pour obtenir cette adresse invalide, il vous suffit de convertir explicitement zéro vers le type de pointeur voulu. Ainsi, le pointeur suivant est un pointeur nul.

```c
int *p = (int *)0;
```

[[information]]
| Rappelez-vous qu’il y a conversion implicite vers le type de destination dans le cas d’une affectation. La conversion est donc superflue dans ce cas-ci.

## La constante NULL

Afin de clarifier un peu les codes sources, il existe une constante définie dans l’en-tête `<stddef.h>` : `NULL`. Celle-ci peut être utilisée partout où un pointeur nul est attendu *sauf comme argument de la fonction `printf()`* (nous verrons pourquoi plus tard dans ce cours).

```c
int *p = NULL; /* Un pointeur nul. */
```