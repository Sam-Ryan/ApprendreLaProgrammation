# Le type `void`

Vous avez déjà recontré le mot-clé `void` lorsque nous avons parlé des fonctions, ce dernier permet d’indiquer qu’une fonction n’utilise aucun paramètre et/ou ne retourne aucune valeur. Toutefois, nous n’avons pas tout dit à son sujet : `void` est en fait un type, au même titre que `int` ou `double`. o_O

[[question]]
| Et il représente quoi ce type, alors ?

*Hum*… rien (d’où son nom). :-°  
En fait, il s’agit d’un type dit « **incomplet** », c’est à dire que la taille de ce dernier n’est pas calculable et qu’il n’est pas utilisable dans des expressions. Quel est l’intérêt de la chose me direz-vous ? Permettre de créer des pointeurs « **génériques** » (ou « universels »).

En effet, nous venons de vous dire qu’un pointeur devait toujours être typé. Cependant, cela peut devenir gênant si vous souhaitez créer une fonction qui doit pouvoir travailler avec n’importe quel type de pointeur (nous verrons un exemple très bientôt). C’est ici que le type `void` intervient : un pointeur sur `void` est considéré comme un pointeur générique, ce qui signifie qu’il peut référencer n’importe quel type d’objet.

En conséquence, il est possible d’affecter n’importe quelle adresse d’objet à un pointeur sur `void` et d’affecter un pointeur sur `void` à n’importe quel autre pointeur (et inversément).

```c
int a;
double b;
void *p;
double *r;

p = &a; /* correct */
p = &b; /* correct */
r = p; /* correct */
```

# Afficher une adresse

Il est possible d’afficher une adresse à l’aide de l’indicateur de conversion `p` de la fonction `printf()`. Ce dernier attends en argument un pointeur sur `void`. Vous voyez ici l’intérêt d’un pointeur générique : un seul indicateur suffit pour afficher tous les types de pointeurs.

Notez que l’affichage s’effectue le plus souvent en hexadécimal.

```c
int a;
int *p = &a;

printf("%p == %p\n", (void *)&a, (void *)p);
```

Tant que nous y sommes, profitons en pour voir quelle est l’adresse invalide de notre système.

```c
printf("%p\n", (void *)0);
```

[[secret]]
| Oui, le plus souvent, il s’agit de zéro. :p