Lors de la présentation des fonctions `fgetc()`, `getc()` et `fgets()` vous aurez peut-être remarqué que ces fonctions utilisent un même retour pour indiqué soit la rencontre de la fin du fichier, soit la survenance d’une erreur. Du coup, comment faire pour distinguer l’un et l’autre cas ?

Il existe deux fonctions pour clarifier une telle situation : `feof()` et `ferror()`.

# La fonction feof

```c
int feof(FILE *flux);
```

La fonction `feof()` retourne une valeur non nulle dans le cas où la fin du fichier associé au flux spécifié est atteinte.

# La fonction ferror

```c
int ferror(FILE *flux);
```

La fonction `ferror()` retourne une valeur non nulle dans le cas où une erreur s’est produite lors d’une opération sur le flux visé.

# Exemple

L’exemple ci-dessous utilise ces deux fonctions pour déterminer le type de problème rencontré par la fonction `fgets()`.

```c hl_lines="17-26"
#include <stdio.h>

int main(void)
{
    char buf[255];
    FILE *fp;

    fp = fopen("texte.txt", "r");

    if (fp == NULL)
    {
        fprintf(stderr, "Le fichier texte.txt n'a pas pu être ouvert\n");
        return EXIT_FAILURE;
    }
    if (fgets(buf, sizeof buf, fp) != NULL)
        printf("%s\n", buf);
    else if (ferror(fp))
    {
        fprintf(stderr, "Erreur lors de la lecture\n");
        return EXIT_FAILURE;
    }
    else
    {
        fprintf(stderr, "Fin de fichier rencontrée\n");
        return EXIT_FAILURE;
    }
    if (fclose(fp) == EOF)
    {
        fprintf(stderr, "Erreur lors de la fermeture du flux\n");
        return EXIT_FAILURE;        
    }

    return 0;
}
```