Pour clore ce chapitre, un petit mot sur le cas des flux ouverts en lecture *et* en écriture (soit à l'aide des modes `r+`, `w+`, `a+` et leurs équivalents binaires).

Si vous utilisez un tel flux, vous *devez* appeler une fonction de déplacement entre deux opérations de nature différentes ou utiliser la fonction `fflush()` entre une opération d’écriture et de lecture. Si vous ne souhaitez pas vous déplacer, vous pouvez utiliser l’appel `fseek(flux, 0L, SEEK_CUR)` afin de respecter cette condition sans réellement effectuer un déplacement.

[[information]]
| Vous l'aurez sans doute compris : cette règle impose en fait de vider le tampon du flux entre deux opérations de natures différentes.

```c
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    char chaine[255];
    FILE *fp;

    fp = fopen("texte.txt", "w+");

    if (fp == NULL)
    {
        fprintf(stderr, "Le fichier texte.txt n'a pas pu être ouvert.\n");
        return EXIT_FAILURE;
    }
    if (fputs("Une phrase.\n", fp) == EOF)
    {
        fprintf(stderr, "Erreur lors de l'écriture d'une ligne.\n");
        return EXIT_FAILURE;
    }

    /* Retour au début : la condition est donc remplie. */

    if (fseek(fp, 0L, SEEK_SET) != 0)
    {
        fprintf(stderr, "Impossible de revenir au début du fichier.\n");
        return EXIT_FAILURE;
    }
    if (fgets(chaine, sizeof chaine, fp) == NULL)
    {
        fprintf(stderr, "Erreur lors de la lecture.\n");
        return EXIT_FAILURE;
    }

    printf("%s\n", chaine);

    if (fclose(fp) == EOF)
    {
        fputs("Erreur lors de la fermeture du flux\n", stderr);
        return EXIT_FAILURE;        
    }

    return 0;
}
```

```text
Une phrase.
```