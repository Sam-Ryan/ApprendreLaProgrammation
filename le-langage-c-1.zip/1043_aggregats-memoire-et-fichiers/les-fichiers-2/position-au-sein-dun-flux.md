De manière imagée, un fichier peut être vu comme une longue bande magnétique depuis laquelle des données sont lues ou sur laquelle des informations sont écrites. Ainsi, au fur et à mesure que les données sont lues ou écrites, nous avançons le long de cette bande.

Toutefois, il est parfois nécessaire de se rendre directement à un point précis de cette bande (par exemple à la fin) afin d’éviter des lectures inutiles pour parvenir à un endroit souhaité. À cet effet, la bibliothèque standard fournit plusieurs fonctions.

# La fonction ftell

```c
long ftell(FILE *flux);
```

La fonction `ftell()` retourne la position actuelle au sein du fichier sous forme d’un `long`. Elle retourne un nombre négatif en cas d’erreur. Dans le cas des flux *binaires*, cette valeur correspond au nombre de multiplets séparant la position actuelle du début du fichier.

[[attention]]
| Lors de l’ouverture d’un flux, la position courante correspond au début du fichier, *sauf* pour les modes `a` et `a+` pour lesquels la position initiale est soit le début, soit la fin du fichier.

# La fonction fseek

```c
int fseek(FILE *flux, long distance, int repere);
```

La fonction `fseek()` permet d’effectuer un déplacement d’une distance fournie en argument depuis un repère donné. Elle retourne zéro en cas de succès et une autre valeur en cas d’échec. Il existe trois repères possibles :

* `SEEK_SET` qui correspond au début du fichier ;
* `SEEK_CUR` qui correspond à la position courante ;
* `SEEK_END` qui correspond à la fin du fichier.

Cette fonction s’utilise différemment suivant qu’elle opère sur un flux de texte ou sur un flux binaire.

## Les flux de texte

Dans le cas d’un flux de texte, il y a deux possibilités :

* la distance fournie est nulle ;
* la distance est une valeur fournie par un précédent appel à la fonction `ftell()` et le repère est `SEEK_SET`.

## Les flux binaires

Dans le cas d’un flux binaire, seuls les repères `SEEK_SET` et `SEEK_CUR` peuvent être utilisés. La distance correspond à un nombre de multiplets à passer depuis le repère fourni.

[[attention]]
| Dans la cas des modes `a` et `a+`, un déplacement a lieu à la fin du fichier *avant chaque opération d’écriture* et ce, *qu’il y ait eu déplacement auparavant ou non*.

# La fonction rewind

```c
void rewind(FILE *flux);
```

La fonction `rewind()` vous ramène au début du fichier (autrement dit, elle rembobine la bande).

[[erreur]]
| Si vous utilisez un flux ouvert en lecture *et* écriture vous *devez* appeler une fonction de déplacement entre deux opérations de nature différentes ou utiliser la fonction `fflush()` (présentée dans l’extrait suivant) entre une opération d’écriture et de lecture. Si vous ne souhaitez pas vous déplacer, vous pouvez utilisez l’appel `fseek(flux, 0, SEEK_CUR)` afin de respecter cette condition sans réellement effectuer un déplacement.