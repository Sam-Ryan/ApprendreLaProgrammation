Dans le chapitre précédent, nous vous avons précisé que les flux étaient le plus souvent temporisés afin d'optimiser les opérations de lecture et d'écriture sous-jacentes. Dans cette section, nous allons nous pencher un peu plus sur cette notion.

# Introduction

Nous vous avons dit auparavant que deux types de temporisations existaient : la temporisation par lignes et celle par blocs. Une des conséquences logiques de cette temporisation est que les fonctions de lecture/écriture récupèrent les données et les inscrivent dans ces tampons. Ceci peut paraître évident, mais cela peut avoir des conséquences parfois surprenantes si ce fait est oublié ou inconnu.

```c
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
	char nom[64];
	char prenom[64];

	printf("Quel est votre nom ? ");

	if (scanf("%63s", nom) != 1)
	{
		fprintf(stderr, "Erreur lors de la saisie\n");
		return EXIT_FAILURE;
	}

	printf("Quel est votre prénom ? ");

	if (scanf("%63s", prenom) != 1)
	{
		fprintf(stderr, "Erreur lors de la saisie\n");
		return EXIT_FAILURE;
	}

	printf("Votre nom est %s\n", nom);
	printf("Votre prénom est %s\n", prenom);
	return 0;
}
```

```text
Quel est votre nom ? Charles Henri
Quel est votre prénom ? Votre nom est Charles
Votre prénom est Henri
```

Comme vous le voyez, le programme ci-dessus réalise deux saisies, mais si l'utilisateur entre par exemple « Charles Henri », il n'aura l'occasion d'entrer des données qu'une seule fois. Ceci est dû au fait que l'indicateur `s` récupère une suite de caractères exempte d'espaces (ce qui fait qu'il s'arrête à « Charles ») et que la suite « Henri » *demeure dans le tampon du flux* `stdin`. Ainsi, lors de la deuxième saisie, il n'est pas nécessaire de récupérer de nouvelles données depuis le terminal puisqu'il y en a déjà en attente dans le tampon, d'où le résultat obtenu.

Le même problème peut se poser si par exemple les données fournies ont une taille supérieure par rapport à l'objet qui doit les accueillir.

```c
#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    char chaine1[16];
    char chaine2[16];

    printf("Un morceau : ");

    if (fgets(chaine1, sizeof chaine1, stdin) == NULL)
    {
        printf("Erreur lors de la saisie\n");
        return EXIT_FAILURE;
    }

    printf("Un autre morceau : ");

    if (fgets(chaine2, sizeof chaine2, stdin) == NULL)
    {
        printf("Erreur lors de la saisie\n");
        return EXIT_FAILURE;
    }

    printf("%s ; %s\n", chaine1, chaine2);
    return 0;
}
```

```text
Un morceau : Une chaîne de caractères, vraiment, mais alors vraiment trop longue
Un autre morceau : Une chaîne de  ; caractères, vr
```

Ici, la chaîne entrée est trop importante pour être contenue dans `chaine1`, les données non lues sont alors conservées dans le tampon du flux `stdin` et lues lors de la seconde saisie (qui ne lit par l'entièreté non plus).

# Intérargir avec la temporisation

## Vider un tampon

Si la temporisation nous évite des coûts en terme d'opérations de lecture/écriture, il nous est parfois nécessaire de passer outre cette mécanique pour vider manuellement le tampon d'un flux.

### Opération de lecture

Si le tampon contient des données qui proviennent d'une opération de lecture, celles-ci peuvent être abandonnées soit en appelant une fonction de positionnement soit en lisant les données, tout simplement. Il y a toutefois un bémol avec la première solution : les fonctions de positionnement ne fonctionnent pas dans le cas où le flux ciblé est lié à un périphérique « interactif », c'est-à-dire le plus souvent un terminal.

Autrement dit, pour que l'exemple précédent recoure bien à deux saisies, il nous est nécessaire de vérifier que la fonction `fgets()` a bien lu un caractère `\n` (qui signifie que la fin de ligne est atteinte et donc celle du tampon s'il s'agit du flux `stdin`). Si ce n'est pas le cas, alors il nous faut lire les caractères restants jusqu'au `\n` final (ou la fin du fichier).

```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int vider_tampon(FILE *fp)
{
    int c;

    do
        c = fgetc(fp);
    while (c != '\n' && c != EOF);

    return ferror(fp) ? 0 : 1;
}


int main(void)
{
    char chaine1[16];
    char chaine2[16];

    printf("Un morceau : ");

    if (fgets(chaine1, sizeof chaine1, stdin) == NULL)
    {
        printf("Erreur lors de la saisie\n");
        return EXIT_FAILURE;
    }
    if (strchr(chaine1, '\n') == NULL)
        if (!vider_tampon(stdin))
        {
            fprintf(stderr, "Erreur lors de la vidange du tampon.\n");
            return EXIT_FAILURE;
        }

    printf("Un autre morceau : ");

    if (fgets(chaine2, sizeof chaine2, stdin) == NULL)
    {
        printf("Erreur lors de la saisie\n");
        return EXIT_FAILURE;
    }
    if (strchr(chaine2, '\n') == NULL)
        if (!vider_tampon(stdin))
        {
            fprintf(stderr, "Erreur lors de la vidange du tampon.\n");
            return EXIT_FAILURE;
        }

    printf("%s ; %s\n", chaine1, chaine2);
    return 0;
}
```

```text
Un morceau : Une chaîne de caractères vraiment, mais alors vraiment longue
Un autre morceau : Une autre chaîne de caractères
Une chaîne de  ; Une autre chaî
```

### Opération d'écriture

Si, en revanche, le tampon comprend des données en attente d'écriture, il est possible de forcer celle-ci soit à l'aide d'une fonction de positionnement, soit à l'aide de la fonction `fflush()`.

```c
int fflush(FILE *flux);
```

Celle-ci vide le tampon du flux spécifié et retourne zéro en cas de succès ou `EOF` en cas d’erreur.

[[attention]]
| Notez bien que cette fonction ne peut être employée que pour vider un tampon comprenant des données en attente d'*écriture*.

## Modifier un tampon

Techniquement, il ne vous est pas possible de modifier directement le contenu d'un tampon, ceci est réalisé par les fonctions de la bibliothèque standard au gré de vos opérations de lecture et/ou d'écriture. Il y a toutefois une exception à cette règle : la fonction `ungetc()`.

```c
int ungetc(int ch, FILE *flux);
```

Cette fonction est un peu particulière : elle place le caractère `ch` dans le tampon du flux `flux`. Ce caractère pourra être lu lors d’un appel ultérieur à une fonction de *lecture*. Elle retourne le caractère ajouté en cas de succès et `EOF` en cas d’échec.

Cette fonction est très utile dans le cas où les actions d’un programme dépendent du contenu d’un flux. Imaginez par exemple que votre programme doit déterminer si l’entrée standard contient une suite de caractères ou un nombre et doit ensuite afficher celui-ci. Vous pourriez utiliser `getchar()` pour récupérer le premier caractère et déterminer s’il s’agit d’un chiffre. Toutefois, le premier caractère du flux est alors lu et cela complique votre tâche pour la suite… La fonction `ungetc()` vous permet de résoudre ce problème en replaçant ce caractère dans le tampon du flux `stdin`.

```c
#include <stdio.h>
#include <stdlib.h>

static void afficher_nombre(void);
static void afficher_chaine(void);


static void afficher_nombre(void)
{
    double f;

    if (scanf("%lf", &f) == 1)
        printf("Vous avez entré le nombre : %f\n", f);
    else
        fprintf(stderr, "Erreur lors de la saisie\n");
}


static void afficher_chaine(void)
{
    char chaine[255];

    if (scanf("%254s", chaine) == 1)
        printf("Vous avez entré la chaine : %s\n", chaine);
    else
        fprintf(stderr, "Erreur lors de la saisie\n");
}


int main(void)
{
    int ch;

    ch = getchar();

    if (ungetc(ch, stdin) == EOF)
    {
        fprintf(stderr, "Impossible de replacer un caractère\n");
        return EXIT_FAILURE;
    }

    switch (ch)
    {
    case '0':
    case '1':
    case '2':
    case '3':
    case '4':
    case '5':
    case '6':
    case '7':
    case '8':
    case '9':
        afficher_nombre();
        break;

    default:
        afficher_chaine();
        break;
    }
    
    return 0;
}
```

[[attention]]
| La fonction `ungetc()` ne vous permet de replacer qu’*un seul caractère* avant une opération de *lecture*.