Alors, cela s’est bien passé ? Si oui, félicitations, si non, la correction devrait vous aider à y voir plus clair. ;)

[[secret]]
|```c
| #include <stdio.h>
| 
| 
| int
| main(void)
| {
|     unsigned jour;
|     int njours;
| 
|     printf("Entrez un jour : ");
|     scanf("%u", &jour);
| 
|     njours = (jour - 1);
| 
|     switch (njours % 7)
|     {
|     case 0:
|         printf("C'est un samedi\n");
|         break;
| 
|     case 1:
|         printf("C'est un dimanche\n");
|         break;
| 
|     case 2:
|         printf("C'est un lundi\n");
|         break;
| 
|     case 3:
|         printf("C'est un mardi\n");
|         break;
| 
|     case 4:
|         printf("C'est un mercredi\n");
|         break;
| 
|     case 5:
|         printf("C'est un jeudi\n");
|         break;
| 
|     case 6:
|         printf("C'est un vendredi\n");
|         break;
|     }
|     
|     return 0;
| }
|```

Tout d’abord, nous demandons à l’utilisateur d’entrer un jour du mois de janvier que nous affectons à la variable `jour`. Ensuite, nous calculons la différence de jours séparant le premier janvier de celui entré par l’utilisateur. Enfin, nous appliquons le modulo à ce résultat afin d’obtenir le jour de la semaine correspondant.