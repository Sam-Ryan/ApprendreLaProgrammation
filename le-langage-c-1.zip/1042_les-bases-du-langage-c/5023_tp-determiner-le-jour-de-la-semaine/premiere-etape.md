Pour cette première étape, vous allez devoir réaliser un programme qui demande à l’utilisateur un jour du mois de janvier de l’an un et qui lui précise de quel jour de la semaine il s’agit, le tout à l’aide de la méthode présentée ci-dessous.

```text
Entrez un jour : 27
C’est un jeudi
```

# Déterminer le jour de la semaine

Pour déterminer le jour de la semaine correspondant à une date, vous allez devoir partir du premier janvier de l’an un (c’était un samedi) et calculer le nombre de jours qui sépare cette date de celle fournie par l’utilisateur. Une fois ce nombre obtenu, il nous est possible d’obtenir le jour de la semaine correspondant à l’aide de l’opérateur modulo.

En effet, comme vous le savez, les jours de la semaine suivent un cycle et se répètent tous les sept jours. Or, le reste de la division entière est justement un nombre cyclique allant de zéro jusqu’au diviseur diminué de un. Voici ce que donne le reste de la division entière des chiffres 1 à 9 par 3.

```text
1 % 3 = 1
2 % 3 = 2
3 % 3 = 0
4 % 3 = 1
5 % 3 = 2
6 % 3 = 0
7 % 3 = 1
8 % 3 = 2
9 % 3 = 0
```

Comme vous le voyez, le reste de la division oscille toujours entre zéro et deux. Ainsi, si nous attribuons un chiffre de zéro à six à chaque jour de la semaine (par exemple zéro pour samedi et ainsi de suite pour les autres) nous pouvons déduire le jour de la semaine correspondant à un nombre de jours depuis le premier janvier de l’an un.

Prenons un exemple : l’utilisateur entre la date du vingt-sept janvier de l’an un. Il y a vingt-six jours qui le sépare du premier janvier. Le reste de la division entière de vingt-six par 7 est 5, il s’agit donc d’un jeudi.

Si vous le souhaitez, vous pouvez vous aider du calendrier suivant.

[[secret]]
|```text
|      Janvier 1        
| di lu ma me je ve sa  
|                    1  
|  2  3  4  5  6  7  8  
|  9 10 11 12 13 14 15  
| 16 17 18 19 20 21 22  
| 23 24 25 26 27 28 29  
| 30 31
|```            


À présent, à vous de jouer. ;)