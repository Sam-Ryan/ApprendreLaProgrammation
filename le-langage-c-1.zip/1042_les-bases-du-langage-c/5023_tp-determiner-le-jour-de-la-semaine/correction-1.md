Bien, passons à la correction. :)

[[secret]]
|```c
| #include <stdio.h>
| 
| 
| int
| main(void)
| {
|     unsigned jour;
|     unsigned mois;
|     int njours;
| 
|     printf("Entrez une date (jj/mm) : ");
|     scanf("%u/%u", &jour, &mois);
| 
|     njours = (mois - 1) * 31;
| 
|     switch (mois)
|     {
|     case 12:
|         --njours;
|     case 11:
|     case 10:
|         --njours;
|     case 9:
|     case 8:
|     case 7:
|         --njours;
|     case 6:
|     case 5:
|         --njours;
|     case 4:
|     case 3:
|         njours -= 3;
|         break;
|     }
| 
|     njours += (jour - 1);
| 
|     switch (njours % 7)
|     {
|     case 0:
|         printf("C'est un samedi\n");
|         break;
| 
|     case 1:
|         printf("C'est un dimanche\n");
|         break;
| 
|     case 2:
|         printf("C'est un lundi\n");
|         break;
| 
|     case 3:
|         printf("C'est un mardi\n");
|         break;
| 
|     case 4:
|         printf("C'est un mercredi\n");
|         break;
| 
|     case 5:
|         printf("C'est un jeudi\n");
|         break;
| 
|     case 6:
|         printf("C'est un vendredi\n");
|         break;
|     }
| 
|     return 0;
| }
|```

Nous commencons par demander deux nombres à l’utilisateur qui sont affectés aux variables `jours` et `mois`. Ensuite, nous multiplions le nombre de mois séparant celui entré par l’utilisateur du mois de janvier par trente et un. Après quoi, nous soustrayons les jours comptés en trop suivant le mois fourni. Enfin, nous ajoutons le nombre de jours séparant celui entré du premier du mois, comme pour la première étape.

[[information]]
| Notez que nous avons utilisé ici une propriété intéressante de l’instruction `switch` : si la valeur de contrôle correspond à celle d’une entrée, alors les instructions sont exécutées *jusqu’à rencontrer une instruction* `break` (ou jusqu’à la fin du `switch`). Ainsi, si le mois entré est celui de mai, l’instruction `--njours` va être exécutée, puis l’instruction `njours -= 3` va également être exécutée.