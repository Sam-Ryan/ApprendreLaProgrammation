Bien, complexifions à présent un peu notre programme et demandons à l’utilisateur de nous fournir un jour *et* un mois de l’an un.

```text
Entrez une date (jj/mm) : 20/4
C'est un mercredi
```

Pour ce faire, vous allez devoir convertir chaque mois en son nombre de jours et ajouter ensuite celui-ci au nombre de jours séparant la date entrée du premier du mois. À cette fin, vous pouvez considérer dans un premier temps que chaque mois compte trente et un jours et ensuite retrancher les jours que vous avez compté en trop suivant le mois fourni.

Par exemple, si l’utilisateur vous demande quel jour de la semaine était le vingt avril de l’an un :

* vous multipliez trente et un par trois puisque trois mois séparent le mois d’avril du mois de janvier (janvier, février et mars) ;
* vous retranchez trois jours (puisque le mois de février ne comporte que vingt-huit jours les années non bissextiles) ;
* enfin, vous ajoutez les dix-neuf jours qui séparent la date fournie du premier du mois.

Au total, vous obtenez alors cent et neuf jours, ce qui nous donne, modulo sept, le nombre quatre, c’est donc un mercredi.

À toutes fins utiles, voici le calendrier complet de l’an un.

[[secret]]
|```text
|       Janvier               Février                 Mars          
| di lu ma me je ve sa  di lu ma me je ve sa  di lu ma me je ve sa  
|                    1         1  2  3  4  5         1  2  3  4  5  
|  2  3  4  5  6  7  8   6  7  8  9 10 11 12   6  7  8  9 10 11 12  
|  9 10 11 12 13 14 15  13 14 15 16 17 18 19  13 14 15 16 17 18 19  
| 16 17 18 19 20 21 22  20 21 22 23 24 25 26  20 21 22 23 24 25 26  
| 23 24 25 26 27 28 29  27 28                 27 28 29 30 31        
| 30 31                                                             
| 
|        Avril                  Mai                   Juin          
| di lu ma me je ve sa  di lu ma me je ve sa  di lu ma me je ve sa  
|                 1  2   1  2  3  4  5  6  7            1  2  3  4  
|  3  4  5  6  7  8  9   8  9 10 11 12 13 14   5  6  7  8  9 10 11  
| 10 11 12 13 14 15 16  15 16 17 18 19 20 21  12 13 14 15 16 17 18  
| 17 18 19 20 21 22 23  22 23 24 25 26 27 28  19 20 21 22 23 24 25  
| 24 25 26 27 28 29 30  29 30 31              26 27 28 29 30        
|                                                                   
| 
|       Juillet                 Août               Septembre        
| di lu ma me je ve sa  di lu ma me je ve sa  di lu ma me je ve sa  
|                 1  2      1  2  3  4  5  6               1  2  3  
|  3  4  5  6  7  8  9   7  8  9 10 11 12 13   4  5  6  7  8  9 10  
| 10 11 12 13 14 15 16  14 15 16 17 18 19 20  11 12 13 14 15 16 17  
| 17 18 19 20 21 22 23  21 22 23 24 25 26 27  18 19 20 21 22 23 24  
| 24 25 26 27 28 29 30  28 29 30 31           25 26 27 28 29 30     
| 31                                                                
| 
|       Octobre               Novembre              Décembre        
| di lu ma me je ve sa  di lu ma me je ve sa  di lu ma me je ve sa  
|                    1         1  2  3  4  5               1  2  3  
|  2  3  4  5  6  7  8   6  7  8  9 10 11 12   4  5  6  7  8  9 10  
|  9 10 11 12 13 14 15  13 14 15 16 17 18 19  11 12 13 14 15 16 17  
| 16 17 18 19 20 21 22  20 21 22 23 24 25 26  18 19 20 21 22 23 24  
| 23 24 25 26 27 28 29  27 28 29 30           25 26 27 28 29 30 31  
| 30 31                                                             
|```

À vos claviers !