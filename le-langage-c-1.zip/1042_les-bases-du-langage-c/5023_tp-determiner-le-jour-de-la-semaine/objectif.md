Votre objectif est de parvenir à réaliser un programme qui, suivant une date fournie par l’utilisateur sous la forme « jj/mm/aaaa », donne le jour de la semaine correspondant. Autrement dit, voici ce que devrait donner l’exécution de ce programme.

```text
Entrez une date : 11/2/2015
C'est un mercredi

Entrez une date : 13/7/1970
C'est un lundi
```