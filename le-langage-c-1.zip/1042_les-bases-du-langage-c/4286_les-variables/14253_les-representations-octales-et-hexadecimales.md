Pour terminer ce chapitre, nous vous proposons un petit apparté sur deux représentations particulières : la représentation octale et la représentation hexadécimale.

Nous avons déjà vu la représentation binaire au début de ce chapitre, les représentations octale et hexadécimale obéissent au même schéma : au lieu d’utiliser dix chiffres pour représenter un nombre, nous en utilisons respectivement huit ou seize.

[[question]]
| Seize chiffres ?! Mais… Je n’en connais que dix moi ! o_O

La représentation hexadécimale est un peu déroutante de prime abord, celle-ci ajoute six chiffres (en fait, six lettres) : a, b, c, d, e et f. Pour vous aider, voici un tableau présentant les nombres de 1 à 16 en binaire, octal, décimal et hexadécimal.

Binaire | Octal | Décimal | Hexadécimal
------- | ----- | ------- | -----------
00001 | 1 | 1 | 1
00010 | 2 | 2 | 2
00011 | 3 | 3 | 3
00100 | 4 | 4 | 4
00101 | 5 | 5 | 5
00110 | 6 | 6 | 6
00111 | 7 | 7 | 7
01000 | 10 | 8 | 8
01001 | 11 | 9 | 9
01010 | 12 | 10 | a
01011 | 13 | 11 | b
01100 | 14 | 12 | c
01101 | 15 | 13 | d
01110 | 16 | 14 | e
01111 | 17 | 15 | f
10000 | 20 | 16 | 10

[[information]]
| Notez que dix dans n’importe quelle base équivaut à cette base.

[[question]]
| Quel est l’intérêt de ces deux bases exactement ?

L’avantage des représentations octale et hexadécimale est qu’il est facilement possible de les convertir en binaire contrairement à la représentation décimale. En effet, un chiffre en base huit ou en base seize peut-être facilement traduit, respectivement, en trois ou quatre *bits*.

Prenons l’exemple du nombre 35 qui donne 43 en octal et 23 en hexadécimal. Nous pouvons nous focaliser sur chaque chiffre un à un pour obtenir la représentation binaire. Ainsi, du côté de la représentation octale, 4 donne `100` et 3 `011`, ce qui nous donne finalement `00100011`. De même, pour la représentation hexadécimale, 2 nous donne `0010` et 3 `0011` et nous obtenons `00100011`. Il n’est pas possible de faire pareil en décimal.

En résumé, les représentations octale et hexadécimale permettent de représenter un nombre binaire de manière plus concise et plus lisible.

# Constantes octales et hexadécimales

Il vous est possible de préciser la base d’une constante entière en utilisant des préfixes. Ces préfixes sont `0` pour les constantes octales et `0x` ou `0X` pour les constantes hexadécimales.

```c
long a = 65535; /* En décimal */
int b = 0777; /* En octal */
short c = 0xFF; /* En hexadécimal */
```

[[information]]
| Les lettres utilisées pour la représentation hexadécimale peuvent être aussi bien écrites en minuscule qu’en majuscule.

[[question]]
| Il n’est pas possible d’utiliser une constante en base deux ?

Malheureusement, non, le langage C ne permet pas d’utiliser de telles constantes.