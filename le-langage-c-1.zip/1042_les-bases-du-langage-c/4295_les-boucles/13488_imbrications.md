Il est parfaitement possible d’**imbriquer** une ou plusieurs boucles en plaçant une boucle dans le corps d’une autre boucle.

```c
int i;
int j;

for (i = 0 ; i < 1000 ; ++i)
{
    for (j = i ; j < 1000 ; ++j)
    {
          /*  Code  */
    }
}
```

Cela peut servir par exemple pour déterminer la liste des nombres dont le produit vaut mille.

```c
#include <stdio.h>


int main(void)
{
    int i;
    int j;

    for (i = 0 ; i <= 1000 ; ++i)
    {
        for (j = i ; j <= 1000 ; ++j)
            if (i * j == 1000) 
                printf ("%d * %d = 1000 \n", i, j);
    }

    return 0;
}
```

```text
1 * 1000 = 1000 
2 * 500 = 1000 
4 * 250 = 1000 
5 * 200 = 1000 
8 * 125 = 1000 
10 * 100 = 1000 
20 * 50 = 1000 
25 * 40 = 1000 
```

[[information]]
| Vous n’êtes bien entendu pas tenu d’imbriquer des types de boucles identiques. Vous pouvez parfaitement plaçer, par exemple, une boucle `while` dans une boucle `for`.