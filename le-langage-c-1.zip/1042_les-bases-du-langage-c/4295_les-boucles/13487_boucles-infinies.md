Lorsque vous utilisez une boucle, il y a une chose que vous devez impérativement vérifier : elle doit pouvoir se terminer. Cela paraît évident de prime abord, pourtant il s’agit d’une erreur de programmation assez fréquente qui donne lieu à des **boucles infinies**. Soyez donc vigilants !

L’exemple le plus fréquent est l’oubli d’incrémentation de l’itérateur.

```c
#include <stdio.h>

int main(void)
{
    int i = 0;

    while (i < 5)
    {
        printf("La variable i vaut %d\n", i);
        /* Oubli d'incrémentation */
    }

    return 0;
}
```

```console
La variable i vaut 0
La variable i vaut 0
La variable i vaut 0
...
```

Ce code continuera jusqu’à ce que l’utilisateur arrête le programme.