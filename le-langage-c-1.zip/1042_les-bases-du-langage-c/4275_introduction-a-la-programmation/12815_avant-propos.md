# Esprit et but du tutoriel

Ce cours a été écrit dans un seul but : vous enseigner le langage C de la manière la plus complète, la plus rigoureuse et la plus instructive possible. Pour ce faire, celui-ci combinera théorie, détails techniques et exercices pratiques. Dès lors, nous ne vous le cachons pas : cette approche va réclamer de votre part des **efforts**, certains passages étant assez complexes.

Nous avons choisi cette méthode d’apprentissage, car c’est celle que nous jugeons la plus profitable. Elle s’oppose à une autre, plus fréquente et plus superficielle, qui permet certes d’acquérir des connaissances rapidement, mais qui s’avère bien souvent peu payante sur le long terme.

En effet, beaucoup de programmeurs débutants se retrouvent ainsi perdus lorsqu’ils sont jetés dans la jungle de la programmation à la fin d’un cours, ceux-ci manquant souvent de connaissances techniques, de (bonnes) pratique(s) et de rigueur.

Ne soyez toutefois pas apeuré, notre objectif n’est pas de vous noyer d’informations ou de vous perdre avec des termes techniques. Nous vous précisons simplement que ce cours nécessite d’avoir les doigts sur le clavier et non dans le nez et que le début risque d’être un peu moins « *cool* » que ce que vous pourrez trouver ailleurs. ;)

# À qui est destiné ce cours ?

À n’importe quelle personne intéressée : que vous soyez un(e) programmeur(euse) expérimenté(e), un(e) total(e) débutant(e) ou que vous vouliez réviser certaines notions du C, vous êtes tous et toutes les
bienvenus(es). Les explications seront les plus claires possibles afin de rendre la lecture accessible à tous.

Toutefois, quelques qualités sont opportunes pour arriver au bout de ce cours :

* De la **motivation** : ce cours va présenter de nombreuses notions, souvent théoriques, et qui sembleront parfois complexes. Il vous faut donc être bien motivés pour profiter pleinement de cet apprentissage.  
* De la **logique** : apprendre la programmation, c’est aussi être logique. Bien sûr, ce cours vous apprendra à mieux l’être, mais il faut néanmoins savoir réfléchir par soi-même et ne pas compter sur les autres pour faire le travail à sa place.  
* De la **patience** : vous vous apprêtez à apprendre un langage de programmation. Pour arriver à un sentiment de maîtrise, il va vous falloir de la patience pour apprendre, comprendre, vous entraîner, faire des erreurs et les corriger.
* De la **rigueur** : cette qualité, nous allons tenter de vous l’inculquer à travers ce cours. Elle est très importante, car c’est elle qui fera la différence entre un bon et un mauvais programmeur.
* De la **curiosité** : n’hésitez pas à apporter des modifications aux codes proposés et à sortir un peu des balises du cours, cela ne vous sera que profitable.
* De la **passion** : le plus important pour suivre ce tutoriel, c’est de prendre plaisir à programmer. Amusez-vous en codant, c’est le meilleur moyen de progresser !

À noter qu’un niveau acceptable en anglais est un plus indéniable, beaucoup de cours, de forums et de documentations étant rédigés en anglais. Si ce n’est pas le cas, gardez ceci à l’esprit : en programmation, vous y serez confrontés tôt ou tard.

Enfin, un dernier point au sujet des mathématiques : contrairement à la croyance populaire, un bon niveau en maths n’est absolument pas nécessaire pour faire de la programmation. Certes, cela peut vous aider en développant votre logique, mais si les mathématiques ne sont pas votre fort, vous pourrez suivre ce cours sans problèmes.

# Aller plus loin

Un des concepts fondamentaux de l’apprentissage de notions informatiques sur Internet est le *croisement des sources*. Il permet de voir la programmation sous un angle différent. Par exemple, quelques cours de [Developpez](http://c.developpez.com/cours/?page=lang-c) recourant à des approches différentes sont à votre entière disposition. N’hésitez pas non plus à lire des livres sur le C, notamment le [K&R](http://en.wikipedia.org/wiki/The_C_Programming_Language), écrit par les auteurs du langage (une version traduite en français est disponible [aux éditions Dunod](http://www.dunod.com/informatique-multimedia/developpement/cc/ouvrages-denseignement/le-langage-c)). C’est un livre qui pourra vous être utile.