Malgré tous ces langages de programmation disponibles nous allons, dans ce tutoriel, nous concentrer sur un seul d’entre-eux : le C. Avant de parler des caractéristiques de ce langage et des choix qui nous amènent à l’étudier dans ce cours, faisons un peu d’histoire.

# L’histoire du C

Le langage C est né au début des années 1970 dans les laboratoires de la société AT&T aux États-Unis. Son concepteur, [Dennis MacAlistair Ritchie](http://fr.wikipedia.org/wiki/Dennis_Ritchie), souhaitait améliorer un langage existant, le B, afin de lui adjoindre des nouveautés. En 1973, le C était pratiquement au point et il commença à être distribué l’année suivante. Son succès fut tel auprès des informaticiens qu’en 1989, l’ANSI, puis en 1990, l’ISO, décidèrent de le normaliser, c’est-à-dire d’établir des règles internationales et officielles pour ce langage. À l’heure actuelle, il existe trois normes : la norme ANSI C89 ou ISO C90, la norme ISO C99 et la norme ISO C11.

*[AT&T]: American Telephone and Telegraph Company
*[ANSI]: American National Standards Institute
*[ISO]: International Organization for Standardization

[[information]]
| Si vous voulez en savoir plus sur l’histoire du C, lisez donc [ce tutoriel](http://c.developpez.com/cours/historique-langage-c/).

# Pourquoi apprendre le C ?

C’est une très bonne question. :D  
Après tout, étant donné qu’il existe énormément de langages différents, il est légitime de se demander pourquoi choisir le C en particulier ? Il y a plusieurs raisons à cela.

* Sa **popularité** : le C fait partie des langages de programmation les plus utilisés. Il possède une communauté très importante, de nombreux cours et beaucoup de documentations. Vous aurez donc toujours du monde pour vous aider. De plus, il existe un grand nombre de programmes et de bibliothèques développés en C.	
* Sa **rapidité** : le C est connu pour être un langage très rapide, ce qui en fait un langage de choix pour tout programme où la vitesse d’exécution est cruciale.
* Sa **simplicité** : le C est un langage minimaliste pourvu de peu de concepts ce qui permet d’en faire le tour *relativement* rapidement et d’éviter un niveau d’abstraction trop important.
* Sa **légèreté** : le C est léger, ce qui le rend utile pour les programmes embarqués où la mémoire disponible est faible.	 
* Sa **portabilité** : cela signifie qu’un programme développé en C peut être compilé pour fonctionner sur différentes machines sans devoir changer ledit code.

Ce ne sont que quelques raisons, mais elles sont à notre goût suffisantes pour justifier l’apprentissage de ce langage. Bien entendu, le C comporte aussi sa part de défauts. On peut citer la tolérance aux comportements dangereux qui fait que le C demande de la rigueur pour ne pas tomber dans certains « pièges », un nombre plus restreint de concepts (c’est parfois un désavantage, car on est alors obligé de recoder certains mécanismes qui existent nativement dans d’autres langages), etc. D’ailleurs, si votre but est de développer rapidement des programmes amusants, sachez que le C n’est pas adapté pour cela et que nous vous conseillons, dans ce cas, de vous tourner vers d’autres langages, comme par exemple le [Python](https://zestedesavoir.com/tutoriels/799/apprendre-a-programmer-avec-python-3/) ou le [Ruby](https://zestedesavoir.com/tutoriels/634/une-introduction-a-ruby/).

Le C possède aussi une caractéristique qui est à la fois un avantage et un défaut : il s’agit d’un langage dit de « **bas niveau** ». Cela signifie qu’il permet de programmer en étant « proche de sa machine », c’est-à-dire sans trop vous cacher son fonctionnement interne. Cette propriété est à double tranchant : d’un côté elle rend l’apprentissage plus difficile et augmente le risque d’erreurs ou de comportements dangereux, mais de l’autre elle vous laisse une grande liberté d’action et vous permet d’en apprendre plus sur le fonctionnement de votre machine. Cette notion de « bas niveau » est d’ailleurs à opposer aux langages dit de « **haut niveau** » qui permettent de programmer en faisant abstraction d’un certain nombre de choses. Le développement est rendu plus facile et plus rapide, mais en contrepartie, beaucoup de mécanisme interne sont cachés et ne sont pas accessibles au programmeur. Ces notions de haut et de bas niveau sont néanmoins à nuancer, car elles dépendent du langage utilisé et du point de vue du programmeur (par exemple, par rapport au langage machine, le C est un langage de haut niveau). 

Une petite note pour terminer : peut-être avez-vous entendu parler du **C++** ? Il s’agit d’un langage de programmation qui a été inventé dans les années 1980 par [Bjarne Stroustrup](https://en.wikipedia.org/wiki/Bjarne_Stroustrup), un collègue de Dennis Ritchie, qui souhaitait rajouter des éléments au C. Bien qu’il fût très proche du C lors de sa création, le C++ est aujourd’hui un langage très différent du C et n’a pour ainsi dire plus de rapport avec lui (si ce n’est une certaine proximité au niveau d’une partie de sa syntaxe). Ceci est encore plus vrai en ce qui concerne la manière de programmer et de raisonner qui sont *radicalement* différentes.

Ne croyez toutefois pas, comme peut le laisser penser leur nom ou leur date de création, qu’il y a un langage meilleur que l’autre, ils sont simplement *différents*. Si d’ailleurs votre but est d’apprendre le C++, nous vous encourageons à le faire. En effet, contrairement à ce qui est souvent dit ou lu, *il n’y a pas besoin de connaitre le C pour apprendre le C++*.

# La norme

Comme précisé plus haut, le C est un langage qui a été normalisé à trois reprises. Ces normes servent de référence à tous les programmeurs et les aident chaque fois qu’ils ont un doute ou une question en rapport avec le langage. Bien entendu, elle ne sont pas parfaites et ne répondent pas à toutes les questions, mais elles restent *la* référence pour tout programmeur. 

Ces normes sont également indispensables pour les compilateurs. En effet, le respect de ces normes par les différents compilateurs permet qu'il n'y ait pas de différences d’interprétation d’un même code. Finalement, ces normes sont l’équivalent de nos règles d’orthographe, de grammaire et de conjugaison. Imaginez si chacun écrivait ou conjuguait à sa guise, ce serait un sacré bazar…

Dans ce cours, nous avons décidé de nous reposer sur la norme ANSI C89 (ou ISO C90, c'est pareil). En effet, même s’il s’agit de la plus ancienne, elle nous permettra néanmoins de développer avec n’importe quel compilateur et sous n'importe quel système sans problèmes et sans nous poser de questions sur la présence ou non de telle ou telle fonctionnalité.

Rassurez-vous néanmoins : le fait de nous baser sur la norme C89 ne signifie pas que vous allez découvrir une version obsolète du langage C. En effet, d'une part, ce que vous allez voir tout au long de ce cours est toujours valable au regard des normes plus récentes et, d'autre part, les changements induits par les autres normes sont le plus souvent mineurs et consistent pour ainsi dire tous en des *ajouts* et non en des modifications. De ce fait, il vous sera aisé, une fois ce cours parcouru, de passer à une norme plus récente.

[[information]]
| Pour les curieux, voici [un lien](http://flash-gordon.me.uk/ansi.c.txt) vers le brouillon de cette norme. Cela signifie qu’il ne s’agit pas de la version définitive et officielle, cependant il est largement suffisant pour notre niveau et, surtout, il est gratuit (la norme officielle coûtant *très* cher :-° ). Notez que celui-ci est rédigé en anglais.