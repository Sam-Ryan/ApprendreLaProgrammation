[[information]]
| Dans cette section, nous nous contenterons d'une présentation succinte qui est suffisante pour vous permettre de poursuivre la lecture de ce cours. Toutefois, si vous souhaitez un propos plus étayé, nous vous conseillons la lecture du [cours d'introduction à la programmation](https://zestedesavoir.com/tutoriels/531/les-bases-de-la-programmation/) présent sur ce site.

La programmation est une branche de l’informatique qui sert à créer des **programmes**. Tout ce que vous possédez sur votre ordinateur est un programme : votre navigateur Internet (Internet Explorer, Firefox, Opera, etc.), votre système d’exploitation (Windows, GNU/Linux, Mac OS X, etc.) qui est un regroupement de plusieurs programmes appelés **logiciels**, votre lecteur MP3, votre logiciel de discussion instantanée, vos jeux vidéos, etc.

# Les programmes expliqués en long, en large et en travers

Un programme est une séquence d’**instructions**, d’ordres, donnés à l’ordinateur afin qu’il exécute des actions. Ces instructions sont généralement assez basiques. On trouve ainsi des instructions d’addition, de multiplication, ou d’autres opérations mathématiques de base, qui font que notre ordinateur est une vraie machine à calculer. D’autres instructions plus complexes peuvent exister, comme des opérations permettant de comparer des valeurs, traiter des caractères, etc.

Créer un programme, c’est tout simplement utiliser une suite d’instructions de base qui permettra de faire ce que l’on veut. Tous les programmes sont créés ainsi : votre lecteur MP3 donne des instructions à l’ordinateur pour écouter de la musique, le *chat* donne des instructions pour discuter avec d’autres gens sur le réseau, le système d’exploitation donne des instructions pour dire à l’ordinateur comment utiliser le matériel, etc.

[[information]]
| Notez qu’il n’est pas possible de créer des instructions. Ces dernières sont imprimées dans les circuits de l’ordinateur ce qui fait qu’il ne peut en gérer qu’un nombre précis et qu’il ne vous est donc pas loisible d’en construire de nouvelles (sauf cas particuliers vraiment tordus).

Notre ordinateur contient un composant électronique particulier, spécialement conçu pour exécuter ces instructions : le **processeur**. Ce qu’il faut retenir, c’est que notre ordinateur contient un circuit, le processeur, qui permet d’effectuer de petits traitements de base qu’on appelle des instructions et qui sont la base de tout ce qu’on trouve sur un ordinateur.

Les instructions sont stockées dans notre ordinateur sous la forme de chiffres binaires (appelés *bits* en anglais), autrement dit sous forme de zéros ou de uns. Ainsi, nos instructions ne sont rien d’autre que des suites de zéros et de uns conservées dans notre ordinateur et que notre processeur va interpréter comme étant des ordres à exécuter. Ces suites de zéros et de uns sont difficilement compréhensibles pour nous, humains, et parler à l’ordinateur avec des zéros et des uns est très fastidieux et très long. Autant vous dire que créer des programmes de cette façon revient à se tirer une balle dans le pied.

Pour vous donner un exemple, imaginez que vous deviez communiquer avec un étranger alors que vous ne connaissez pas sa langue. Communiquer avec un ordinateur reviendrait à devoir lui donner une suite de zéros et de uns, ce dernier étant incapable de comprendre autre chose. Ce langage s’appelle  le **langage machine**.

Une question doit certainement vous venir à l’esprit : comment communiquer avec notre processeur sans avoir à apprendre sa langue ?

L’idéal serait de parler à notre processeur en français, en anglais, etc, mais disons-le clairement : notre technologie n’est pas suffisamment évoluée et nous avons dû trouver autre chose. La solution retenue a été de créer des langages de programmation plus évolués que le langage machine, plus faciles à apprendre et de fournir le traducteur qui va avec. Il s’agit de langages assez simplifiés, souvent proches des langages naturels et dans lesquels on peut écrire nos programmes beaucoup plus simplement qu’en utilisant le langage machine. Grâce à eux, il est possible d’écrire nos programmes sous forme de texte, sans avoir à se débrouiller avec des suites de zéros et de uns totalement incompréhensibles. Il existe de nombreux langages de programmation et l’un d’entre-eux est le **C**.

Reste que notre processeur ne comprend pas ces langages évolués et n’en connaît qu’un seul : le sien. Aussi, pour utiliser un langage de programmation, il faut disposer d’un traducteur qui fera le lien entre celui-ci et le langage machine du processeur. Ainsi, il ne vous est plus nécessaire de connaître la langue de votre processeur. En informatique, ce traducteur est appelé un **compilateur**.

Pour illustrer notre propos, voici un code écrit en C (que nous apprendrons à connaître).

```c
#include <stdio.h>

int main(void)
{
    printf("Salut !\n");
    return 0;
}
```

Et le même en langage machine (plus précisémment pour un processeur de la famille x86-64).

```text
01010101 01001000 10001001 11100101 10111111 00100100
00101100 01001000 00000000 10111000 00000000 00000000
00000000 00000000 11101000 10011101 00001011 00000000
00000000 10111000 00000000 00000000 00000000 00000000
01011101 01010011 01100001 01101100 01110101 01110100
00100000 00100001 00001010 00000000
```

Nous y gagnons tout de même au change, non ? :p