L’algorithmique est liée à la programmation et constitue même une branche à part des mathématiques. Elle consiste à définir et établir des **algorithmes**.

Un algorithme peut se définir comme étant une suite finie et non-ambiguë d’opérations permettant de résoudre un problème. En clair, il s’agit de calculs qui prennent plusieurs paramètres et fournissent un résultat. Les algorithmes ne sont pas limités à l’informatique, ils existaient même avant son apparition ; prenez les recettes de cuisine par exemple, ou des instructions de montage d’un meuble ou d’un Lego, ce sont des algorithmes.

L’intérêt principal des algorithmes est qu’ils sont très utiles lorsqu’ils sont en relation avec des ordinateurs. En effet, ces derniers peuvent exécuter des milliards d’instructions à la seconde, ce qui les rend bien plus rapides qu’un humain. Illustrons : imaginez que vous deviez trier une liste de dix nombres dans l’ordre croissant. C’est assez facile et faisable en quelques secondes. Et pour plusieurs milliards de nombres ? C’est impossible pour un humain, alors qu’un ordinateur le fera rapidement.

Ce qu’il faut retenir, c’est qu’un algorithme est une suite d’opérations destinée à résoudre un problème donné. Nous aurons l’occasion d’utiliser quelques algorithmes dans ce cours, mais nous ne nous concentrerons pas dessus. Si vous voulez en savoir plus, lisez le tutoriel sur [l’algorithmique pour l’apprenti programmeur](/tutoriels/621/algorithmique-pour-lapprenti-programmeur/) en même temps que vous apprenez à programmer avec celui-ci.

# Le pseudo-code

Pour représenter un algorithme indépendamment de tout langage, on utilise ce qu’on appelle un **pseudo-code**. Il s’agit de la description des étapes de l’algorithme en langage naturel (dans notre cas le français). Voici un exemple de pseudo-code.

```console
Fonction max (x, y)
    
    Si x est supérieur à y
        Retourner x
    Sinon 
        Retourner y

Fin fonction
```

Dans ce cours, il y aura plusieurs exercices dans lesquels un algorithme fourni devra être mis en œuvre, traduit en C. Si vous voulez vous entrainer davantage tout en suivant ce cours, nous vous conseillons [France-IOI](http://www.france-ioi.org/) qui permet de mettre en application divers algorithmes dans plusieurs langages, dont le C. Cela pourra être un excellent complément.