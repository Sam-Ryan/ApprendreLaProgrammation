# Le compilateur

Allez dans le dossier `/Applications/Utilitaires` et lancez l’application « terminal.app ». Une fois ceci fait, entrez la commande suivante :

```text
xcode-select --install
```

et cliquez sur « installer » dans la fenêtre qui apparaît. Si vous rencontrez le message d’erreur ci-dessous, cela signifie que vous disposez déjà des logiciels requis.

```text
Impossible d’installer ce logiciel car il n’est pas disponible actuellement depuis le serveur de mise à jour de logiciels.
```


Si vous ne disposez pas de la commande indiquée, alors rendez-vous sur le site de développeur d’Apple : [*Apple developer connection*](https://developer.apple.com/). Il faudra ensuite vous rendre sur le « *mac dev center* » puis, dans « *additional download* », cliquez sur « *view all downloads* ». Quand vous aurez la liste, il vous suffit de chercher la version 3 de Xcode (pour Leopard et Snow Leopard) ou 2 pour les versions antérieures (Tiger). Vous pouvez aussi utiliser votre CD d’installation pour installer Xcode (sauf pour Lion).

# Configuration

Voyez ce qui est dit pour GNU/Linux, *BSD et les autres Unixoïdes.

# L’éditeur de texte

Comme pour les autres Unixoïdes, vous trouverez un bon nombres d’éditeurs de texte. Si toutefois vous êtes perdu, nous vous conseillons [TextWrangler](http://www.barebones.com/products/TextWrangler/) ou [Smultron](https://www.peterborgapps.com/smultron/).

# Introduction à la ligne de commande

Référez-vous à l’introduction dédiée à GNU/Linux, *BSD et les autres Unixoïdes.