# Le compilateur

Nous vous proposons de télécharger MinGW, qui est une adaptation pour Windows du compilateur GCC.

Rendez-vous sur le [site de MinGW](http://www.mingw.org/) dans la section « *download* » et cliquez sur le lien en haut de la page « *looking for the latest version ? Download mingw-get-install-xxxxxxxx.exe (xxx.x kB)* ».

Exécutez le programme, cliquez sur « *install* », décochez la case « *also install support for graphical user interface* » et enfin cliquez sur « *continue* ».

Ceci étant fait, il nous faut désormais créer une variable d’environnement afin de spécifier à notre invite de commande le chemin vers les différents composants de MinGW.

* sous Windows XP et antérieur, faites un clic-droit sur « poste de travail » puis choisissez « propriétés ». Dans la fenêtre qui s’ouvre, cliquez sur « avancés » puis sur « variables d’environnement » ;
* sous Windows Vista, Seven, faites un clic-droit sur l’icône « ordinateur » dans le menu « démarrer » ou bien sur « poste de travail ». Ensuite, cliquez sur « paramètres systèmes avancés ». Dans la nouvelle fenêtre qui s’ouvre, cliquez sur « variables d’environnement » ;
* sous Windows 8, rendez-vous dans le panneau de configuration à la rubrique « système ». Cliquez sur « avancé » puis sur « variables d’environnement ».

Dans la partie « utilisateur courant », créez une nouvelle variable nommée `PATH` et donnez lui pour valeur : `%PATH%;C:\MinGW\bin` (le chemin après le point-virgule peut varier en fonction de où vous avez décidés d’installer MinGW, l’important est de bien avoir le répertoire `bin` à la fin).

À présent, exécutez l’invite de commandes (il est situé dans les accessoires sous le même nom) et entrez la ligne suivante.

```text
mingw-get install gcc gdb
```

Le compilateur et le débogueur sont à présent installés. À présent, lancez le bloc-note et placez y le texte suivant.

```text
@echo off
gcc -D__USE_MINGW_ANSI_STDIO=1 -Wall -Wextra -pedantic -std=c89 -fno-common -fno-builtin %*
```

Ensuite, enregistrez ce fichier dans le dossier « bin » de MinGW (par défaut `C:\MinGW\bin`) sous le nom « zcc.bat » en choisissant « autres types de fichiers ».

Maintenant, rendez-vous dans le menu des accessoires, réalisez un clic droit sur l'invite de commande et sélectionnez « propriétés ». Dans l'onglet « raccourci », remplacer le champ « cible » par « %windir%\system32\cmd.exe /k "chcp 65001" ». Enfin, dans l'onglet « police », choisissez « Consolas » ou « Lucida Console » et adaptez la taille suivant vos envies.

# L’éditeur de texte

L’éditeur de texte va nous permettre d’écrire notre code source et de l’enregistrer. L’idéal est d’avoir un éditeur de texte facile à utiliser et pas trop minimaliste. Si jamais vous avez déjà un éditeur de texte et que vous l’appréciez, n'en changez pas, il fera sûrement l'affaire.

Si vous n’avez pas d’idée, nous vous conseillons [Notepad++](http://notepad-plus-plus.org/fr/) qui est simple, pratique et efficace. Pour le télécharger, rendez-vous simplement dans la rubrique « Téléchargements » du menu principal.

[[attention]]
| Veillez-bien à ce que l’encodage de votre fichier soit « UTF-8 (sans BOM) » (voyez le menu éponyme à cet effet).

# Introduction à la ligne de commande

La ligne de commande, derrière son aspect rustre et archaïque, n’est en fait qu’une autre manière de réaliser des tâches sur un ordinateur. La différence majeure avec une interface graphique étant que les instructions sont données non pas à l’aide de boutons et de cliques de souris, mais exclusivement à l’aide de texte. Ainsi, pour réaliser une tâche donnée, il sera nécessaire d’invoquer un programme (on parle souvent de **commandes**) en tapant son nom.

La première chose que vous devez garder à l’esprit, c’est le dossier dans lequel vous vous situez. Celui-ci est indiqué au tout début de chaque ligne et se termine par le symbole `>`. Ce dossier est celui dans lequel les actions (par exemple la création d’un répertoire) que vous demanderez seront réalisées. Normalement, par défaut, vous devriez vous situez dans le répertoire `C:\Users\Utilisateur` (où `Utilisateur` correspond à votre nom d’utilisateur). Ceci étant posé, voyons quelques commandes basiques.

La commande `mkdir` (pour *make directory*) vous permet de créer un nouveau dossier. Pour ce faire, tapez `mkdir` suivi d’un espace et du nom du nouveau répertoire. Par exemple, vous pouvez créer un dossier « Programmation » comme suit.

```text
C:\Users\Utilisateur> mkdir Programmation
```

La commande `dir` (pour *directory*) vous permet de lister le contenu d’un dossier. Vous pouvez ainsi vérifier qu’un nouveau répertoire a bien été créé.

```text
C:\Users\Utilisateur> dir
Répertoire de C:\Users\Utilisateur

30/03/2015  17:00    <REP>          .
30/03/2015  17:00    <REP>          ..
30/03/2015  17:00    <REP>          Programmation
```

[[information]]
| Le résultat ne sera pas forcément le même que ci-dessus, cela dépend du contenu de votre dossier. L’essentiel est que vous retrouviez bien le dossier que vous venez de créer.

Enfin, la commande `cd` (pour *change directory*) vous permet de vous déplacer d’un dossier à l’autre. Pour ce faire, spécifiez simplement le nom du dossier de destination.

```text
C:\Users\Utilisateur> cd Programmation
C:\Users\Utilisateur\Programmation>
```

[[information]]
| Le dossier spécial « **..** » représente le répertoire parent. Il vous permet donc de revenir en arrière dans la hiérarchie des dossiers. Le dossier spécial « **.** » représente quant à lui le dossier courant.

Voilà, avec ceci, vous êtes fin prêt pour compiler votre premier programme. Vous pouvez vous rendre à la deuxième partie de ce chapitre.


*[MinGW]: Minimalist GNU for Windows
*[GCC]: GNU Compiler Collection