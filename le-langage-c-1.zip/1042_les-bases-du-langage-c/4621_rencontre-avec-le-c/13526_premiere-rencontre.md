Bien, il est à présent temps d’écrire et de compiler notre premier programme ! Pour ce faire, ouvrez votre éditeur de texte et entrez les lignes suivantes.

```c
int main(void)
{
    return 0;
}
```

Ensuite, enregistrez ce fichier dans un dossier de votre choix et nommez-le « main.c ». Une fois ceci fait, rendez-vous dans le dossier contenant le fichier à l’aide d’un terminal et exécutez la commande ci-dessous.

```text
zcc main.c
```

[[attention]]
| Si vous n’êtes pas sous Windows et que vous utilisez l’interprétateur de commande `sh`, `ksh` ou `zsh`, la commande `zcc` ne sera connue de votre invite de commande qu’une fois que vous aurez ouvert une nouvelle session. En attendant, vous pouvez entrez la commande `alias zcc='gcc -Wall -Wextra -pedantic -std=c89 -fno-common -fno-builtin'` dans votre terminal pour que cela fonctionne.

Si tout se passe bien, vous devriez obtenir un fichier « a.exe » sous Windows et un fichier « a.out » sinon. Vous pouvez exécutez ce programme en tapant `a.exe` ou `./a.out`.

[[question]]
| Je viens de le faire, mais il ne se passe rien…

Cela tombe bien, c’est exactement ce que fait ce programme : rien. :p  
Voyons cela plus en détails.

Ce bout de code est appelé une **fonction**. Un programme écrit en C n’est composé pratiquement que de fonctions qui sont des morceaux de programme donnant des instructions à l’ordinateur. Elles ont toujours un objectif, une *fonction* particulière, par exemple calculer la racine carrée d’un nombre.

Notre fonction s’appelle `main` (prononcez « mèïne »). C’est la fonction de base commune à tous les programmes en C, le programme commence et finit toujours par elle.

Une fonction est délimitée par des accolades (`{` et `}`). Après les accolades, il n’y a rien, car pour l’instant nous n’avons que la fonction `main`.

Le nom de la fonction est précédé du mot-clé `int` qui est un nom de type (nous verrons cette notion au chapitre suivant) qui indique que la fonction retourne une valeur entière. À l’intérieur des parenthèses, il y a le mot `void` qui signifie que la fonction ne reçoit pas de paramètres, nous y reviendrons en temps voulu.

Enfin, la fonction se termine par l’instruction `return 0` qui signifie en l’occurrence que la fonction a terminé son travail (bon, pour l’instant elle n’en a pas, mais nous y arriverons rapidement) et que tout s’est bien passé.