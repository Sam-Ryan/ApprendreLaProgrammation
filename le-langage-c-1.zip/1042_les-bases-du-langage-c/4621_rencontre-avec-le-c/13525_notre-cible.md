Avant de commencer à programmer, il nous faut aussi définir ce que nous allons programmer, autrement dit le type de programme que nous allons réaliser. Il existe en effet deux grands types de programmes : les programmes **graphiques** et les programmes **en console**.

Les programmes graphiques sont les plus courants et les plus connus puisqu’il n’y a pratiquement qu’eux sous Windows ou Mac OS X par exemple. Vous en connaissez sans doute énormément tel que les lecteurs de musique, les navigateurs Internet, les logiciels de discussions instantanées, les suites bureautiques, les jeux vidéos, etc. Ce sont tous des programmes graphiques, ou programmes GUI. En voici un exemple sous GNU/Linux.

![L’éditeur d’images vectorielles Inkscape est un programme graphique](/media/galleries/1501/3bb7ecca-f38e-4c21-8c9d-03969b5faf11.png.960x960_q85.jpg)

Cependant, écrire ce genre de programmes demande beaucoup de connaissances, ce qui nous manque justement pour l’instant. Aussi, nous allons devoir nous rabattre sur le deuxième type de programme : les programmes en console.

Les programmes console sont les premiers programmes et sont apparus en même temps que l’écran. Ils étaient très utilisés dans les années 1970/1980 (certains d’entre vous se souviennent peut-être de MS-DOS), mais ont fini par être remplacés par une interface graphique avec la sortie de Mac OS et de Windows. Cependant, ils existent toujours et redeviennent quelque peu populaires chez les personnes utilisant GNU/Linux ou un *BSD.

Voici un exemple de programme en console (il s’agit de [GNU Chess](http://www.gnu.org/software/chess/), un jeu d’échecs performant entièrement en ligne de commande).

```text
White (1) : d4
1. d4

black  KQkq  d3
r n b q k b n r 
p p p p p p p p 
. . . . . . . . 
. . . . . . . . 
. . . P . . . . 
. . . . . . . . 
P P P . P P P P 
R N B Q K B N R 

Thinking...

white  KQkq
r n b q k b . r 
p p p p p p p p 
. . . . . n . . 
. . . . . . . . 
. . . P . . . . 
. . . . . . . . 
P P P . P P P P 
R N B Q K B N R 


My move is : Nf6
White (2) :
```

Ce sera le type de programme que nous allons apprendre à créer. Rassurez-vous, quand vous aurez fini le cours, vous aurez les bases pour apprendre à créer des programmes graphiques. Tout est possible.

*[GUI]: Graphical User Interface