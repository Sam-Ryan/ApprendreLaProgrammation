# Précisions concernant scanf

[[question]]
| Pourquoi uiliser la notation polonaise inverse et non l’écriture habituelle ?

Parce qu’elle va vous permettre de bénéficier d’une caractéristique intéressante de la fonction `scanf()` : sa valeur de retour. Nous anticipons un peu sur les chapitres suivants, mais sachez que la fonction `scanf()` retourne une valeur entière qui correspond au nombre de conversions réussies. Une conversion est réussie si ce qu’entre l’utilisateur correspond à l’indicateur de conversion.

Ainsi, si nous souhaitons récupérer un entier à l’aide de l’indicateur `d`, la conversion sera réussie si l’utilisateur entre un nombre (par exemple 2) alors qu’elle échouera s’il entre une lettre ou un signe de ponctuation.

Grâce à cela, vous pourrez détecter facilement s’il manque ou non un opérande pour une opération.

[[attention]]
| Lorsqu’une conversion échoue, la fonction `scanf()` arrête son exécution. Aussi, s’il y avait d’autres conversions à effectuer après celle qui a avorté, elles ne seront pas réalisée.

```c
double a;
double b;
char op;

scanf("%lf %lf %c", &a, &b, &op);
```

Dans le code ci-dessus, si l’utilisateur entre `7 *`, la fonction `scanf()` retournera 1 et n’aura lu que le nombre 7. Il sera nécessaire de l’appeler une seconde fois pour que le symbole `*` soit récupéré.

[[information]]
| Petit bémol tout de même : les symboles `+` et `-` sont considérés comme des débuts de nombre valables (puisque vous pouvez par exemple entrer -2). Dès lors, si vous souhaitez additionner ou soustraire un nombre au résultat de l’opération précédente, vous devrez doubler ce symbole. Pour ajouter cinq cela donnera donc : `5 ++`.

# Les puissances

Pour élever une nombre à une puissance donnée (autrement dit, pour calculer $x^y$), nous allons avoir besoin d’une nouvelle partie de la bibliothèque standard dédiée aux fonctions mathématiques de base. Le fichier d’en-tête de la bibliothèque mathématique se nomme `<math.h>` et contient, entre autre, la déclaration de la fonction `pow()`.

```c
double pow(double x, double y);
```

Cette dernière prends deux arguments : la base et l’exposant.

[[attention]]
| L’utilisation de la bibliothèque mathématique requiert d’ajouter l’option `-lm` lors de la compilation, par exemple comme ceci : `zcc -lm main.c`

# La factorielle

La factorielle d’un nombre est égal au produit des nombres entiers *positifs et non nuls* inférieurs ou égaux à ce nombre. La factorielle de quatre équivaut donc à `1 * 2 * 3 * 4`, donc vingt-quatre. Cette fonction n’est pas fournie par la bibliothèque standard, il vous faudra donc la programmer par vous-même (pareil pour le PGCD et le PPCD que nous avons vus dans les chapitres précédents).

[[information]]
| Par convention, la factorielle de zéro est égale à un.

# Exemple d’utilisation

```text
> 5 6 +
11.000000
> 4 *
44.000000
> 2 /
22.000000
> 5 2 %
1.000000
> 2 5 ^
32.000000
> 1 ++
33.000000
> 5 !
120.000000
```

# Derniers conseils

Nous vous conseillons de récupérer les nombres sous forme de `double`. Cependant, gardez bien à l’esprit que certaines opérations ne peuvent s’appliquer qu’à des entiers : le reste de la division entière, la factorielle, le PGCD et le PPCD. Il vous sera donc nécessaire d’effectuer des conversions.

Également, notez bien que la factorielle ne s’applique qu’à *un seul* opérande à l’inverse de toutes les autres opérations.

Bien, vous avez à présent toutes les cartes en main : au travail ! :)