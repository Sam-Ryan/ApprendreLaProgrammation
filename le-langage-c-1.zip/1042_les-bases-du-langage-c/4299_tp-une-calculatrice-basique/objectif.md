Votre objectif sera de réaliser une calculatrice basique pouvant calculer une somme, une soustraction, une multiplication, une division, le reste d’une division entière, une puissance, une factorielle, le PGCD et le PPCD.

Celle-ci attendra une entrée formatée suivant la [notation polonaise inverse](http://fr.wikipedia.org/wiki/Notation_polonaise_inverse). Autrement dit, les opérandes d’une opération seront entrés *avant* l’opérateur, par exemple comme ceci pour la somme de quatre et cinq : `4 5 +`.

Elle devra également retenir le résultat de l’opération précédente et déduire l’utilisation de celui-ci en cas d’omission d’un opérande. Plus précisément, si l’utilisateur entre par exemple `5 +`, vous devrez déduire que le premier opérande de la somme est le résultat de l’opération précédente (ou zéro s’il n’y en a pas encore eu).

Chaque opération se verra attribuer un symbole ou une lettre, comme suit :

* addition : `+` ;
* soustraction : `-` ;
* multiplication : `*` ;
* division : `/` ;
* reste de la division entière : `%` ;
* puissance : `^` ;
* factorielle : `!` ;
* PGCD : `g` ;
* PPCD : `p`.

Le programme doit s’arrêter lorsque la lettre « q » est spécifiée comme opération (avec ou sans opérande).