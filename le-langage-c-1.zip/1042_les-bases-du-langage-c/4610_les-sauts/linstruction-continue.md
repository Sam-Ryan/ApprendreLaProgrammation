L’instruction `continue` permet d’arrêter l’exécution de l’itération courante. Autrement dit, celle-ci vous permet de retourner (sauter) directement à l’évaluation de la condition.

## Exemple

Afin d’améliorer un peu l’exemple précédent, nous pourrions passer les cas où le diviseur testé est un multiple de deux (puisque si un des deux nombres n’est pas divisible par deux, il ne peut pas l’être par quatre, par exemple).

Ceci peut s’exprimer à l’aide de l’instruction `continue`.

```c
#include <stdio.h>


int main(void)
{
    int a;
    int b;
    int i;
    int min;

    printf("Entrez deux nombres : ");
    scanf("%d %d", &a, &b);
    min = (a < b) ? a : b;

    for (i = 2; i <= min; ++i)
    {
        if (i != 2 && i % 2 == 0)
        {
            printf("je passe %d\n", i);
            continue;
        }
        if (a % i == 0 && b % i == 0)
        {
            printf("le plus petit diviseur de %d et %d est %d\n", a, b, i);
            break;
        }
    }

    return 0;
}
```

```text
je passe 4
je passe 6
le plus petit diviseur de 112 et 567 est 7
```

[[information]]
| Dans le cas de la boucle `for`, l’exécution reprend à l’évaluation de sa deuxième expression (ici `++i`) et non à l’évaluation de la condition (qui a lieu juste après). Il serait en effet mal venu que la variable `i` ne soit pas incrémentée lors de l’utilisation de l’instruction `continue`.