Notez bien que les instructions `break` et `continue` n’affecte que l’exécution de la boucle dans laquelle elles sont situées. Ainsi, si vous utilisez l’instruction `break` dans une boucle imbriquée dans une autre, vous sortirez de la première, mais pas de la seconde.

```c
#include <stdio.h>


int main(void)
{
    int i;
    int j;

    for (i = 0 ; i <= 1000 ; ++i)
    {
        for (j = i ; j <= 1000 ; ++j)
        {
            if (i * j == 1000) 
            {
                printf ("%d * %d = 1000 \n", i, j);
                break; /* Quitte la boucle courante, mais pas la première. */
            }
        }
    }

    return 0;
}
```

```text
1 * 1000 = 1000 
2 * 500 = 1000 
4 * 250 = 1000 
5 * 200 = 1000 
8 * 125 = 1000 
10 * 100 = 1000 
20 * 50 = 1000 
25 * 40 = 1000 
```