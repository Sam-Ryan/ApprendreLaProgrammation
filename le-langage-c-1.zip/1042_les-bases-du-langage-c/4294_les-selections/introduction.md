Comme dit au chapitre précédent, les structures de contrôle permettent de modifier le comportement d’un programme suivant la réalisation de différentes conditions. Parmi ces structures de contrôle se trouvent les **instructions de sélection** (ou **sélections** en abrégé) qui vont retenir notre attention dans ce chapitre.

Le tableau ci-dessous reprend celles dont dispose le langage C.

Structure de sélection  | Action
------------- | -------------
**if…**  | exécute une suite d’instructions si une condition est respectée.
**if… else…**  | exécute une suite d’instructions si une condition est respectée ou exécute une autre suite d’instructions si elle ne l’est pas.
**switch…**  | exécute une suite d’instructions différente suivant la valeur testée.