L’**opérateur conditionnel** ou **opérateur ternaire** est un opérateur particulier dont le résultat dépend de la réalisation d’une condition. Son deuxième nom lui vient du fait qu’il est le seul opérateur du langage C à requérir trois opérandes : une condition et deux expressions.

```text
(condition) ? expression si vrai : expression si faux
```

[[information]]
| Les parenthèses entourant la condition ne sont pas obligatoires, mais préférables.

*Grosso modo*, cet opérateur permet d’écrire de manière condensée une structure `if {} else {}`. Voyez par vous-mêmes.

```c
#include <stdio.h>

int main(void)
{
    int heure;

    scanf("%d", &heure);

    (heure > 8 && heure < 20) ? printf("Il fait jour.\n") : printf("Il fait nuit.\n");
    return 0;
}
```

Il est également possible de l’écrire sur plusieurs lignes, même si cette pratique est moins courante.

```c
(heure > 8 && heure < 20)
    ? printf("Il fait jour.\n")
    : printf("Il fait nuit.\n");
```

Cet opérateur peut sembler inutile de prime abord, mais il s’avère être un allié de choix pour simplifier votre code quand celui-ci requiert la vérification de conditions simples.

# Exercice

Pour bien comprendre cette nouvelle notion, nous allons faire un petit exercice. Imaginez que nous voulions faire un mini jeu vidéo dans lequel nous affichons le nombre de coups du joueur. Seulement voilà, vous êtes maniaques du français et vous ne supportez pas qu’il y ait un « s » en trop ou en moins. Essayez de réaliser un programme qui demande à l’utilisateur d’entrer un nombre de coups puis qui affiche celui-ci correctement accordé.

[[secret]]
| ```c
| #include <stdio.h>
| 
| int main(void)
| {
|     int nb_coups;
| 
|     printf("Donnez le nombre de coups : ");
|     scanf("%d", &nb_coups);
|     printf("Vous gagnez en %d coup%c\n", nb_coups, (nb_coups > 1) ? 's' : ' ');
|     return 0;
| }
| ```

Ce programme utilise l’opérateur conditionnel pour condenser l’expression et aller plus vite dans l’écriture du code. Sans lui nous aurions dû écrire quelque chose comme ceci.

```c
#include <stdio.h>

int main(void)
{
    int nb_coups;

    printf("Donnez le nombre de coups : ");
    scanf("%d", &nb_coups);

    if (nb_coups > 1)
        printf("Vous gagnez en %d coups\n", nb_coups);
    else
        printf("Vous gagnez en %d coup\n", nb_coups);

    return 0;
}
```