Ce chapitre a été important, il vous a permis d’utiliser les conditions ; les instructions ```if``` et ```else``` ; l’instruction ```switch``` et l’opérateur conditionnel. Aussi, si vous n’avez pas très bien compris ou que vous n’avez pas tout retenu, nous vous conseillons de relire ce chapitre.

Le chapitre suivant sera l’occasion de mettre en œuvre ce que vous avez appris puisqu’il s’agira de votre premier TP.

*[TP]: Travaux Pratiques