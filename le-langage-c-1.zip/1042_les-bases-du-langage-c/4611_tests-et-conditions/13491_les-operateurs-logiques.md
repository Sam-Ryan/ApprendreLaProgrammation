Toutes ces comparaisons sont toutefois un peu faibles seules car il y a des choses qui ne sont pas possibles à vérifier en utilisant une seule comparaison. Par exemple, si un nombre est situé entre zéro et mille (inclus). Pour ce faire, il serait nécessaire de vérifier que celui-ci est supérieur ou égal à zéro **et** inférieur ou égal à mille.

Il nous faudrait donc trouver un moyen de combiner plusieurs comparaisons entre elles pour résoudre ce problème. *Hé* bien rassurez-vous, le langage C fournit de quoi associer plusieurs résultats de comparaisons : les **opérateurs logiques**.

# Les opérateurs logiques de base

Il existe trois opérateurs logiques. L’opérateur « **et** », l’opérateur « **ou** », et l’opérateur de **négation**. Les deux premiers permettent de combiner deux conditions alors que le troisième permet d’inverser le sens d’une condition.

## L’opérateur « et »

L’opérateur « et » va manipuler deux conditions. Il va donner un si elles sont vraies, et zéro sinon.

Première condition | Seconde condition | Résultat de l’opérateur « et »
------------- | ------------- | -------------
Fausse | Fausse | 0
Fausse | Vraie | 0
Vraie | Fausse | 0
Vraie | Vraie | 1

Cet opérateur s’écrit ```&&``` et s’intercale entre les deux conditions à combiner. Si nous reprenons l’exemple vu plus haut, pour combiner les comparaisons ```a >= 0``` et ```a <= 1000```, nous devons placer l’opérateur `&&` entre les deux, ce qui donne l’expression ```a >= 0 && a <= 1000```.

## L’opérateur « ou »

L’opérateur « ou » fonctionne exactement comme l’opérateur « et », il prend deux conditions et les combine pour former un résultat. Cependant, l’opérateur « ou » vérifie que l’une des deux conditions (ou que les deux) est (sont) vraie(s).

Première condition | Seconde condition | Résultat de l’opérateur « ou »
------------- | ------------- | -------------
Fausse | Fausse | 0
Fausse | Vraie | 1
Vraie | Fausse | 1
Vraie | Vraie | 1

Cet opérateur s’écrit ```||``` et s’intercale entre les deux conditions à combiner. L’exemple suivant permet de déterminer si un nombre est divisible par trois ou par cinq (ou les deux) : ```(a % 3 == 0) || (a % 5 == 0)```. Notez que les parenthèses ont été placées par soucis de lisibilité.

## L’opérateur de négation

Cet opérateur est un peu spécial : il manipule une seule condition et en inverse le sens.

Condition | Résultat de l’opérateur de négation
------------- | -------------
Fausse | 1
Vraie | 0

Cet opérateur se note ```!```. Son utilité ? Simplifier certaines expressions. Par exemple, si nous voulons vérifier cette fois qu’un nombre **n’est pas** situé entre zéro et mille, nous pouvons utiliser la condition `a >= 0 && a <= 1000` et lui appliquer l’opérateur de négation, ce qui donne `!(a >= 0 && a <= 1000)`.

[[attention]]
| Faites bien attention à l’utilisation des parenthèses ! L’opérateur de négation s’applique à l’opérande le plus proche (sans parenthèses, il s’agirait de `a`). Veillez donc a bien entourer de parenthèses l’expression concernée par la négation.

[[information]]
| Notez que pour cet exemple, il est parfaitement possible de se passer de cet opérateur à l’aide de l’expression ```a < 0 || a > 1000```. Il est d’ailleurs souvent possible d’exprimer une condition de différentes manières.

# Évaluation en court-circuit

Les opérateurs `&&` et `||` evaluent toujours la première condition avant la seconde. Cela paraît évident, mais ce n’est pas le cas dans tous les langages de programmation. Ce genre de détail permet à ces opérateurs de disposer d’un comportement assez intéressant : **l’évaluation en court-circuit**.

De quoi s’agit-il ? Pour illustrer cette notion, reprenons l’exemple précédent : nous voulons vérifier si un nombre est compris entre zéro et mille, ce qui donne l’expression ```a >= 0 && a <= 1000```. Si jamais `a` est inférieur à zéro, nous savons dès la vérification de la première condition qu’il n’est pas situé dans l’intervalle voulu. Il n’est donc pas nécessaire de vérifier la seconde. *Hé* bien, c’est exactement ce qu’il se passe en langage C. Si le résultat de la première condition suffit pour déterminer le résultat de l’opérateur `&&` ou `||`, *alors la seconde condition n’est pas évaluée*. Voilà pourquoi l’on parle d’évaluation en court-circuit.

Plus précisément, ce sera le cas pour l’opérateur `&&` si la première condition est fausse et pour l’opérateur `||` si la première condition est vraie (relisez les tableaux précédents si cela ne vous semble pas évident).

Ce genre de propriété peut-être utilisé efficacement pour éviter de faire certains calculs, en choisissant intelligemment quelle sera la première condition.

# Combinaisons

Bien sûr, il est possible de mélanger ces opérateurs pour créer des conditions plus complexes. Voici un exemple un peu plus long (et inutile, soit dit en passant :-° ).

```c
int a = 3;
double b = 64.67;
double c = 12.89;
int d = 8;
int e = -5;
int f = 42;
int r;

r = ((a < b && b > 32) || (c < d + b || e == 0)) && (f > d);
printf("La valeur logique est égale à : %d\n", r);
```

Ici, la variable `r` est égale à 1, la condition est donc vraie.

## Parenthèses

En regardant le code écrit plus haut, vous avez surement remarqué la présence de plusieurs parenthèses. Celles-ci permettent d’enlever toute ambigüité dans les expressions créées avec des opérateurs logiques. En effet, comme pour les opérateurs mathématiques, les opérateurs logiques ont une priorité (revoyez le chapitre sur les opérations mathématiques si cela ne vous dit rien) qui fait que l’opérateur `&&` passe *avant* l’opérateur `||`. Ainsi, le premier code est équivalent au second car l’opérateur `&&` est évalué *avant* l’opérateur `||`.

```c
printf("%d\n", a && b || c && d);
```


```c
printf("%d\n", (a && b) || (c && d));
```

Si vous souhaitez un autre résultat, il est nécessare d’ajouter des parenthèses pour modifier la priorité par défaut, par exemple comme ceci.

```c
printf("%d\n", a && (b || c) && d );
```