Comme les opérateurs que nous avons vu précédemment (`+`, `-`, `*`, etc), les opérateurs de comparaison et les opérateurs logiques donnent un résultat : « vrai » si la condition est vérifiée, et « faux » si la condition est fausse. Toutefois, comme vous le savez, notre ordinateur ne voit que des nombres. Aussi, il est nécessaire de représenter ces valeurs à l’aide de ceux-ci. 

Certains langages fournissent pour cela un type distinct pour stocker le résultat des opérations de comparaison et deux valeurs spécifiques : `true` (vrai) et `false` (faux). Néanmoins, dans les premières versions du langage C, ce type spécial n’existait pas[^bool]. Il a donc fallu ruser et trouver une solution pour représenter les valeurs « vrai » et « faux ». Pour cela, la méthode la plus simple a été privilégiée : utiliser directement des nombres pour représenter ces deux valeurs. Ainsi, le langage C impose que :
 
* la valeur « faux » soit représentée par zéro ;
* et que la valeur « vrai » soit représentée par tout sauf zéro.

Les opérateurs de comparaison et les opérateurs logiques suivent cette convention pour représenter leur résultat. Dès lors, une condition vaudra zéro si elle est fausse et un si elle est vraie.

[^bool]: Depuis la norme C99, le type `_Bool` a été introduit ainsi que l'en-tête `<stdbool.h>` qui fournit un synonyme pour ce nouveau type : `bool`, et deux constantes entières `true` (qui vaut 1) et `false` (qui vaut zéro).