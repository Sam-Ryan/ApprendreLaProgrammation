Maintenant que nous savons déclarer, utiliser et même afficher des variables, nous sommes fin prêts pour interagir avec l’utilisateur. En effet, jusqu’à maintenant, nous nous sommes contentés d’afficher des informations. Nous allons à présent voir comment en récupérer grâce à la fonction `scanf()`, dont l’utilisation est assez semblable à `printf()`.

```c
#include <stdio.h>


int main(void)
{
    int age;

    printf("Quelle âge avez-vous ? ");
    scanf("%d", &age);
    printf("Vous avez %d an(s)\n", age);
    return 0;
}
```

```text
Quelle age avez-vous ? 15
Vous avez 15 an(s).
```

Comme vous le voyez, l’appel à `scanf()` ressemble très fort à celui de `printf()` mise à part l’absence du caractère spécial `\n` (qui n’a pas d’intérêt puisque nous récupérons des informations) et le symbole `&`.

À son sujet, souvenez-vous de la brève explication sur la mémoire au début du chapitre précédent. Celle-ci fonctionne comme une armoire avec des tiroirs (les adresses mémoires) et des objets dans ces tiroirs (nos variables). La fonction `scanf()` a besoin de connaitre l’emplacement en mémoire de nos variables afin de les modifier. Afin d’effectuer cette opération, nous utilisons le symbole ```&``` (qui est en fait un opérateur que nous verrons en détail plus tard). Ce concept de transmission d’adresses mémoires est un petit peu difficile à comprendre au début, mais ne vous inquiétez pas, vous aurez l’occasion de bien revoir tout cela en profondeur dans le chapitre traîtant des pointeurs.

Ici, `scanf()` attend patiemment que l’utilisateur saisisse un nombre au clavier afin de modifier la valeur de la variable *age*. On dit que c’est une **fonction bloquante**, car elle suspend l’exécution du programme tant que l’utilisateur n’a rien entré.

Pour ce qui est des indicateurs de conversions, ils sont un peu différents de ceux de `printf()`.

Type | Indicateur(s) de conversion
------------------------ | ------------
**char** | c
**short** | hd ou hi
**int** | d ou i
**long** | ld ou li
**unsigned short** | hu, hx ou ho
**unsigned int** | u, x ou o
**unsigned long** | lu, lx ou lo
**float** | f
**double** | lf
**long double** | Lf

[[erreur]]
| Faites bien attention aux différences ! Si vous utilisez le mauvais format, le résultat ne sera pas celui que vous attendez. Les changements concernent les types `char`, `short` et `double`.

[[information]]
| Notez que l'indicateur `c` ne peut être employé que pour récupérer un caractère et non un nombre.

[[information]]
| Remarquez également qu’il n’y a plus qu’un seul indicateur pour récupérer un nombre hexadécimal : `x` (l’utilisation de lettres majuscules ou minuscules n’a pas d’importance). 

En passant, sachez qu’il est possible de lire plusieurs entrées en même temps, par exemple comme ceci.

```c
int x, y;

scanf("%d %d", &x, &y);
printf("x = %d | y = %d\n", x, y);
```

L’utilisateur a deux possibilités, soit insérer un (ou plusieurs) espace(s) entre les valeurs, soit insérer un (ou plusieurs) retour(s) à la ligne entre les valeurs.

```text
14
6
x = 14 | y = 6
```

```text
14 6
x = 14 | y = 6
```

La fonction `scanf()` est en apparence simple (oui, *en apparence*), mais son utilisation peut devenir très complexe lorsqu’il est nécessaire de vérifier les entrées de l’utilisateur (entre autres). Cependant, à votre niveau, vous ne pouvez pas encore effectuer de telles vérifications. Ce n’est toutefois pas très grave, nous verrons cela en temps voulu. ;)