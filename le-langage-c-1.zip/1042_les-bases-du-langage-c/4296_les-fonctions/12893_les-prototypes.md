Jusqu’à présent, nous avons toujours défini notre fonction *avant* la fonction `main()`. Cela paraît de prime abord logique (nous définissons la fonction avant de l’utiliser), cependant cela est surtout indispensable. En effet, si nous déplaçons la définition après la fonction `main()`, le compilateur se retrouve dans une situation délicate : il est face à un appel de fonction dont il ne sait rien (nombres d’arguments, type des arguments et type de retour). Que faire ? *Hé* bien, il serait possible de stopper la compilation, mais ce n’est pas ce qui a été retenu, le compilateur va considérer que la fonction retourne une valeur de type `int` et qu’elle reçoit un nombre indéterminé d’arguments.

Toutefois, si cette décision à l’avantage d’éviter un arrêt de la compilation, elle peut en revanche conduire  à des problèmes lors de l’exécution si cette supposition du compilateur s’avère inadéquate. Or, il serait pratique de pouvoir définir les fonctions dans l’ordre que nous souhaitons sans se soucier de qui doit être défini avant qui.

Pour résoudre ce problème, il est possible de **déclarer** une fonction à l’aide d’un **prototype**. Celui-ci permet de spécifier le type de retour de la fonction, son nombre d’arguments et leur type, mais ne comporte pas le corps de cette fonction. La syntaxe d’un prototype est la suivante.

```text
type nom(paramètres);
```

Ce qui donne par exemple ceci.

```c
#include <stdio.h>

void bonjour(void);


int main(void)
{
    bonjour();
    return 0;
}


void bonjour(void)
{
    printf("Bonjour !\n");
}
```

[[attention]]
| Notez bien le point-virgule à la fin du prototype qui est obligatoire.

[[information]]
| Étant donné qu’un prototype ne comprends pas le corps de la fonction qu’il déclare, il n’est pas obligatoire de préciser le nom des paramètres de celles-ci. Ainsi, le prototype suivant est parfaitement correct.
|
|```c
|int ppcd(int, int);
|```