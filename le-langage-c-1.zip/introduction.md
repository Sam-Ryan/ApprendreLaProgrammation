[[information]]
| Ce tutoriel a été initialement rédigé sur le feu site Progdupeupl par Mewtow, Mathuin, paraze, informaticienzero et Taurre, sous licence CC BY-NC-SA.

Vous souhaitez apprendre à programmer, mais vous ne savez pas comment vous y prendre ? Vous connaissez déjà le C, mais vous avez besoin de revoir un certain nombre de points ? Ou encore, vous êtes curieux de découvrir un nouveau langage de programmation ? Si oui, alors permettez-nous de vous souhaiter la bienvenue dans ce cours de programmation consacré au langage C.

Pour pouvoir suivre ce cours, *aucun prérequis n’est nécessaire* : tout sera détaillé de la manière la plus complète possible, accompagné d’exemples, d’exercices et de travaux pratiques.

# Remerciements

Avant de commencer, nous souhaitons remercier plusieurs personnes :

* [Mewtow](http://www.developpez.net/forums/u428309/mewtow/) pour sa participation à la rédaction et à l'évolution de ce cours ainsi que pour ses nombreux conseils ;
* [Arius](/membres/voir/Arius/) et [Saroupille](/membres/voir/Saroupille/) pour la validation de ce cours ;
* [Pouet_forever](/membres/voir/Pouet_forever/), [SofEvans](http://www.siteduzero.com/membres-294-214840.html), [paraze](/membres/voir/paraze/) et Mathuin pour leur soutien lors des débuts de la rédaction ;
* [Dominus Carnufex](/membres/voir/Dominus%20Carnufex/) pour son suivi minutieux et sa bienveillance face à nos (nombreuses) fautes de français ;
* [Karnaj](/membres/voir/Karnaj/) pour ses suggestions et corrections ;
* [Maëlan](/membres/voir/Ma%C3%ABlan/) pour sa relecture attentive du chapitre sur les encodages ;
* toute l’équipe de Progdupeupl et de Zeste de Savoir ;
* tous ceux qui, au fil du temps et de la rédaction, nous ont apporté leurs avis, leurs conseils, leurs points de vue et qui nous ont aidés à faire de ce cours ce qu’il est aujourd’hui ;
* et surtout vous, lecteurs, pour avoir choisi ce cours.