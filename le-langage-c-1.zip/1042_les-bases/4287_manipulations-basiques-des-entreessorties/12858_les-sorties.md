Intéressons-nous dans un premier temps aux sorties. Afin d’afficher du texte à l’écran, nous avons besoin d'une **fonction**.

Qu'est-ce qu'une fonction ? Une fonction est un morceau de code qui a un but, une *fonction* particulière et qui peut être **appelée** à l'aide d'une référence, le plus souvent le nom de cette fonction (comme pour une variable, finalement). En l'occurrence, nous allons utiliser une fonction qui a pour objectif d'afficher du texte à l'écran : la fonction *printf*().

# Première approche

Un exemple valant mieux qu'un long discours, voici un premier exemple :

```c
#include <stdio.h>


int main(void)
{
    printf("Bonjour tout le monde !\n");
    return 0;
}
```

```text
Bonjour tout le monde !
```

Deux remarques au sujet de ce code :

```c
#include <stdio.h>
```

Il s'agit d'une **directive du préprocesseur**, facilement reconnaissable car elles commencent toutes par le symbole ```#```. Celle-ci sert à inclure un fichier (**stdio.h**) qui contient les références de différentes fonctions d'entrée et sortie (**stdio** est une abbréviation pour « _**St**andar**d i**nput **o**utput_ », soit « Entrée-sortie standard »).

Ce fichier se terminant par l'extension **.h** est appelé un **fichier d'en-tête** (*header* en anglais) et fait partie avec d'autre d'un ensemble plus large appelée la **bibliothèque standard** (« standard » car elle est prévue par la norme).

```c
printf("Bonjour tout le monde !\n");
```

Ici, nous **appelons** la fonction *printf*() (un appel de fonction est toujours suivi d'un groupe de parenthèses) avec comme **argument** (ce qu'il y a entre les parenthèses de l'appel) un texte (il s'agit plus précisément d'une **chaîne de caractères**, qui est toujours comprise entre deux guillemets double). Le `\n` est un caractère spécial qui représente un retour à la ligne, cela est plus commode pour l'affichage.

Le reste devrait vous être familier.

# Les formats

Bien, nous savons maintenant afficher une phrase à l'écran, mais ce serait quand même mieux de pouvoir voir les valeurs de variables. Comment faire ? *Hé* bien, pour y parvenir, la fonction *printf*() met à notre disposition des **formats**. Ceux-ci sont en fait des sortes de repères au sein d'un texte qui indique à *printf*() que la valeur d'une variable est attendue à cet endroit. Voici un exemple pour une variable de type `int` :

```c
#include <stdio.h>


int main(void)
{
    int variable = 20;

    printf("%d\n", variable);
    return 0;
}
```

```text
20
```

Nous pouvons voir que le texte de l'exemple précédent a été remplacé par `%d`, seul le `\n` été maintenu. Un format commence toujours par le symbole `%` et est suivi par une ou plusieurs lettres qui indiquent le type de données que nous souhaitons voir affiché. Cette suite de lettre est appelée un **indicateur de conversion**. En voici une liste non exhaustive :

Type | Indicateur(s) de conversion
------------------------ | ------------
**char** | c, d (ou i)
**short** | d (ou i)
**int** | d (ou i)
**long** | ld (ou li)
**unsigned char** | u, x (ou X) ou o
**unsigned short** | u, x (ou X) ou o
**unsigned int** | u, x (ou X) ou o
**unsigned long** | lu, lx (ou lX) ou lo
**float** | f
**double** | f
**long double** | Lf

[[information]]
| Remarquez que pour le type `char` l'indicateur est soit **c**, soit **d** (ou **i**). Cela dépend si vous l'utiliser pour contenir un caractère ou un entier. Également, notez que les indicateurs de conversions sont identiques pour les type `char` (s'il stocke un entier), `short` et `int` (pareil pour leurs équivalents non signés) ainsi que pour les types `float` et `double`.

[[information]]
| Les indicateurs **x**, **X** et **o** permettent d'afficher un nombre en représentation hexadécimale ou octale (l'indicateur **x** affiche les lettres en minuscules alors que l'indicateur **X** les affiches en majuscules).

Allez, un petit exemple pour reprendre tout cela et retravailler le chapitre précédent par la même occasion :

```c
#include <stdio.h>


int main(void)
{
    char z = 'z';
    char a = 10;
    unsigned short b = 20;
    int c = 30;
    long d = 40;
    float e = 50.;
    double f = 60.0;
    long double g = 70.0;

    printf("%c\n", z);
    printf("%d\n", a);
    printf("%u\n", b);
    printf("%o\n", b);
    printf("%x\n", b);
    printf("%d\n", c);
    printf("%li\n", d);
    printf("%f\n", e);
    printf("%f\n", f);
    g = 80.0;
    printf("%Lf\n", g);
    return 0;
}
```

```text
z
10
20
24
14
30
40
50.000000
60.000000
80.000000
```

[[information]]
| Si vous souhaitez afficher le caractère `%` vous devez le doubler : `%%`.

# Précision des nombres flottants

Vous avez peut-être remarquer que lorsqu'un flottant est affiché, il y a un certain nombre de zéros qui suivent, et ce peu importe qu'ils soient utiles ou non. Afin d'en supprimer certains, vous pouvez spécifier une **précision**. Celle-ci correspond au nombre de chiffre suivant la virgule qui seront affichés. Elle prend la forme d’un point suivi par un nombre : la quantité de chiffres qu’il y aura derrière la virgule.

``` c
double x = 42.42734;

printf("%.2f", x);
```

```text
42.43
``` 

# Les caractères spéciaux

Dans certains cas, nous souhaitons obtenir un résultat à l'affichage (saut de ligne, une tabulation, un retour chariot, *etc*). Cependant, ils ne sont pas particulièrement pratique à insérer dans une chaîne de caractères. Aussi, le C nous permet de le faire en utilisant une **séquence d'échappement**. Il s'agit en fait d'une suite de caractères commençant par le symbole `\` et suivie d'une lettre. En voici une liste non exhaustive :

Séquence d'échappement | Signification
---------------------- | -------------
`\a` | Caractère d'appel
`\b` | Espacement arrière
`\f` | Saut de page
`\n` | Saut de ligne
`\r` | Retour chariot
`\t` | Tabulation horizontale
`\v` | Tabulation verticale
`\"` | Le symbole « `"` »
`\\` | Le symbole « `\` » lui-même

En général, vous n'utiliserez que le saut de ligne, la tabulation horizontale et de temps à autre le retour chariot, les autres n'ont quasiment plus d'intérêt. Un petit exemple pour illustrer leurs effets :

```c
#include <stdio.h>


int main(void)
{
    printf("Quelques sauts de ligne\n\n\n");
    printf("\tIl y a une tabulation avant moi !\n");
    printf("Je voulais dire que...\r");
    printf("Hey ! Vous pourriez me laisser parler !\n");
    return 0;
}
```

```text
Quelques sauts de ligne


        Il y a une tabulation avant moi !
Hey ! Vous pourriez me laisser parler !
```

[[information]]
| Le retour chariot provoque un retour au début de la ligne courante. Ainsi, il est possible d'écrire par dessus un texte affiché.

# Sur plusieurs lignes

Notez qu'il est possible d'écrire un long texte sans appeler plusieurs fois *printf*(). Pour ce faire, il suffit de le diviser en plusieurs chaîne de caractères :

```c
#include <stdio.h>

int main(void)
{
    printf("Texte ecrit sur plusieurs "
           "lignes dans le code source "
           "mais sur une seule dans la console.\n");
    return 0;
}
```

```text
Texte écrit sur plusieurs lignes dans le code source mais sur une seule dans la console.
```