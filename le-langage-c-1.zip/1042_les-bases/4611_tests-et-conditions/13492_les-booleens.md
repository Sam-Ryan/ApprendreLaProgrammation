Commes les opérateurs que nous avons vu précédemment (`+`, `-`, `*`, etc), les opérateurs de comparaisons et les opérateurs logiques donnent un résultat : « vrai » si la condition est vérifiée, et « faux » si la condition est fausse. Toutefois, comme vous le savez, notre ordinateur ne voit que des nombres. Aussi, il est nécessaire de représenter ces valeurs à l'aide de nombres. 

Certains langages fournissent pour cela un type distinct pour stocker le résultat des opérations de comparaisons et deux valeurs spécifiques : `true` (vrai) et `false` (faux). Néanmoins, dans les premières versions du langage C, ce type spécial n'existe pas. Il a donc fallu ruser et trouver une solution pour représenter les valeurs « vrai » et « faux ». Pour cela, la méthode la plus simple a été privilégiée : utiliser directement des nombres pour représenter ces deux valeurs. Ainsi, le langage C impose que :
 
* la valeur « faux » soit représentée par zéro ;
* et que la valeur « vrai » soit représentée par tout sauf zéro.

Les opérateurs de comparaison et les opérateurs logiques suivent cette convention pour représenter leur résultat. Dès lors, une condition vaudra 0 si elle est fausse et 1 si elle est vraie.