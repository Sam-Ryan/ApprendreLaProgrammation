Jusqu'à présent, vous avez appris à écrire du texte, manipuler des nombres et interagir un tout petit peu avec l'utilisateur.

En gros, pour le moment, un programme est quelque chose de sacrément simple et linéaire : il ne permet que d'exécuter des instructions dans un ordre donné. Techniquement, une simple calculatrice peut en faire autant (voire plus). Cependant et heureusement, les langages de programmation actuels fournissent des moyens permettant de réaliser des tâches plus évoluées.

Pour ce faire, diverses **structures de contrôle** ont été inventées. Celles-ci permettent de modifier le comportement d'un programme suivant la réalisation de différentes conditions. Ainsi, si une condition est vraie, alors le programme se comportera d'une telle façon, si elle est fausse, le programme fera telle ou telle chose, etc.

Dans ce chapitre, nous allons voir comment rédiger des conditions à l'aide de deux catégories d'opérateurs : 

- les **opérateurs de comparaison**, qui comparent deux nombres ;
- les **opérateurs logiques**, qui permettent de combiner plusieurs conditions.