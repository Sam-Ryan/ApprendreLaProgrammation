Le langage C fournit différents opérateurs qui permettent d'effectuer des comparaisons entre des nombres. Ces opérateurs peuvent s'appliquer aussi bien à des nombres écrits en dur dans le code qu'à des variables (ou un mélange des deux). Ces derniers permettent donc par exemple de vérifier si une variable est supérieure à une autre, si elles sont égales, etc.

# Comparaisons

L'écriture de conditions est similaire aux écritures mathématiques que vous voyez en cours : l'opérateur est entre les deux expressions à comparer. Par exemple, dans le cas de l'opérateur `>` (« strictement supérieur à »), il est possible d'écrire des expressions du type : ```a > b``` , qui vérifie si la variable *a* est strictement supérieure à la variable *b*.

Le tableau ci-dessous reprends les différents opérateurs de comparaisons.

Opérateur  | Signification
------------- | -------------
==| Égalité
!=| Inégalité
<| Strictement inférieur à
<=| Inférieur ou égal à
>| Strictement supérieur à
>=| Supérieur ou égal à

Ces opérateurs ne semblent pas très folichons : avec, nous ne pouvons faire que quelques tests basiques sur des nombres. Cependant, rappelez-vous : pour un ordinateur, tout n'est que nombre et comme pour le stockage des données (revoyez le début du chapitre 4 si cela ne vous dit rien) il est possible de ruser et d'exprimer toutes les conditions possibles avec ces opérateurs (cela vous paraîtra plus clair quand nous passerons aux exercices).

# Résultat d'une comparaison

Comme dit dans l'extrait plus haut, une opération de comparaison va donner 0 si elle est fausse et 1 si elle est vraie. Pour illustrer ceci : vérifions quels sont les résultats donnés par différentes comparaisons.

```c
int main(void)
{
    printf("10 == 20 vaut %d\n", 10 == 20);
    printf("10 != 20 vaut %d\n", 10 != 20);
    printf("10 < 20 vaut %d\n", 10 < 20);
    printf("10 > 20 vaut %d\n", 10 > 20);

    return 0;
}
```

```text
10 == 20 vaut 0
10 != 20 vaut 1
10 < 20 vaut 1
10 > 20 vaut 0
```

Le résultat confirme bien ce que nous avons dit ci-dessus : une condition vaut 0 si elle est fausse et 1 si elle est vraie.