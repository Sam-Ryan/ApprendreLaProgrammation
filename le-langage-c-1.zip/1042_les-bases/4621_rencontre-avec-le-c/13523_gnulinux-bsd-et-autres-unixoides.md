# Le compilateur

Suivant le système que vous choisissez, vous aurez ou non le choix entre différents compilateurs. Si vous n'avez pas d'idée, nous vous conseillons d'opter pour GCC en installant le paquet éponyme à l'aide de votre gestionnaire de paquet. Également, vous pouvez installer le paquet gdb qui est un débogueur.

# Configuration

Ceci dépend de votre interprétateur de commande. Pour savoir quel est celui dont vous disposez, ouvrez un terminal et entrez la commande suivante :

```sh
echo $SHELL
```

## bash

Exécutez la commande suivante depuis votre dossier personnel (/home/utilisateur) :

```sh
echo "alias zcc='gcc -Wall -Wextra -pedantic -std=c89 -fno-common -fno-builtin'" >> .bashrc
```

## csh ou tcsh

Exécutez la commande suivante depuis votre dossier personnel (/home/utilisateur) :

```sh
echo "alias zcc 'gcc -Wall -Wextra -pedantic -std=c89 -fno-common -fno-builtin'" >> .cshrc # (ou .tcshrc)
```

## ksh, zsh ou sh

Exécutez les commandes suivante depuis votre dossier personnel (/home/utilisateur) :

```sh
echo "alias zcc='gcc -Wall -Wextra -pedantic -std=c89 -fno-common -fno-builtin'" >> .kshrc # (ou .zshrc ou .shrc)
echo "export ENV=$HOME/.kshrc" >> .profile # (ou .zshrc ou .shrc)
```

# L'éditeur de texte

Ce serait un euphémisme de dire que vous avez l'embarras du choix. Il existe une pléthore d'éditeurs de texte fonctionnant en ligne de commande ou avec une interface graphique, voire les deux.

Pour n'en citer que quelques-uns, en ligne de commande vous trouverez par exemple : vim et emacs (les deux monstres de l'édition), nano ou joe. Côté graphique, vous avez entre autres : gedit, mousepad et kate.

# Introduction à la ligne de commande

La ligne de commande, derrière son aspect rustre et archaïque, n'est en fait qu'une autre manière de réaliser des tâches sur un ordinateur. La différence majeure avec une interface graphique étant que les instructions sont données non pas à l'aide de boutons et de cliques de souris, mais exclusivement à l'aide de texte. Ainsi, pour réaliser une tâche donnée, il sera nécessaire d'invoquer un programme (on parle souvent de **commandes**) en tapant son nom.

La première chose que vous devez garder à l'esprit, c'est le dossier dans lequel vous vous situez. Suivant le terminal que vous employez, celui-ci est parfois indiqué en début de ligne et terminé par le symbole `$` ou `%`. Ce dossier est celui dans lequel les actions (par exemple la création d'un répertoire) que vous demanderez seront exécutées. Normalement, par défaut, vous devriez vous situez dans le répertoire : « /home/utilisateur » (où « *utilisateur* » correspond à votre nom d'utilisateur).  Ceci étant posé, voyons quelques commandes basiques.

La commande **pwd** (pour *print working directory*) vous permet de connaître le répertoire dans lequel vous êtes.

```text
$ pwd
/home/utilisateur
```

La commande **mkdir** (pour *make directory*) vous permet de créer un nouveau dossier. Pour ce faire, tapez **mkdir** suivi d'un espace et du nom du nouveau répertoire. Par exemple, vous pouvez créer un dossier « programmation » comme suit :

```text
$ mkdir programmation
```

La commande **ls** (pour *list*) vous permet de lister le contenu d'un dossier. Vous pouvez ainsi vérifier qu'un nouveau répertoire a bien été crée :

```text
$ ls
programmation
```

[[information]]
| Le résultat ne sera pas forcément le même que ci-dessus, cela dépend du contenu de votre dossier. L'essentiel est que vous retrouviez bien le dossier que vous venez de créer.

Enfin, la commande **cd** (pour *change directory*) vous permet de vous déplacer d'un dossier à l'autre. Pour ce faire spécifier simplement le nom du dossier de destination.

```text
$ cd programmation
$ pwd
/home/utilisateur/programmation
```

[[information]]
| Le dossier spécial « **..** » représente le répertoire parent. Il vous permet donc de revenir en arrière dans la hiérarchie des dossiers.

Voilà, avec ceci, vous êtes fin prêt pour compiler votre premier programme. Vous pouvez vous rendre à la deuxième partie de ce chapitre.

*[GCC]: GNU Compiler Collection