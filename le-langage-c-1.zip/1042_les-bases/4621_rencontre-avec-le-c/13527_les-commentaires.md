Il est souvent nécessaire de **commenter son code source** pour décrire des passages un peu moins lisibles ou tout simplement pour offrir quelques compléments d’information au lecteur du code. Nous en utiliserons souvent dans la suite de ce cours pour rendre certains exemples plus parlant.

Un commentaire est ignoré par le compilateur : il disparait et n’est pas présent dans l’exécutable. Il ne sert qu’au programmeur et aux lecteurs du code.

Un commentaire en C est écrit entre les signes ```/*``` et ```*/``` :

```c
/* Ceci est un commentaire */
```

Il peut très bien prendre plusieurs lignes :

```c
/* Ceci est un commentaire qui
   prend plusieurs lignes. */
```