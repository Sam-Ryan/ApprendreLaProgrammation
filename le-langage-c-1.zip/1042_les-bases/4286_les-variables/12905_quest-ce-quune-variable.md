Pour comprendre ce qu’est une variable, et comment manipuler celles-ci, il faut commencer par comprendre comment notre ordinateur fait pour stocker des données. En théorie, un ordinateur est capable de stocker tout type d’information. Mais comment est-il possible de réaliser un tel miracle alors qu'il ne s'agit finalement que d'un amas de circuits électriques ? 

# Codage des informations

Peut-être avez-vous déjà entendu le proverbe suivant : « *si le seul outil que vous avez est un marteau, vous verrez tout problème comme un clou* » (Abraham Maslow). *Hé* bien, l'idée est un peu la même pour un ordinateur : ce dernier ne sachant utiliser que des nombres, il voit toute information comme une suite de nombres. 

L'astuce consiste à transformer une information en nombre pour que l'ordinateur puisse la traiter. Différentes techniques sont possibles pour atteindre cet objectif, une des plus simples étant une table de correspondance, par exemple entre un nombre et un caractère.

Caractère | Nombre
--------- | ----------
A | 1
B | 2
C | 3

## Binaire

Cependant, comme si cela ne suffisait pas, un ordinateur ne compte pas comme nous : il compte en base deux (l'andouille !).

[[question]]
| En base deux ?

La base correspond aux nombres de chiffres disponibles pour représenter un nombre. En base 10, nous disposons de dix chiffres : zéro, un, deux, trois, quatre, cinq, six, sept, huit et neuf. En base deux, nous en avons donc... deux : zéro et un. Pour ce qui est de compter, c'est du pareil au même : nous commençons par épuiser les unités : 0, 1 ; puis nous passons aux dizaines : 10, 11, puis aux centaines : 100, 101, 110, 111; et ainsi de suite. Ci-dessous un petit tableau de correspondance entre la base deux et la base dix.

Base deux | Base dix
--------- | --------
0 | 0
1 | 1
10 | 2
11 | 3
100 | 4
101 | 5
110 | 6
111 | 7
1000 | 8
1001 | 9
1010 | 10

Un chiffre binaire (un zéro ou un un) est appelé un _bit_ en anglais. Il s'agit de la contraction de l'expression « *binary digit* ». Nous l'employerons assez souvent dans la suite de ce cours par soucis d'économie.

[[question]]
| Mais pourquoi utiliser la base deux et non la base dix ?

Parce que les données circules sous forme de courants électriques. Or, la tension de ceux-ci n'étant pas toujours stable, il est difficile de réaliser un système fiable sachant détecter dix valeurs différentes. Par contre, c'est parfaitement possible avec deux valeurs : il y a du courant ou il n'y en a pas.

# La mémoire

Nous savons à présent que notre ordinateur ne sait employer que des nombres représentés en base deux. 

[[question]]
| Mais comment stocker tout ce fatras de nombres ?

*Hé* bien, les *bits* sont stockés dans un composant électronique particulier de l'ordinateur : la **mémoire**. Enfin, nous disons « _**la** mémoire_ », mais il y en a en fait plusieurs.

[[question]]
| Mais pourquoi plusieurs mémoires et pas une seule ? 

Le fait est qu'il est actuellement impossible de créer des mémoires qui soient à la fois rapides et capables de contenir beaucoup de données. Nous ne pouvons donc utiliser une seule grosse mémoire capable de stocker toutes les données dont nous avons besoin. Ce problème s’est posé dès les débuts de l’informatique, comme en témoigne cette citation des années 1940, provenant des concepteurs d'un des tout premiers ordinateurs :

Mais les chercheurs et ingénieur du début de l'informatique ont trouvé une solution : segmenter la mémoire de l’ordinateur en plusieurs sous-mémoires, de taille et de vitesse différentes, utilisées chacune suivant les besoins. Nous aurons donc des mémoires pouvant contenir peu de données et rapides, à coté de mémoires plus importantes et plus lentes.

Nous vous avons dit que l’ordinateur utilisait plusieurs mémoires. Trois d'entre-elles méritent à notre sens votre attention :

* les registres  ;
* la mémoire vive (ou RAM en anglais) ;
* le disque dur.

Les **registres** sont des mémoires intégrées dans le processeur, utilisées pour stocker des données temporaires. Elles sont très rapides, mais ne peuvent contenir que des données très simples, comme des nombres.

La **mémoire vive** est une mémoire un peu plus grosse, mais plus lente que les registres. Elle peut contenir pas mal de données et est généralement utilisée pour stocker les programmes en court d'exécution ainsi que les données qu’ils manipulent. 

Ces deux mémoires (les registres et la mémoire vive) ont tout de même un léger défaut : elles perdent leur contenu quand elles ne sont plus alimentées... Autant dire que ce n'est pas le meilleur endroit pour stocker un système d’exploitation ou des fichiers personnels. Ceci est le rôle du **disque dur**, une mémoire avec une capacité très importante, mais très lente qui a toutefois l'avantage d'assurer la persistance des données.

En C, la mémoire la plus manipulée par le programmeur est la mémoire vive. Aussi, nous allons nous y intéresser d'un peu plus près dans ce qui suit.

## *Bits*, multplets et octets

Dans la mémoire vive, les *bits* sont regroupés en « paquets » de quantité fixe : des « **cases mémoires** », aussi appelées **multiplets** (ou *bytes* en anglais). A quelques exceptions près, les mémoires utilisent des multiplets de huit *bits*, aussi appelés **octet**. Un octet peut stocker 256 informations différentes (vous pouvez faire le calcul vous même : combien vaut 11111111 en base deux ? :p ). Pour stocker plus d’informations, il sera nécessaire d'utiliser plusieurs octets.

## Adresse mémoire

Néanmoins, il est bien beau de stocker des données en mémoire, encore faut-il pouvoir remettre la main dessus.

Dans cette optique, chaque octet de la mémoire vive se voit attribuer un nombre unique, **une adresse**, qui va permettre de le sélectionner et de l’identifier parmi tous les autres. Imaginez la mémoire vive de l’ordinateur comme une immense armoire, qui contiendrait beaucoup de tiroirs (les cases mémoires) pouvant chacun contenir un octet. Chaque tiroir se voit attribuer un numéro pour le reconnaitre parmi tous les autres. Nous pourrons ainsi demander : quel est le contenu du tiroir numéro 27 ? Pour la mémoire, c’est pareil. Chaque case mémoire a un numéro : son adresse.

Adresse  |  Contenu mémoire
------------|-------------
0  | 11101010
1 | 01111111
2 | 00000000
3 | 01010101
4 | 10101010
5 | 00000000

En fait, vous pouvez comparer une adresse à un numéro de téléphone (ou à une adresse d’appartement) : chacun de vos correspondants a un numéro de téléphone et vous savez que pour appeler telle personne, vous devez composer tel numéro. Les adresses mémoires fonctionnent exactement de la même façon !

![Exemple : on demande à notre mémoire de sélectionner la case mémoire d’adresse 1002 et on récupère son contenu (ici, 17).](http://zestedesavoir.com/media/galleries/1501/71880ecc-f5c1-420e-9d9b-310e34bf0b66.png.960x960_q85.jpg)

[[information]]
| Plus généralement, toutes les mémoires disposent d'un mécanisme similaire pour retrouver les données. Aussi, vous entendrez souvent le terme de **référence** qui désigne un moyen (comme une adresse) permettant de localiser une donnée. Il s'agit simplement d'une notion plus générale.

# Les variables

Tout cela est bien sympathique, mais manipuler explicitement des références (des adresses si vous préférez) est un vrai calvaire, de même que de s'évertuer à calculer en base deux. Heureusement pour nous, les langages de programmation (et notamment le C), se chargent d'effectuer les conversions pour nous et remplacent les références par des variables.

Une variable correspondra à une portion de mémoire, appelée **objet**, à laquelle nous donnerons un nom. Ce nom permettra d’identifier notre variable, tout comme une référence permet d’identifier une portion de mémoire parmi toutes les autres. Nous allons ainsi pouvoir nommer les données que nous manipulons, chacun de ces noms étant remplacés lors de la compilation par une référence (le plus souvent une adresse).