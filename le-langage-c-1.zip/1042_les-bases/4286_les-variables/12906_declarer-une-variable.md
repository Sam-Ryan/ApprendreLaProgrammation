Entrons maintenant dans le vif du sujet en apprenant à déclarer nos variables. Tout d'abord, sachez qu'une variable est constituée de deux éléments obligatoires :

* un **type** ;
* un **identificateur** qui est en gros le « nom » de la variable.   

Le type d’une variable permet d’indiquer ce qui y sera stocké, par exemple : un caractère, un nombre entier un, nombre à virgule (ou nombre **flottant**), *etc*. Pour préciser le type d’une variable, il est nécessaire d'utiliser un mot-clé spécifique (il y en a donc un pour chaque type).

Une fois que nous avons décidé du nom et du type de notre variable, nous pouvons la créer (on dit aussi la déclarer) comme ceci : 

```text
type identificateur;
```

En clair, il suffit de placer un mot-clé indiquant le type de la variable, et de placer le nom qu'on lui a choisi immédiatement après. Faites bien attention au point-virgule à la fin !

# Les types

Comme dit précédemment, un type permet d’indiquer au compilateur quel genre de données nous souhaitons stocker. Ce type va permettre de préciser :

* toutes les valeurs que peut prendre la variable ;
* les opérations qu'il est possible d'effectuer avec (il n'est par exemple pas possible de réaliser une division entière avec un nombre flottant, nous y reviendrons).

Définir le type d’une variable permet donc de préciser son contenu potentiel et ce que nous pouvons faire avec. Le langage C fournit 8 types de base : 

Type  | Sert à stocker
-------------|------------
**char**| un caractère ou un entier
**short int**| un entier
**int**| un entier
**long int**| un entier
**float**| un flottant
**double**| un flottant
**long double**| un flottant

Les types ```short int```, ```int``` et ```long int``` servent tous à stocker des nombres entiers qui peuvent prendre des valeurs positives, négatives, ou nulles. On dit qu’il s’agit de types signés (car il peut comporter un signe). Pour ces trois types, il existe un type équivalent dit **non signé**. Un type entier non signé est un type entier qui n’accepte que des valeurs positives ou nulles : il ne peut pas stocker de valeurs négatives. Pour déclarer des variables d’un type non signé, il vous suffit de faire précéder le nom du type entier du mot-clé ```unsigned```.

Le type ```char``` peut lui aussi servir à stocker des nombres. Il sert surtout au stockage de caractères, mais ces derniers étant stockés dans l'ordinateur sous forme de nombres, il est possible de stocker des nombres dans un ```char```. Le seul problème, c’est que ce type peut être signé ou non signé de base suivant les compilateurs. Pour éviter les ennuis, spécifiez ce que vous souhaitez lors de la déclaration : non signé (```unsigned char```) ou signé (```signed char```).

[[information]]
| En cas de manque d'information concernant le type lors d'une déclaration, c'est le type `int` qui sera utilisé. Ainsi, `long` et `short` sont respectivement des raccourcis pour `long int` et `short int`. De même, le mot-clé `unsigned` seul signifie `unsigned int`.

## Capacité d’un type

Tous les types stockant des nombres ont des bornes, c’est-à-dire une limite aux nombres qu’ils peuvent stocker. En effet, le nombre de multiplets occupés par une variable est limité suivant son type. En conséquence, il n'est pas possible de mettre tous les nombres possibles dans une variable de type ```int```, ```float```, ou ```double```. Il y aura *toujours* une valeur minimale et une valeur maximale : certains nombres seront trop grands ou trop petits pour rentrer dans une variable d’un certain type. Ces bornes (que vous pouvez trouver au paragraphe 2.2.4.2 de la norme) sont les suivantes :

Type  | Minimum  | Maximum 
-------------|-------------|-----------
**signed char**| -127 | 127
**unsigned char**| 0 | 255
**short**| -32 767 | 32 767
**unsigned short**| 0 | 65 535
**int**| -32 767 | 32 767
**unsigned int**| 0 | 65 535
**long**| -2 147 483 647 | 2 147 483 647
**unsigned long**| 0 | 4 294 967 295
**float**| $-1 × 10^{37}$ | $+1 × 10^{37}$
**double**| $-1 × 10^{37}$ | $+1 × 10^{37}$
**long double**| $-1 × 10^{37}$ | $+1 × 10^{37}$

Si vous regardez bien ce tableau, vous remarquez que certains types ont des bornes identiques. En vérité, les valeurs présentées ci-dessus sont les *minima* garantis par la norme et il est fort probable qu’en réalité, vous puissiez stocker des valeurs plus élevées que celles-ci. Cependant, dans une optique de portabilité, vous devez considérer ces valeurs comme les *minima* et les *maxima* de ces types, peu importe la capacité réelle de ces derniers sur votre machine.

## Taille d’un type

Peut-être vous êtes vous demandés pourquoi existe t-il autant de types différents. La réponse est toute simple : la taille des mémoires était très limitée à l’époque où le langage C a été créé. En effet, le [PDP-11](http://cm.bell-labs.com/cm/cs/who/dmr/kd14.jpg) sur lequel le C a été conçu ne possédait que 24 Ko de mémoire (pour comparaison une calculatrice TI-Nspire possède 100 Mo de mémoire, soit environ 4000 fois plus). Il fallait donc l’économiser au maximum en choisissant le type le plus petit possible. Cette taille dépend des machines, mais de manière générale vous pouvez retenir les deux suites d’inégalités suivantes : ```char``` ≤ ```short``` ≤ ```int``` ≤ ```long``` et ```float``` ≤ ```double``` ≤ ```long double```.

Aujourd’hui ce n’est plus un problème, il n’est pas nécessaire de se casser la tête sur quel type choisir (excepté si vous voulez programmer pour de petits appareils où la mémoire est plus petite). En pratique, nous utiliserons surtout ```char``` pour les caractères, ```int``` ou ```long``` pour les entiers et ```double``` pour les flottants.

# Les identificateurs

Maintenant que l’on a vu les types, parlons des identificateurs. Comme dit précédemment, un identificateur est un nom donné à une variable pour la différencier de toutes les autres. Et ce nom, c’est au programmeur de le choisir. Cependant, il y a quelques limitations à ce choix. 

* seuls les 26 lettres de l’alphabet latin (majuscules ou minuscules), le caractère *underscore* (« _ ») et les chiffres sont acceptés. Pas d’accents, pas de ponctuation ni d’espaces ;
* un identificateur ne peut pas commencer par un chiffre ;
* les mots-clés ne peuvent pas servir à identifier une variable ; il s'agit de : 

```c
auto       double     int        struct
break      else       long       switch
case       enum       register   typedef
char       extern     return     union
const      float      short      unsigned
continue   for        signed     void
default    goto       sizeof     volatile
do         if         static     while
```
* deux variables ne peuvent avoir le même identificateur (le même nom). Il y a parfois quelques exceptions, mais cela n’est pas pour tout de suite ;    
* les identificateurs peuvent être aussi longs que l’on désire, toutefois le compilateur ne tiendra compte que des 31 premiers caractères.

Voici quelques exemples pour bien comprendre : 

Identificateur correct  | Identificateur incorrect  | Raison
------------- | ------------- | -------------
variable  | Nom de variable  | Espaces interdits
nombre_de_vie  | 1nombre_de_vie  | Commence par un chiffre
test  | test!  | Caractère « ! » interdit
un_dernier_pour_la_route1  | ```continue```  | Mot-clé réservé par le langage

À noter que le C fait la différence entre les majuscules et les minuscules (on dit qu’**il respecte la casse**). Ainsi les trois identificateurs suivants sont différents.

```c
variable
Variable
VaRiAbLe
```

# Déclaration et initialisation

Maintenant que nous savons toutes les bases, entrainons-nous à déclarer quelques variables :

```c
int main(void)
{
    double taille;
    unsigned int age;
    char caractere;
    short petite_valeur;

    return 0;
}
```

Il est possible de déclarer plusieurs variables **de même type** sur une même ligne, en séparant leurs noms par une virgule : 

```c
int age, taille, nombre;
```

Ceci permet de regrouper les déclarations suivant les rapports que les variables ont entres-elles.

```c
int annee, mois, jour;
int age, taille;
int x, y, z;
```

## Initialisation

En plus de déclarer une variable, il est possible de **l'initialiser**, c'est à dire de lui attribuer une valeur. La syntaxe est la suivante :

```console
type identificateur = valeur;
```

Ou comme ceci s'il s'agit d'un caractère :

```console
char identificateur = 'lettre';
```

Quelques exemples d'initialisations de variables :

```c
unsigned int age = 25;
short petite_valeur = 1;
const long abc = 3141596;
char caractere = 'h';
```

[[information]]
| Notez qu'une déclaration comporte le mot-clé `const`. Celui-ci permet de préciser qu'une variable ne pourra pas être modifiée par la suite. Il peut être utile pour stocker une valeur qui ne changera jamais (comme la constante $\pi$ qui vaut toujours 3,14159265).

[[attention]]
| Les déclarations doivent toujours se situées en début de bloc, c'est-à-dire juste après une accolade ouvrante.

## Initialisation des nombres flottants

Petit précision concernant la manière d’initialiser une variable de type flottant : celles-ci étant faites pour contenir des nombres à virgule, à l’initialisation, il est nécessaire de placer cette « virgule ». Toutefois, cette dernière est représentée par un point.

```c
const double pi = 3.14;
```

Cela vient du fait que le C est une invention américaine, et que les anglophones utilisent le point à la place de la virgule.

Notez qu'il est important de bien placé ce point, *même si vous voulez stocker un nombre entier*. Par exemple, vous ne devez pas écrire ```double a = 5``` mais ```double a = 5.``` (certains préfère ```double a = 5.0```, cela revient au même). Si vous ne le faites pas, vous risquez d’avoir quelques problèmes.

# Affectation

Nous savons donc déclarer (créer) nos variables, et les initialiser (leur donner une valeur à la création). Il ne nous reste plus qu’à voir la dernière manipulation possible : **l’affectation**. Celle-ci permet de modifier la valeur contenue dans une variable, pour la remplacer par une autre valeur.

Il va de soi que cette affectation n’est possible que pour les variables qui ne sont pas déclarées avec le mot-clé ```const``` puisque, par définition, de telles variables sont constantes et ne peuvent voir leur contenu modifié.

Pour faire une affectation, il suffit d’opérer ainsi :

```console
identificateur = nouvelle_valeur;
```

Nous voyons que la syntaxe est similaire à celle d’une déclaration avec initialisation : la seule différence, c’est qu’on n’a pas à préciser le type. Celui-ci est en effet fixé une fois pour toutes lors de la déclaration de notre variable : pas besoin de le préciser lors d’une affectation. Si nous souhaitons changer la valeur de nous variables, nous procédons simplement comme suit :

```c
age = 30;
taille = 177.5;
petite_valeur = 2;
```

Il n’y a aucune limite, voyez par exemple :

```c
petite_valeur = 2;
petite_valeur = 4;
petite_valeur = 8;
petite_valeur = 16;
petite_valeur = 8;
petite_valeur = 4;
petite_valeur = 2;
```

À chaque affectation, la variable va prendre une nouvelle valeur. Par contre, ne mettez pas le type quand vous voulez changer la valeur, sinon vous aurez le droit à une belle erreur du type « *redefinition of 'nom_de_votre_variable'* » car vous aurez créé deux variables avec le même identificateur !

Le code suivant est donc incorrect : 

```c
int age = 15;
int age = 20;
```

Si vous exécutez tous ces codes, vous verrez qu’ils n’affichent toujours rien. Mais pourquoi ? Tout simplement parce qu’on n'a pas demandé à notre ordinateur d'afficher quoique ce soit. Et ce n'est pas pour tout de suite : nous apprendrons comment faire au chapitre suivant. Quoiqu'il en soit, ne soyez pas pressés et prenez bien le temps d’assimiler toutes les notions présentées dans ce chapitre.

[[erreur]]
| Il n'y a pas de valeur par défaut en C. Aussi, sans initialisation ou affectation, la valeur d'une variable est indéterminée ! Veillez donc à ce que vos variables aient une valeur connue avant de les utiliser !