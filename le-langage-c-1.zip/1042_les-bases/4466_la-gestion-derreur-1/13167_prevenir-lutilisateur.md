Savoir qu'une erreur s'est produite, c'est bien, le signaler à l'utilisateur, c'est mieux. Ne laisser pas votre utilisateur dans le vide, s'il se passe quelque chose, dites le lui.

```c
#include <stdio.h>

int main(void)
{
    int x;
    int y;

    printf("Entrez deux nombres : ");

    if (scanf("%d %d", &x, &y) == 2)
        printf("Vous avez entré : %d et %d\n", x, y);
    else
        printf("Vous devez saisir deux nombres !\n");

    return 0;
}
```

```text
Entrez deux nombres : a b
Vous devez saisir deux nombres !

Entrez deux nombres : 1 2
Vous avez entre : 1 et 2
```

Simple, mais tellement plus agréable. ;)