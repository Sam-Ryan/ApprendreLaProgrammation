Pour définir une fonction, nous allons devoir donner quatre informations sur celle-ci :

* son **nom** : les règles sont les mêmes que pour les variables ;
* son **corps** (son contenu) : le bloc d'instructions à exécuter ;
* son **type de retour** : le type du résultat de la fonction ;
* d'éventuels **paramètres** : des valeurs reçues par la fonction lors de l'appel.

La syntaxe est la suivante :

```texte
type nom(paramètres)
{
     /* corps de la fonction */
}
```

Prenons un exemple : créons une fonction qui affiche « bonjour ! » à l'écran.

```c
#include <stdio.h>


void bonjour(void)
{
    printf("Bonjour !\n");
}


int main(void)
{
    bonjour();
    return 0;
}
```

Comme vous le voyez, la fonction se nomme *bonjour* et est composée d'un appel à *printf*(). Reste les deux mots-clés `void` :

* dans le cas du type de retour, il spécifie que la fonction ne retourne rien ;
* dans le cas des paramètres, il spécifie que la fonction n'en reçoit aucun (cela se manifeste lors de l'appel : il n'y a rien entre les parenthèses).

# Le type de retour

Le type de retour permet d'indiquer deux choses : si la fonction retourne une valeur et le type de cette valeur.

```c
#include <stdio.h>


int deux(void)
{
    return 2;
}


int main(void)
{
    printf("Retour : %d\n", deux());
    return 0;
}
```

```text
Retour : 2
```

Dans l'exemple ci-dessus, la fonction *deux*() est définie comme retournant une valeur de type `int`. Vous retrouvez l'instruction `return`, une instruction de saut (comme `break`, `continue` et `goto`). Ce `return` arrête de l'exécution de la fonction courante et provoque un retour (techniquement, un saut) vers l'appel à cette fonction qui se voit alors attribuer la valeur de retour (s'il y en a une). Autrement dit, dans notre exemple : l'instruction `return 2` stoppe l'exécution de la fonction *deux()* et ramène l'exécution du programme à l'appel qui vaut désormais 2, ce qui donne finalement : `printf("Retour : %d\n", 2)`

# Les paramètres

Un paramètre sert à fournir des informations à la fonction lors de son exécution. La fonction *printf()* par exemple récupère ce qu'elle doit afficher dans la console à l'aide de paramètres. Ceux-ci sont définis de la même manière que les variables si ce n'est que les définitions sont séparées par des virgules.

```texte
type nom(type paramètres1, type paramètres2, ...)
{
    /* corps de la fonction */
}
```

[[information]]
| Vous pouvez utiliser un maximum de trente et un paramètres, toutefois nous vous conseillons de vous limiter à *cinq* afin de conserver un code concis et lisible.

Maintenant que nous savons tout cela, nous pouvons réaliser une fonction qui calcul le plus petit commun diviseur entre deux nombres et ainsi simplifier l'exemple du dessus :

```c
#include <stdio.h>


int ppcd(int a, int b)
{
    int min = (a < b) ? a : b;
    int i;

    for (i = 2; i <= min; ++i)
        if (a % i == 0 && b % i == 0)
            return i;

    return 0;
}


int main(void)
{
    int a;
    int b;
    int resultat;

    printf("Entrez deux nombres : ");
    scanf("%d %d", &a, &b);
    resultat = ppcd(a, b);

    if (resultat != 0)
        printf("Le plus petit diviseur de %d et %d est %d\n", a, b, resultat);

    printf("Entrez deux autres nombres : ");
    scanf("%d %d", &a, &b);
    resultat = ppcd(a, b);

    if (resultat != 0)
        printf("Le plus petit diviseur de %d et %d est %d\n", a, b, resultat);

    return 0;
}
```

Plus simple et plus lisible, non ?

[[information]]
| Remarquez la présence de deux instructions `return` dans la fonction *ppcd*(). La valeur zéro est retournée afin d'indiquer l'absence d'un diviseur commun.

# Les arguments et les paramètres

À ce stade, il est important de préciser qu'un paramètre est propre à une fonction : il n'est *pas* utilisable en dehors de celle-ci. Par exemple, la variable *a* de la fonction *ppcd*() n'a aucun rapport avec la variable *a* de la fonction *main*().

Voici un autre exemple plus explicite à ce sujet :

```c
#include <stdio.h>


void fonction(int nombre)
{
    ++nombre;
    printf("Variable nombre dans `fonction' : %d\n", nombre);
}


int main(void)
{
    int nombre = 5;

    fonction(nombre);
    printf("Variable nombre dans `main' : %d\n", nombre);
    return 0;
}
```

```text
Variable nombre dans `fonction' : 6
Variable nombre dans `main' : 5
```

Comme vous le voyez, les deux variables *nombre* sont bel et bien distinctes. En fait, lors d'un appel de fonction, vous spécifiez des **arguments** à la fonction appelée. Ces arguments ne sont rien d'autres que des expressions dont les résultats seront ensuite affectés aux différents **paramètres** de la fonction.

[[attention]]
| Notez bien cette différence car elle est très importante : un argument est une *expression* alors qu'un paramètre est une *variable*.

Ainsi, la valeur de la variable *nombre* de la fonction *main*() est passée en argument à la fonction *fonction*() et est ensuite affectée au paramètre *nombre*. La variable *nombre* de la fonction *main*() n'est donc en rien modifiée.