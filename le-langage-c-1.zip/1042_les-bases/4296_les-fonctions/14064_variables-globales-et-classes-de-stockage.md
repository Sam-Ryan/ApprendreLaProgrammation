# Les variables globales

Il arrive parfois que l'utilisation de paramètres ne soit pas adaptée et que des fonctions soient amenées à travailler sur des données qui doivent leur être communes. Prenons un exemple simple : vous souhaitez compter le nombre d'appels de fonction réalisé durant l'exécution de votre programme. Ceci est impossible à réaliser, sauf à définir une variable dans la fonction *main*(), la passé en argument de chaque fonction et de faire en sorte que chaque fonction retourne sa valeur augmentée de un, ce qui est très peu pratique.

À la place, il est possible de définir une variable dite « **globale** » qui sera utilisable par toutes les fonctions. Pour définir une variable globale, il vous suffit de définir une variable *en dehors de tout bloc*, autrement dit en dehors de toutes fonctions.

```c
#include <stdio.h>

void fonction(void);

int appels = 0;


void fonction(void)
{
    ++appels;
}


int main(void)
{
    fonction();
    fonction();
    printf("Ce programme a réalisé %d appel(s) de fonction\n", appels);
    return 0;
}
```

```text
Ce programme a réalisé 2 appel(s) de fonction
```

Comme vous le voyez, nous avons simplement placé la définition de la variable *appels* en dehors de toute fonction et *avant* toute définition de fonctions de sorte qu'elle soit partagée entres-elles.

[[information]]
| Le terme « global » est en fait un peu trompeur étant donné que la variable n'est pas globale au programme, mais tout simplement disponible pour toutes les fonctions du fichier dans lequel elle est située. Ce terme est utilisé en opposition aux paramètres et variables des fonctions qui sont dites « **locales** ».

[[attention]]
| N'utilisez les variables globales que lorsque cela vous paraît *vraiment* nécessaire. Ces dernières étant utilisables dans un fichier entier (voire dans plusieurs, *voy.* le chapitre suivant), elles ont tendances à rendre la lecture du code plus difficile.

# Les classes de stockage

Les variables locales et les variables globales ont une autre différence de taille : leur **classe de stockage**. La classe de stockage détermine (entre autre) la **durée de vie** d'un objet, c'est-à-dire le temps durant lequel celui-ci existera en mémoire.

## Classe de stockage automatique

Les variables locales sont par défaut de classe de stockage **automatique**. Cela signifie qu'elles sont allouées automatiquement à chaque fois que le bloc auquel elles appartiennent est exécuté et qu'elles sont détruites une fois son exécution terminée.

```c
int ppcd(int a, int b)
{
    int min = (a < b) ? a : b;
    int i;

    for (i = 2; i <= min; ++i)
        if (a % i == 0 && b % i == 0)
            return i;

    return 0;
}
```

Par exemple, à chaque fois que la fonction *ppcd*() est appelée, les variables *a*, *b*, *min* et *i* sont allouées en mémoires et détruites à la fin de l'exécution de la fonction.

## Classe de stockage statique

Les variables globales sont *toujours* de classe de stockage **statique**. Ceci signifie qu'elles sont allouées au début de l'exécution du programme et sont détruites à la fin de l'exécution de celui-ci. En conséquence, elles conservent leur valeur tout au long de l'exécution du programme.

Également, à l'inverse des autres variables, celles-ci sont initialisées à zéro si elles ne font pas l'objet d'une initialisation. L'exemple ci-dessous est donc correct et utilise deux variables valant zéro.

```c
#include <stdio.h>

int a;
double b;


int main(void)
{
    printf("%d, %f\n", a, b);
    return 0;
}
```

```text
0, 0.000000
```

Petit bémol tout de même : étant donné que ces variables sont créées au début du programme, elles ne peuvent être initialisée qu'à l'aide de *constantes*. La présence de variables au sein de l'expression d'initialisation est donc proscrite.

```c
#include <stdio.h>

int a = 20; /* Correct */
double b = a; /* Incorrect */


int main(void)
{
    printf("%d, %f\n", a, b);
    return 0;
}
```

## Modification de la classe de stockage

Il est possible de modifier la classe de stockage d'une variable automatique en précédant sa définition du mot-clé `static` afin d'en faire une variable statique.

```c
#include <stdio.h>


int compteur(void)
{
    static int n;

    return ++n;
}


int main(void)
{
    compteur();
    printf("n = %d\n", compteur());
    return 0;
}
```

```text
n = 2
```