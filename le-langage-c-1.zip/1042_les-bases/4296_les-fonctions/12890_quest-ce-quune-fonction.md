Le concept de fonction ne vous est pas inconnu : *printf*(), *scanf*(), et *main*() sont des **fonctions**. 

[[question]]
| Mais qu'est-ce qu'une fonction exactement et quel est leur rôle exactement ?

Une fonction est :

- une suite d'instructions ;
- marquée à l'aide d'un nom (comme une variable finalement) ;
- qui a vocation à être exécutée à plusieurs reprises ;
- qui rassemble des instructions qui permettent d'effectuer une tâche précise (comme afficher du texte à l'écran, calculer la racine carrée d'un nombre, etc).

Pour mieux saisir leur intérêt, prenons un exemple concret :

```c
#include <stdio.h>


int main(void)
{
    int a;
    int b;
    int i;
    int min;

    printf("Entrez deux nombres : ");
    scanf("%d %d", &a, &b);
    min = (a < b) ? a : b;

    for (i = 2; i <= min; ++i)
    {
        if (a % i == 0 && b % i == 0)
        {
            printf("Le plus petit diviseur de %d et %d est %d\n", a, b, i);
            break;
        }
    }

    return 0;
}
```

Ce code, repris du chapitre précédent, permet de calculer le plus petit commun diviseur de deux nombres donnés. Imaginons à présent que nous souhaitions faire la même chose, mais avec deux paires de nombres. Le code ressemblerait alors à ça :

```c
#include <stdio.h>


int main(void)
{
    int a;
    int b;
    int i;
    int min;

    printf("Entrez deux nombres : ");
    scanf("%d %d", &a, &b);
    min = (a < b) ? a : b;

    for (i = 2; i <= min; ++i)
    {
        if (a % i == 0 && b % i == 0)
        {
            printf("Le plus petit diviseur de %d et %d est %d\n", a, b, i);
            break;
        }
    }

    printf("Entrez deux autres nombres : ");
    scanf("%d %d", &a, &b);
    min = (a < b) ? a : b;

    for (i = 2; i <= min; ++i)
    {
        if (a % i == 0 && b % i == 0)
        {
            printf("Le plus petit diviseur de %d et %d est %d\n", a, b, i);
            break;
        }
    }

    return 0;
}
```

Comme vous le voyez, ce n'est pas très pratique : nous devons recopier les instructions de calcul deux fois, ce qui est assez dommage et qui plus est source d'erreurs. C'est ici que les fonctions entre en jeux en nous permettant par exemple de rassembler les instructions dédiées au calcul du plus petit diviseur commun en un seul point que nous solliciterons autant de fois que nécessaire.

[[information]]
| Oui, il est aussi possible d'utiliser une boucle pour éviter la répétition, mais l'exemple aurait été moins parlant. :-°