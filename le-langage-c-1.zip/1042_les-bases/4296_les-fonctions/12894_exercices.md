# Afficher un rectangle

Le premier exercice que nous vous proposons consiste à afficher un rectangle dans la console. Voici ce que devra donner l'exécution de votre programme :

```text
Donnez la longueur : 5
Donnez la largeur : 3

***
***
***
***
***
```

## Correction

[[secret]]
| ```c
| #include <stdio.h>
| 
| void rectangle(int, int);
| 
|
| int main(void)
| {
|     int longueur;
|     int largeur;
| 
|     printf("Donnez la longueur : ");
|     scanf("%d", &longueur);
|     printf("Donnez la largeur : ");
|     scanf("%d", &largeur);
|     printf("\n");
|     rectangle(longueur, largeur);
|     return 0;
| }
| 
|
| void rectangle(int longueur, int largeur)
| {
|     int i;
|     int j;
| 
|     for (i = 0; i < longueur; i++)
|     {
|         for (j = 0; j < largeur; j++)
|             printf("*");
| 
|         printf("\n");
|     }
| }
| ```

[[information]]
| Vous pouvez aussi essayer d'afficher le rectangle dans l'autre sens.

# Afficher un triangle

Même principe, mais cette fois-ci avec un triangle (rectangle). Le programme devra donner ceci :

```text
Donnez un nombre : 5

*
**
***
****
*****
```

Bien entendu, la taille du triangle variera en fonction du nombre entré.

## Correction

[[secret]]
| ```c
| #include <stdio.h>
| 
| void triangle(int);
|
|
| int main(void)
| {
|     int nombre;
| 
|     printf("Donnez un nombre : ");
|     scanf("%d", &nombre);
|     printf("\n");
|     triangle(nombre);
|     return 0;
| }
| 
| void triangle(int nombre)
| {
|     int i;
|     int j;
| 
|     for (i = 0; i < nombre; i++)
|     {
|         for (j = 0; j <= i; j++)
|             printf("*");
| 
|         printf("\n");
|     }
| }
| ```

# En petites coupures ?

Pour ce dernier exercice, vous allez devoir réaliser un programme qui reçoit en entrée une somme d'argent et donne en sortie la plus petite quantité de coupures nécessaires pour reconstituer cette somme.

Pour cet exercice, vous utiliserez les coupures suivantes :

* Des billets de 100€.
* Des billets de 50€.
* Des billets de 20€.
* Des billets de 10€.
* Des billets de 5€.
* Des pièces de 2€.	
* Des pièces de 1€.

Ci dessous un exemple de ce que devra donner votre programme une fois terminé.

```text
Entrez une somme : 285
2 billet(s) de 100.
1 billet(s) de 50.
1 billet(s) de 20.
1 billet(s) de 10.
1 billet(s) de 5.
```

## Correction

[[secret]]
| ```c
| #include <stdio.h>
|
|
| int coupure_inferieure(int valeur)
| {
|     switch (valeur)
|     {
|     case 100:
|         return 50;
|     
|     case 50:
|         return 20;
|     
|     case 20:
|         return 10;
|     
|     case 10:
|         return 5;
|     
|     case 5:
|         return 2;
|     
|     case 2:
|         return 1;
|     
|     default:
|         return 0;
|     }
| }
| 
|
| void coupure(int somme)
| {
|     int valeur;
|     int nb_coupure;
| 
|     valeur = 100;
| 
|     while (valeur != 0)
|     {
|         nb_coupure = somme / valeur;
|         
|         if (nb_coupure > 0)
|         {
|             if (valeur >= 5)
|                 printf("%d billet(s) de %d.\n", nb_coupure, valeur);
|             else
|                 printf("%d pièce(s) de %d.\n", nb_coupure, valeur);
| 
|             somme -= nb_coupure * valeur;
|         }
|
|         valeur = coupure_inferieure(valeur);
|     }
| }
| 
|
| int main(void)
| {
|     int somme;
| 
|     printf("Entrez une somme : ");
|     scanf("%d", &somme);
|     coupure(somme);
|     return 0;
| }
| ```