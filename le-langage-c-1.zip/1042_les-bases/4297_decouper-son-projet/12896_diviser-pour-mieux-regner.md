# Les fonctions

Dans le chapitre précédent, nous avions, entre autres, créé une fonction *triple*() que nous avons placée dans le même fichier que la fonction *main*(). Essayons à présent de les répartir dans deux fichiers distincts. Pour ce faire, il vous suffit de créer un second fichier avec l'extension « **.c** ». Dans notre cas, il s'agira de **main.c** et de **autre.c**.

```c
/* Fichier autre.c */

int triple(int nombre)
{
    return nombre * 3;
}
```
```c
/* Fichier main.c */

int main(void)
{
    int nombre = triple(3);
    return 0;
}
```

La compilation se réalise de la même manière qu'auparavant, si ce n'est qu'il vous est nécessaire de spécifier les deux noms de fichier : `zcc main.c autre.c`. À noter que vous pouvez également utiliser une forme raccourcie : `zcc *.c`, où `*.c` correspond à tous les fichiers portant l'extension « **.c** » du dossier courant.

Si vous testez ce code, vous aurez droit à un bel avertissement de votre compilateur du type : « *implicit declaration of function 'triple'* ». Quel est le problème ? Le problème est que la fonction *triple*() n'est pas déclarée dans le fichier **main.c** et que le compilateur ne la connaît donc pas lorsqu'il compile le fichier. Pour corriger cette situation, nous devons déclarer la fonction en signalant au compilateur que cette dernière se situe dans un autre fichier. Pour ce faire, nous allons inclure le prototype de la fonction *triple*() dans le fichier **main.c** en le précédant du mot-clé ```extern```, qui signifie que la fonction est externe au fichier.

```c
/* Fichier autre.c */

int triple(int nombre)
{
    return nombre * 3;
}
```
```c
/* Fichier main.c */

extern int triple(int nombre);

int main(void)
{
    int nombre = triple(3);
    return 0;
}
```

En terme technique, on dit que la fonction *triple*() est **définie** dans le fichier **autre.c** (car c'est là que se situe le corps de la fonction) et qu'elle est **déclarée** dans le fichier **main.c**. Sachez qu'une fonction ne peut être définie qu'**une seule fois**.

Pour information, notez que le mot-clé ```extern``` est facultatif devant un prototype (il est implicitement inséré par le compilateur). Nous vous conseillons cependant de l'utiliser, dans un soucis de clarté et de symétrie avec les déclarations de variables.

# Les variables

La même méthode peut être appliquée aux variables, mais uniquement à celle ayant une **portée au niveau d'un fichier**. Également, à l'inverse des fonctions, il est plus difficile de distinguer une définition d'une déclaration de variable (elles n'ont pas de corps comme les fonctions). La règle pour les différencier est qu'une déclaration sera précédée du mot-clé ```extern``` alors que la définition non. C'est à vous de voir dans quel fichier vous souhaitez définir la variable, mais elle ne peut être définie qu'**une seule fois**. Enfin, sachez que seule la définition peut comporter une initialisation. Ainsi, cet exemple est tout à fait valide :

```c
/* Fichier autre.c */

int nombre = 10;	/* une définition */
extern int autre;	/* une déclaration */
```
```c
/* Fichier main.c */
extern int nombre;	/* une déclaration */
int autre = 10;		/* une définition */
```

Alors que celui-ci, non :

```c
/* Fichier autre.c */

int nombre = 10;	/* il existe une autre définition */
extern int autre = 10;	/* une déclaration ne peut pas comprendre une initialisation */
```
```c
/* Fichier main.c */

int nombre = 20;	/* il existe une autre définition */
int autre = 10;		/* une définition */
```

# On m'aurait donc menti ?

Nous vous avons dit plus haut qu'il n'était possible de définir une variable ou une fonction qu'une seule fois, en fait ce n'est pas tout à fait vrai. Il est possible de rendre une variable (ayant une portée au niveau d'un fichier) ou une fonction locale à un fichier en précédant sa définition du mot-clé ```static```. De cette manière, la variable ou la fonction est interne au fichier où elle est définie et n'entre pas en conflit avec les autres variables ou fonctions locales à d'autres fichiers. La contrepartie est que la variable ou la fonction ne peut être utilisée que dans le fichier où elle est définie (c'est assez logique). Ainsi, l'exemple suivant est tout à fait correct et affichera 20.

```c
/* Fichier autre.c */
static int nombre = 10;
```
```c
/* Fichier main.c */
#include <stdio.h>

static int nombre = 20;

int main(void)
{
    printf("%d\n", nombre);
    return 0;
}
```

[[erreur]]
| Ne confondez pas l'utilisation du mot-clé `static` visant à modifier la classe de stockage d'une variable automatique avec celle permettant de limiter l'utilisation d'une variable globale à un seul fichier !