Pour terminer ce chapitre, il ne nous reste plus qu'à voir les fichiers d'en-têtes. Jusqu'à présent, lorsque vous voulez utiliser une fonction ou une variable définie dans un autre fichier, vous insérez sa déclaration dans le fichier ciblé. Seulement voilà, si vous utilisez dix fichiers et que vous décidez un jour d'ajouter ou de supprimer une fonction ou une variable ou encore de modifier une déclaration, vous vous retrouvez Gros-Jean comme devant et vous êtes bon pour modifier les dix fichiers ... ce qui n'est pas très pratique.

Pour résoudre ce problème, on utilise des fichiers d'en-têtes (d'extension **.h**). Ces derniers contiennent conventionnellement des déclarations de fonctions et de variables et sont inclus *via* la directive ```#include```, dans les fichiers qui utilisent les fonctions et variables en question.

[[information]]
| Les fichiers d'en-têtes n'ont pas besoin d'être spécifiés lors de la compilation, ils seront automatiquement inclus.

La structure d'un fichier d'en-tête est généralement de la forme :

```c
#ifndef CONSTANTE_H
#define CONSTANTE_H

/* les déclarations */

#endif
```

Les directives du préprocesseur sont là pour éviter les inclusions multiples : vous devez les utiliser pour chacun de vos fichiers d'en-têtes. Vous pouvez remplacer CONSTANTE par ce que vous voulez, le plus simple et le plus fréquent étant le nom de votre fichier, par exemple AUTRE_H si votre fichier se nomme **autre.h**. Voici un exemple d'utilisation de fichier d'en-tête :

```c
/* Fichier d'en-tête autre.h */

#ifndef AUTRE_H
#define AUTRE_H

extern int triple(int nombre);

#endif
```
```c
/* Fichier source autre.c */

#include "autre.h"

int triple(int nombre)
{
    return nombre * 3;
}
```
```c
/*Fichier source main.c */

#include "autre.h"

int main(void)
{
    int nombre = triple(3);
    return 0;
}
```

Plusieurs remarques à propos de ce code :

* dans la directive d'inclusion, les fichiers d'en-têtes sont entre guillemets et non entre crochets comme les fichiers d'en-têtes de la bibliothèque standard ;
* les fichiers sources et d'en-têtes correspondants portent le même nom ;
* nous vous conseillons d'inclure le fichier d'en-tête dans le fichier source correspondant (dans mon cas **autre.h** dans **autre.c**) afin d'éviter des problèmes de portée.