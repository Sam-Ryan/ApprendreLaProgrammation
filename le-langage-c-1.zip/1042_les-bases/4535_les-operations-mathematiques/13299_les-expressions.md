Il est possible de combiner opérateur, variables et constantes littérales pour former des **expressions**, des lignes de code qui sont évaluées et produisent un résultat. Les lignes de code suivantes sont toutes des expressions.

```c
"Bonjour !"
2 + 3
10 > 2
```

Généralement, une expression ne peut être écrite seule et doit faire partie d'une **instruction**. La frontière entre instruction et expression est assez floue puisqu’une instruction peut être composée de nombreuses expressions. Le code ci-dessous est un exemple d’instruction qui est *quasi* une expression (on parle d'**expression-instruction**).

```c
x = 2 + 3;
```

Nous donnons en effet un ordre à l’ordinateur (« affecte la valeur 2 + 3 à *x* »), mais c’est aussi une expression qui produit la valeur 5 comme résultat. Vous verrez qu’en C, la majorité des lignes de code sont des instructions-expressions. C’est ce qui est appellé : la **programmation impérative**. C’est le choix des concepteurs du langage, mais ce n’est pas la seule possibilité (il en existe d’autres, mais ça ne nous concerne pas en tant qu’utilisateurs du C).

# Type d'une expression

Vous avez sans doute remarqué que nous avons utilisé directement des expressions (`2 + 3` par exemple) comme argument de la fonction *printf*(). Rien de bien surprenant me direz-vous... À un détail près : quel indicateur de format doit-on utiliser ? Autrement dit : quel est le type d'une expression ? D'ailleurs, ont-elles un type ?

*Hé* bien, oui. Tout comme les variables, les expressions ont un type. Ce dernier dépend toutefois du type des éléments qui la compose. En l'occurrence, une constante entière comme `2` ou `3` est par défaut de type `int`. Le résultat d'une somme, par exemple, sera donc également de type `int`. Les constantes flottantes comme `5.` ou `78.0` sont, elles, de type `double` et le résultat d'une opération sera alors de type `double`.

[[question]]
| D'accord, mais si j'additionne un `int` avec un `double`, cela me donne quoi ?

Heureusement pour nous, la norme a prévu ces différents cas et à fixer des règles :

* si une opérande est de type `long double`, le résultat est de type `long double` ; si non
* si une opérande est de type `double`, le résultat est de type `double` ; si non
* si une opérande est de type `float`, le résultat est de type `float` ; si non
* si une opérande est de type `unsigned long`, le résultat est de type `unsigned long`; si non
* si une opérande est de type `long`, le résultat est de type `long`; si non
* si une opérande est de type `unsigned int`, le résultat est de type `unsigned int`; si non
* le résultat est de type `int`.

## Suffixes

[[question]]
| *Heu*... D'accord, mais vous venez de dire que les constantes entières étaient de type `int` et que les constantes flottantes étaient de type `double`. Du coup, je fais comment pour obtenir une constante d'un autre type ?

À l'aide d'un suffixe. Celui-ci se place à la fin de la constante et permet de modifier son type. En voici la liste :

Type | Suffixe
---- | -------
u ou U | **unsigned**
l ou L | **long**
f ou F | **float**
l ou L | **long double**

[[information]]
| Notez que les suffixes `L` (ou `l`) et `U` (ou `u`) peuvent être combinés.

## Exemple

Allez, un petit récapitulatif :

```c
#include <stdio.h>


int main(void)
{
    /* long double + int = long double */
    printf("78.56 + 5 = %Lf\n", 78.56L + 5);

    /* long + double = double */
    printf("5678 + 2.2 = %f\n", 5678L + 2.2);

    /* long + unsigned long = unsigned long */
    printf("2 + 5 = %lu\n", 2L + 5UL);
    return 0;
}
```

```text
78.56 + 5 = 83.560000
5678 + 2.2 = 5680.200000
2 + 5 = 7
```

[[information]]
| Nous vous conseillons d'opter pour les lettres majuscules qui ont l'avantage d'être plus lisible.

# Conversions de types

La **conversion de type** est une opération qui consiste à changer le type de la valeur d'une expression. Ainsi, il vous est par exemple possible de convertir une valeur de type ```float``` en type ```int```. 

## Perte d’information

Une perte d’information survient quand le type d’une variable est converti vers un autre type ayant une capacité plus faible et que celui-ci ne peut pas contenir la valeur d'origine. Si, par exemple, nous convertissons un ```double``` de 100 chiffres en un ```short```, il y a perte d’information, car le type ```short``` ne peut pas contenir 100 chiffres. Retenez donc bien cette assertion : une conversion d'un type T vers un type S de plus faible capacité entraîne une perte d'information (une perte de précision, pour les nombres).

Les conversions peuvent être vicieuses et doivent être manipulées avec précaution, au risque de tomber sur des valeurs fausses en cas de perte d’information. Nous découvrirons d’ici quelques chapitres comment connaitre la taille d’un type pour éviter ces pertes d’information.

## Deux types de conversions

Il existe deux types de conversions : les conversions explicites et les conversions implicites.

Les **conversions explicites** sont des conversions demandées par le programmeur. Elles s'utilisent suivant ce modèle :

```text
(<Type>) <Expression>
```

Voici par exemple un code où nous demandons explicitement la conversion d’un ```double``` en ```int```.

```c
int a;
const double pi = 3.14;

a = (int) pi;
```

La valeur de *pi* reste inchangée, elle vaudra toujours 3.14 dans la suite du programme. Par contre, *a* vaut maintenant 3, puisque la valeur de *pi* a été convertie en `int`. 

Les **conversions implicites** sont des conversions spécifiées par la norme et réalisée automatiquement par le compilateur. En général, cela ne pose pas de problème et cela est même désirable. Par exemple, il y a toujours une conversion implicite dans le cadre d'une affectation.

Ainsi, la conversion explicite du code précédent n'est en fait pas nécessaire.

```c
int a;
const double pi = 3.14;

/* Il y a conversion implicite de double en int. */
a = pi;
```