Vous êtes prêts pour un exercice ? 

Essayez de coder une minicalculatrice qui :

* Dit bonjour ;
* Demande deux nombres entiers à l’utilisateur ;	
* Les additionne, les soustrait, les multiplie et les divise (au millième près) ;	
* Dit au revoir.

Un exemple d'utilisation pourrait être :

```text
Bonjour !
Veuillez saisir le premier nombre : 4
Veuillez saisir le deuxième nombre : 7
Calculs :
        4 + 7 = 11
        4 - 7 = -3
        4 * 7 = 28
        4 / 7 = 0.571
Au revoir !
```

Bien, vous avez maintenant toutes les cartes en main donc : au boulot ! :)

[[secret]]
| ```c
| #include <stdio.h>
|
|
|int main(void)
|{
|    int a;
|    int b;
| 
|    printf("Bonjour !\n");
| 
|    /* Nous demandons deux nombres à l'utilisateur */
|    printf("Veuillez saisir le premier nombre : ");
|    scanf("%d", &a);
|    printf("Veuillez saisir le deuxième nombre : ");
|    scanf("%d", &b);
|
|    /* Puis nous effectuons les calculs */
|    printf("Calculs :\n");
|    printf("\t%d + %d = %d\n", a, b, a + b);
|    printf("\t%d - %d = %d\n", a, b, a - b);
|    printf("\t%d * %d = %d\n", a, b, a * b);
|    printf("\t%d / %d = %.3f\n", a, b, a / (double)b);
|    printf("Au revoir !\n");
|    return 0; 
|}
|```

Vous y êtes arrivé sans problème ? Bravo ! Dans le cas contraire, ne vous inquiétiez pas, ce n'est pas grave. Relisez bien tous les points qui ne vous semblent pas clairs et ça devrait aller mieux.