Dans les expressions vues au-dessus, nous avons utilisé des affectations pour sauvegarder le résultat de l'opération dans une variable. Les expressions obtenues ainsi sont assez longues, et on peut se demander s'il existe des moyens pour écrire moins de code. *Hé* bien, le langage C fournit des écritures pour simplifier la vie. Certains cas particuliers peuvent s'écrire avec des raccourcis, du « **sucre syntaxique** ».

# Les opérateurs combinés

Comment vous y prendriez-vous pour multiplier une variable par trois ? La solution qui devrait vous venir à l'esprit serait d'affecter à la variable son ancienne valeur multipliée par trois. Autrement dit :

```c
int variable = 3;

variable = variable * 3;
printf("variable * 3 = %d\n", variable);
```

```text
variable * 3 = 9
```

Ce qui est parfaitement correct. Cependant, cela implique de devoir écrire deux fois le nom de la variable, ce qui est quelques peu pénible et source d'erreur. Aussi, il existe des opérateurs combinés qui réalise une affectation et une opération en même temps. Les voici :

Opérateur combiné | Équivalent à
----------------- | ------------
variable += nombre | variable = variable + nombre
variable -= nombre | variable = variable - nombre
variable *= nombre | variable = variable * nombre
variable /= nombre | variable = variable / nombre
variable %= nombre | variable = variable % nombre

Avec le code précédent, cela donne donc :

```c
int variable = 3;

variable *= 3;
printf("variable * 3 = %d\n", variable);
```

```text
variable * 3 = 9
```

# L'incrémentation et la décrémentation

L'**incrémentation** et la **décrémentation** sont deux opérations qui, respectivement, ajoute ou enlève 1 à une variable. Avec les opérateurs vu précédemment, cela se traduit par : 

```c
variable += 1; /* Incrémentation */
variable -= 1; /* Décrémentation */
```
Cependant, ces deux opérations étant très souvent utilisée, elles ont droit chacune à un opérateur spécifique disponible sous deux formes :

- une forme **préfixée** ;
- une forme **suffixée**.

La forme préfixée s'écrit comme ceci :

```c
++variable; /* Incrémentation */
--variable; /* Décrémentation */
```

La forme suffixée s'écrit comme cela :

```c
variable++; /* Incrémentation */
variable--; /* Décrémentation */
```

Le résultat des deux paires d'opérateurs est le même : la variable *variable* est incrémentée ou décrémentée, à une différence près : le résultat de l'opération. Dans le premier cas (opérateur suffixé) ce sera la valeur de la variable et dans l'autre (opérateur préfixé) ce sera la valeur de la variable augmentée ou diminuée de un. Illustration :

```c
#include <stdio.h>

int main(void)
{
    int a = 10;
    int b = 10;

    printf("a++ = %d\n", a++);
    printf("a-- = %d\n", a--);
    printf("++b = %d\n", ++b);
    printf("--b = %d\n", --b);
    printf("a = %d\n", a);
    printf("b = %d\n", b);
    return 0;
}
```

```text
a++ = 10
a-- = 11
++b = 11
--b = 10
a = 10
b = 10
```