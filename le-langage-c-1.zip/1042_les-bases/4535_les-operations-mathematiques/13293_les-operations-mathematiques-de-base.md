Jusqu'à présent, nous nous sommes contenter d'afficher du texte et de manipuler très légèrement les variables. Voyons à présent comment nous pouvons réaliser quelques opérations de base. Le langage C nous permets d'en réaliser cinq :
     
* l'addition (opérateur `+`) ;       
* la soustraction (opérateur `-`) ;       
* la multiplication (opérateur `*`) ;       
* la division (opérateur `/`) ;        
* le modulo (opérateur `%`).

[[information]]
| Le langage C fournit bien entendu d’autres fonctions mathématiques et d'autres opérateurs, mais il est encore trop tôt pour vous les présenter.

# Division et modulo

Les quatre premières opérations vous sont connues depuis l'école primaire. Cependant, une chose importante doit être précisée concernant la division : quand les deux nombres manipulés sont des entiers, il s'agit d'une division entière. Autrement dit, le quotient sera un entier et il peut y avoir un reste. Par exemple, $\frac{15}{6}$, ne donnera pas 2,5 (division réelle), mais un quotient de 2, avec un reste de 3.

```c
printf("15 / 4 = %d\n", 15 / 6);
```

```text
15 / 4 = 2
```

Le modulo est un peu le complément de la division entière : au lieu de donner le quotient, il renvoie le reste d’une division euclidienne. Par exemple, le modulo de 15 par 6 est 3, car $15 = 2 \times 6 + 3$.

```c
printf("15 % 4 = %d\n", 15 % 4);
```

```text
15 % 6 = 3
```

Avec des flottants, la division se comporte autrement, et n'est pas une division avec reste : la division de deux flottants donnera un résultat "exact", avec potentiellement plusieurs chiffres après la virgule.

```c
printf("15 / 4 = %f\n", 15. / 4.);   /* En C, ce n’est la même chose que 15 / 4 */
```
 
```text
15 / 4 = 3.750000
```

# Utilisation

Il est possible d'affecter le résultat d'une expression contenant des calculs à une variable, comme lorsque nous les utilisons comme argument de *printf*(). 

```c
#include <stdio.h>

int main(void)
{
    int somme = 5 + 3;

    printf("5 + 3 = %d\n", somme);
    return 0;
}
```

```text
5 + 3 = 8
```

Toute opération peut manipuler :

- des constantes ;
- des variables ;
- les deux à la fois.

Exemple avec des constantes :

```c
#include <stdio.h>

int main(void)
{
    printf("2 + 3 = %d\n", 2 + 3);
    printf("8 - 12 = %d\n", 8 - 12);
    printf("6 x 7 = %d\n", 6 * 7);
    printf("11 % 4 = %d\n", 11 % 4);
    return 0;
}
```

```text
2 + 3 = 5
8 - 12 = -4
6 x 7 = 42
11 % 4 = 3
```

Un autre exemple avec des variables :

```c
int a = 5;
int b = 3;
int somme = a + b;

printf("%d + %d = %d\n", a, b, somme);
```

```text
5 + 3 = 8
```

Et enfin, un exemple qui mélange variables et constantes :

```c
int a = 5;
int b = 65;

printf("%d\n", b / a * 2 + 7 % 2);
```

```text
27
```

# La priorité des opérateurs

Dans l'exemple précédent, nous avons utilisé plusieurs opérations dans une même ligne de code, une même expression. Dans ces cas là, faites attention à la **priorité des opérateurs** ! Comme en mathématiques, certains opérateurs passent avant d’autres : ```* / %``` ont une priorité supérieure à ```+ -```.

Dans ce code : 

```c
a = b + c * 4;
```

C’est ```c * 4``` qui sera exécuté d’abord, puis ```b``` sera ajouté au résultat. Faites donc attention, sous peine d’avoir de mauvaises surprises. Dans le doute, ajoutez des parenthèses.