Il est parfaitement possible d'**imbriquer** une ou plusieurs boucles en plaçant une boucle dans le corps d'une autre boucle.

```c
int i;
int j;

for (i = 0 ; i < 1000 ; ++i)
{
    for (j = i ; j < 1000 ; ++j)
    {
          /*  code  */
    }
}
```

Cela peut servir par exemple pour déterminer la liste des nombres dont la somme vaut mille.

```c
#include <stdio.h>


int main(void)
{
    int i;
    int j;

    for (i = 0 ; i <= 1000 ; ++i)
    {
        for (j = i ; j <= 1000 ; ++j)
        {
            if (i + j == 1000) 
            {
                printf ("%d + %d = 1000 \n", i, j);
            }
        }
    }

    return 0;
}
```

[[information]]
| Vous n'êtes bien entendu pas tenu d'imbriquer des types de boucles identiques. Vous pouvez parfaitement plaçer, par exemple, une boucle `while` dans une boucle `for`.