# Calcul du PGCD de deux nombres

Le PGCD de deux nombres est le plus grand nombre qui peut diviser ces derniers. Par exemple, le PGCD de 15 et 12 est 3 et celui de 24 et 18 est 6.

Pour le calculer, nous devons disposer de deux nombres : a et b avec a *supérieur* à b. Ensuite, nous effectuons la division entière de *a* par *b*.

* si le reste est nul, alors nous avons terminé ;
* si le reste est non nul, nous revenons au début en remplaçant *a* par *b* et *b* par le reste.

Avec cette explication, vous avez tout ce qu'il vous faut : à vos claviers !

## Correction

[[secret]]
| ```c
| #include <stdio.h>
|
|
| int main (void)
| {
|     unsigned int a = 46;
|     unsigned int b = 42;
|     unsigned int reste = a % b;
| 
|     while (reste != 0)
|     {
|         a = b;
|         b = reste;
|         reste = a % b;
|     }
|
|     printf("%d", b);
|     return 0;
| }
| ```

# Une overdose de lapins

Au 13ème siècle, un mathématicien italien du nom de *Leonardo Fibonacci* posa un petit problème dans un de ses livres, qui mettait en scène des lapins. Ce petit problème mis en avant une suite de nombre particulière, nommée la [suite de Fibonnaci](http://fr.wikipedia.org/wiki/Suite_de_Fibonacci), nommée du nom de son inventeur. Il fit les hypothèses suivantes.
	
* le premier mois, nous plaçons un couple de deux lapins dans un enclos ;
* un couple de lapin ne procréer qu'à partir du troisième mois de sa venue dans l'enclos (autrement dit, il ne se passe rien pendant les deux premiers mois) ;
* chaque couple capable de procréer donne naissance à un nouveau couple ;
* enfin, pour éviter tout problème avec la SPA, les lapins ne meurent jamais.

Le problème est le suivant : combien il y a-t-il de couples de lapins dans l'enclos au n-ième mois ? Le but de cet exercice est de réaliser un petit programme qui fasse ce calcul automatiquement.

## Indice

[[secret]]
| Allez, un petit coup de pouce : suivant l'énoncé, un couple ne donne naissance à un autre couple qu'au début du troisième mois de son apparition. Combien de couple y a-t-il le premier mois ? Un seul. Combien y en a-t-il le deuxième mois ? Toujours un seul. Combien y en a-t-il le troisième mois (le premier couple étant là depuis deux mois) ? Deux. Avec ceci, vous devriez venir à bout du problème.

## Correction

[[secret]]
|```c
|#include <stdio.h>
|
|
|int main(void)
|{
|    int a;
|    int b;
|    int nb_lapins = 1;
|    int const mois = 10;
|    int i;
|
|    a = 0;
|    b = 1;
|
|    for (i = 1; i < mois; ++i)
|    {
|        nb_lapins = a + b;
|        a = b;
|        b = nb_lapins;
|    }
|
|    printf("Au mois %d, il y a %d lapins\n", mois, nb_lapins);
|    return 0;	
|}
|```

# Des pieds et des mains pour convertir mille miles

Si vous avez déjà voyagé en Grande-Bretagne ou aux États-unis, vous savez que les unités de mesure utilisées dans ces pays sont différentes des nôtres. Au lieu de notre cher système métrique, dont les stars sont les centimètres, mètres et kilomètres, nos amis outre-manche et outre-atlantique utilisent le système impérial, avec ses pouces, pieds et *miles*, voire lieues et *furlongs* ! Et pour empirer les choses, la conversion n'est pas toujours simple à effectuer de tête ... Aussi, la lecture d'un ouvrage tel que *Le Seigneur des Anneaux*, dans lequel toutes les distances sont exprimées en unités impériales, peut se révéler pénible.

Grâce au langage C, nous allons aujourd'hui résoudre tous ces problèmes ! Votre mission, si vous l'acceptez, sera d'écrire un programme affichant un tableau de conversion entre miles et kilomètres. Le programme ne demande rien à l'utilisateur, mais doit afficher quelque chose comme ceci :

```console
Km    Miles
5     8
10    16
15    24
20    32
25    40
30    48
```

Autrement dit, le programme compte les kilomètres de 5 en 5 jusqu'à 30, et affiche à chaque fois la valeur correspondante en *miles*. Un *mile* vaut exactement 1.609344 km, cependant, nous allons utiliser une valeur approchée : nous prendrons huit-cinquièmes de kilomètre (soit 1.6km). Autrement dit, $1$ km $= \frac{8}{5}$ miles.

## Correction

[[secret]]
| ```c
| #include <stdio.h>
| 
|
| int main(void)
| {
|     unsigned km = 0;
| 
|     printf("Km - Miles\n");
| 
|     do
|     {
|         km += 5;
|         printf("%u %u\n", km, km * 8 / 5);
|     } while(km < 30);
|     
|     return 0;
| }
| ```

# Puissances de trois

Passons à un exercice un peu plus difficile, du domaine des mathématiques. Essayez de le faire même si vous n'aimez pas les mathématiques. 

Vous devez vérifier si un nombre est une puissance de trois, et afficher le résultat. De plus, si c'est le cas, vous devez afficher l'exposant qui va avec.

## Indice

[[secret]]
| Pour savoir si un nombre est une puissance de trois, vous pouvez utiliser le modulo. Attention cependant : si le reste vaut 0, le nombre n'est pas forcément une puissance de trois (par exemple, le reste de la division de 15 par 3 est nul, mais 15 n'est pas une puissance de trois).

## Correction

[[secret]]
| ```c
| #include <stdio.h>
|
|
|/* Un petite explication s'impose, notamment au niveau
|du for. La première partie qui correspond à l'initialisation
|de i ne devrait pas vous poser trop de soucis. Ensuite,
|le i /= 3 sert à diviser i par trois à chaque itération. Au
|tour de la condition, le principe est simple : tant que le
|reste de la division de i par 3 est égal à zéro et que i est
|positif, on incrémente l'exposant. Enfin, pour déterminer
|si le nombre est une puissance de trois, il suffit de vérifier
|si i est égal à 1 (essayer avec de petits nombres dans votre
|tête ou sur papier si vous n'êtes pas convaincu). */ 
|
| int main(void)
| {
|     int number, i;
|     int exposant = 0;
| 
|     puts("Veuillez entrez un nombre : ");
|     scanf("%d", &number);
| 
|     for (i = number; (i % 3 == 0) && (i > 0); i /= 3)
|     {
|         ++exposant;
|     }
| 
| /* Chaque division successive divise i par 3, donc 
| si nous obtenons finalement i == 1, c'est que le nombre est bien
| une puissance de 3 */
|     if (i == 1)
|     {
|         printf ("%d est égal à 3 ^ %d\n", number, exposant);
|     }
|     else
|     {
|         printf("%d n'est pas une puissance de 3\n", number);
|     }
| 
|     return 0;
| }
| ```

# La disparition : le retour

Connaissez-vous le roman *La Disparition* ? Il s'agit d'un roman français de Georges Perec, publié en 1969. Sa particularité est qu'il ne contient *pas une seule fois* la lettre « e ». On appelle ce genre de textes privés d'une lettre des *lipogrammes*. Celui-ci est une prouesse littéraire, car la lettre « e » est la plus fréquente de la langue française : elle représente une lettre sur six en moyenne ! Le roman faisant environ 300 pages, il a sûrement fallu déployer des trésors d'inventivité pour éviter tous les mots contenant un « e ».

Si vous essayez de composer un tel texte, vous allez vite vous rendre compte que vous glissez souvent des « e » dans vos phrases sans même vous en apercevoir. Nous avons besoin d'un vérificateur qui nous sermonnera chaque fois que nous écrirons un « e ». C'est là que le langage C entre en scène !

Écrivez un programme qui demande à l'utilisateur de taper une phrase, puis qui affiche le nombre de « e » qu'il y a dans celle-ci. Une phrase se termine toujours par un point « . », un point d'exclamation « ! » ou un point d'interrogation « ? ». Pour effectuer cet exercice, il sera indispensable de lire la phrase caractère par caractère.

Exemple :

```text
Entrez une phrase : Bonjour, comment allez-vous ?
Au moins une lettre 'e' a été repérée (précisémment : 2) !
```

## Indice

[[secret]]
| La première chose à faire est d'afficher un message de bienvenue, afin que l'utilisateur sache quel est votre programme. Ensuite, Il vous faudra lire les caractères tapés (rappelez-vous les différents formats de la fonction *scanf*()), un par un, *jusqu'à ce qu*'un point (normal, d'exclamation ou d'interrogation) soit rencontré. Dans l'intervalle, il faudra compter chaque « e » qui apparaîtra. Enfin, il faudra afficher le nombre de « e » qui ont été comptés, si présents.

## Correction

[[secret]]
| ```c
| #include <stdio.h>
| 
| int main(void)
| {
|     unsigned compteur = 0;
|     char c;
| 
|     printf("Entrez une phrase se terminant par '.', '!' ou '?' : ");
| 
|     do
|     {
|         scanf("%c", &c);
|         if (c == 'e' || c == 'E')
|         {
|             compteur++;
|         }
|     } while (c != '.' && c != '!' && c != '?');
|     
|     if (compteur == 0)
|     {
|         printf("Aucune lettre 'e' repérée. Félicitations !\n");
|     }
|     else
|     {
|         printf("Au moins une lettre 'e' a été repérée (précisémment : %d) !\n", compteur);
|     }
|     
|     return 0;
| }
| ```