# Syntaxe

```c
for (/* expression 1 */ ; /* condition */ ; /* expression 2 */)
{
    /* instructions à répéter */
}
```

Une boucle ```for``` se décompose en trois parties :

* une expression, qui sera le plus souvent l'initialisation d'une variable ;
* une condition ;
* une seconde expression, qui consistera le plus souvent en l'incrémentation d'une variable.

Techniquement, une boucle `for` revient en fait à écrire ceci :

```c
/* expression 1 */

while (/* condition */)
{
    /* bloc d'instructions à répéter */
    /* expression 2 */
}
```

## Exemple

Le fonctionnement de cette boucle est plus simple à appréhender à l'aide d'un exemple :

```c
#include <stdio.h>


int main(void)
{
    int i;

    for (i = 0 ; i < 5 ; ++i)
    {
        printf("la variable i vaut %d\n", variable);
    }

    return 0;
}
```

```console
variable vaut 0
variable vaut 1
variable vaut 2
variable vaut 3
variable vaut 4
```

Ce qui, comme dit précédemment, revient exactement à écrire :

```c
#include <stdio.h>


int main(void)
{
    int i;

    i = 0;

    while (i < 5)
    {
        printf("la variable i vaut %d\n", variable);
        ++i;
    }

    return 0;
}
```

[[attention]]
| Notez bien que la première expression, `i = 0`, est située *en dehors* du corps de la boucle. Elle n'est donc pas évaluée à chaque tour.

## Exercice

Essayez de réaliser un programme qui calcule la somme de tous les nombres compris entre 1 et n (n étant déterminé par vos soins). Autrement dit, pour un nombre n donné, vous allez devoir calculer $1 + 2 + 3 + ... + (N-2) + (N-1) + N$ .

[[secret]]
| ```c
| #include <stdio.h>
| 
|
| int main (void)
| {
|     const unsigned int n = 250;
|     unsigned int somme = 0;
|     unsigned int i;
| 
|     for (i = 1; i <= n; ++i)
|     {
|         somme += i;
|     }
| 
|     printf ("Somme de 1 à %u : %u\n", n, somme);
|     return 0;
| }
| ```

[[information]]
| Notez qu'il est possible de réaliser cet exercice sans boucle en calculant : $\frac {N \times (N+1)} {2}$.

# Utilisation avancée

Les boucles ```for``` ne vous ont pas encore livré tous leurs secrets. Comme quoi, on en apprend toujours plus sur le C, même quand on pense déjà bien le connaître.

## Plusieurs compteurs

Le nombre de compteurs ou de conditions n'est pas limité, comme le prouve le code suivant.

```c
for (i = 0, j = 2 ; i < 10 && j < 12; i++, j += 2)
```

Ici, on définit deux compteurs *i* et *j* initialisés respectivement à 0 et 2. On exécute le contenu de la boucle tant que *i* est inférieur à 10 et que *j* est inférieur à 12, et on augmente *i* de 1 et *j* de 2 à chaque tour de boucle. Le code est encore assez lisible, cependant la modération est de mise, un trop grand nombre de paramètres rendant le ```for``` illisible.