La boucle ```do while``` fonctionne comme la boucle ```while```, à un petit détail prêt : une boucle ```do while``` s'exécutera toujours au moins une fois, alors qu'une boucle ```while``` peut ne pas s'exécuter si la condition est fausse dès le départ.

![Instruction do...while...](http://zestedesavoir.com/media/galleries/1501/c92b9ffa-a6e9-45eb-920a-74afd4fee7b5.png.960x960_q85.jpg)

# Syntaxe

À la différence de la boucle `while`, la condition est placée à la fin du bloc d'instruction à répéter, ce qui explique pourquoi celui-ci est toujours exécuté au moins une fois. Remarquez également la présence d'un point-virgule à la fin de l'instruction qui est obligatoire.

```c
do
{
    /* bloc d'instruction à répéter */
} while (/* condition */);
```

## Exemple 1

Voici le même code que celui présenté avec l'instruction `while` :

```c
#include <stdio.h>


int main(void)
{
    int i = 0;

    do
    {
        printf("La variable i vaut %d\n", i);
        ++i;
    } while (i < 5);

    return 0;
}
```

```text
La variable i vaut 0
La variable i vaut 1
La variable i vaut 2
La variable i vaut 3
La variable i vaut 4
```

## Exemple 2

Comme nous vous l'avons dit plus haut, une boucle ```do while``` s'éxecute au moins une fois.

```c
#include <stdio.h>


int main(void)
{    
    do
    {
        printf("Boucle do-while\n");
    } while (0);

    return 0;
}
```

```text
Boucle do-while
```

Comme vous le voyez, malgré que la condition est fausse (pour rappel, une valeur nulle correspond à une valeur fausse), le corps de la boucle est exécuté une fois puisque la condition n'est évaluée qu'*après* que le bloc d'instruction ait été parcouru.