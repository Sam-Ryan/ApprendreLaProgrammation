La première des boucles que nous allons étudier est la boucle ```while``` (qui signifie "tant que"). Celle-ci permet de répéter un bloc d'instruction tant qu'une condition est remplie.

![Structure While](http://zestedesavoir.com/media/galleries/1501/79315757-7e50-44a4-8e7c-b26a3b34aeb0.png.960x960_q85.jpg)

# Syntaxe

La syntaxe de notre boucle ```while``` est assez simple :

```c
while (/* condition */)
{
    /* bloc d'instruction à répéter */ 
}
```

## Exemple

```c
#include <stdio.h>


int main(void)
{
    int i = 0;

    while (i < 5)
    {
        printf("La variable i vaut %d\n", i);
        i++;
    }

    return 0;
}
```

```text
La variable i vaut 0
La variable i vaut 1
La variable i vaut 2
La variable i vaut 3
La variable i vaut 4
```

Le fonctionnement est simple à comprendre : 

* au départ, notre variable *i* vaut 0. Étant donné que 0 est bien inférieur à 5, la condition est vraie, le corps de la boucle est donc exécuté ;
* la valeur de *i* est affichée ;
* *i* est incrémentée et vaut désormais 1 ;
* la condition de la boucle est de nouveau vérifiée ;

Ces étapes vont ainsi se répéter pour les valeurs 1, 2, 3 et 4. Quand la variable *i* vaudra 5, la condition sera fausse, et l'instruction ```while``` sera alors passée.

[[information]]
| Dans cet exemple, nous utilisons une variable nommée *i*. Ce nom lui vient d'une contraction du mot anglais *iterator* qui signifie que cette variable sert à l'itération (la répétition) du corps de la boucle. Ce nom est tellement court et explicite qu'il est pour ainsi dire devenu une convention de nommage en C.

# Exercice

Essayez de réaliser un programme qui détermine si un nombre entré par l'utilisateur est premier. Pour rappel, un nombre est dit premier s'il n'est divisible que par 1 et par lui-même. Notez que si un nombre x est divisible par y alors le résultat de l'opération `x % y` est nul.

[[secret]]
| ```c
| #include <stdio.h>
| 
|
|int main(void)
|{
|    int nombre;
|    int i = 2;
| 
|    puts("nombre = ");
|    scanf("%d", &nombre);
| 
|    while ((i < nombre) && (nombre % i != 0))
|    {
|        ++i;
|    }
| 
|    if (i == nombre)
|    {
|        printf("%d est un nombre premier\n", nombre);
|    }
|    else
|    {
|        printf("%d n'est pas un nombre premier\n", nombre);
|    }
| 
|    return 0;
|}
| ```