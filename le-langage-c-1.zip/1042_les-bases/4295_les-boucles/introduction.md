Dans ce chapitre, nous allons aborder les **boucles**. Une boucle est un moyen de répéter des instructions suivant le résultat d'une condition. Ces structures, dîtes **itératives**, que nous allons voir dans ce chapitre sont les suivantes :

Structure de contrôle  | Action
------------- | -------------
***while...***  | répète une suite d'instructions tant qu'une condition est respectée.
***do...while...***  | répète une suite d'instructions tant qu'une condition est respectée. Le groupe d'instructions est exécuté au moins une fois.
***for...***  | répète un nombre fixé de fois une suite d'instructions.