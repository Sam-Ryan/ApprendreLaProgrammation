### Le langage C
Malgré tous ces langages de programmation disponibles, nous allons dans
ce tutoriel nous concentrer sur un seul langage : le langage C. Avant de
parler des caractéristiques de ce langage et des choix qui nous amènent
à l’étudier dans ce cours, faisons un peu d’histoire.

### L'histoire du C ###

Le langage C est né au début des années 1970 dans les
laboratoires AT&T aux États-Unis. Son concepteur, [Dennis
Ritchie](http://fr.wikipedia.org/wiki/Dennis_Ritchie), souhaitait améliorer un
langage existant, le B, afin de lui adjoindre des nouveautés. En 1973, le C
était pratiquement au point, et il commença à être distribué l’année
suivante. Son succès était tel auprès des informaticiens que l'ANSI en
1989, puis l’ISO en 1990 décidèrent de le normaliser, c’est-à-dire
d’établir les règles officielles du langage. On parle donc de C89 / C
ANSI ou bien C90 / C ISO (au choix). D’autres normes sortirent plus tard,
en 1999 (on parle de C99) et en 2011 (on parle de C11).

[[information]]
| Si vous voulez en savoir plus sur l’histoire du C, lisez donc [ce tutoriel](http://c.developpez.com/cours/historique-langage-c/).

### Pourquoi apprendre le C ? ###

C’est une très bonne question. Après tout, il existe tellement de langages
différents, et on peut logiquement se demander pourquoi le C en particulier
? Il y a plusieurs raisons à ça.

* Sa **popularité** : il fait partie des langages de programmation les plus
utilisés. Il possède une communauté très importante et de nombreux cours
et documentations. Vous aurez donc toujours du monde pour vous aider. De
plus, il existe beaucoup de programmes et de bibliothèques développés en
et pour le C.	
* Sa **rapidité** : le C est connu pour être un langage très rapide, ce qui
en fait un langage de choix pour tout programme où la vitesse est cruciale.
* Sa **légèreté** : le C est léger, ce qui le rend utile pour les
programmes embarqués où la mémoire disponible est faible.	 
* Sa **portabilité** : cela signifie qu’un programme développé en C
peut être compilé pour fonctionner sur différentes machines sans devoir
changé ledit code.

Ce ne sont que quelques raisons, mais elles sont à notre goût suffisantes
pour apprendre ce langage. Bien entendu, le C comporte aussi sa part
de défauts. On peut citer la tolérance aux comportements dangereux qui
fait que le C demande beaucoup de rigueur pour ne pas tomber dans certains
« pièges », un nombre plus restreint de concepts (c’est parfois un
désavantage, car on est alors obligé de recoder certains mécanismes qui
existent nativement dans d’autres langages), etc. D’ailleurs, si votre
but est de développer rapidement des programmes amusants, le C n’est pas
du tout adapté pour ça, et nous vous encourageons à vous tourner vers
d’autres langages comme le Python par exemple.

Le C possède aussi une caractéristique qui est à la fois un avantage et
un défaut : c’est un langage de plutôt **bas niveau**. Cela veut dire
qu’il permet de programmer en étant proche de sa machine, en cherchant
à vraiment comprendre ce que l’on fait. C’est à double tranchant :
c’est plus difficile et plus long, mais on en apprend beaucoup sur sa
machine et on a un grand contrôle de ce que l’on fait. Cette notion de
bas niveau est d’ailleurs à opposer aux langages de **haut niveau**,
qui permettent de programmer en faisant abstraction d’un certain nombre
de choses. Le développement est souvent plus facile et plus rapide, mais en
contrepartie on voit moins bien le fonctionnement de la machine. Ces notions
de haut et bas niveau sont néanmoins à nuancer, car elles dépendent du
langage utilisé et du point de vue du programmeur. 

Une petite note pour terminer : peut-être avez-vous entendu parler du C++
? C’est un langage de programmation qui a été inventé dans les années
1980 par Bjarne Stroustrup, un collègue de Dennis Ritchie, qui souhaitait
rajouter des éléments au C. Bien que très ressemblants à l’époque
de sa création, ces deux langages sont aujourd’hui très différents
(on ne programme pas et on ne réfléchit pas de la même façon en C et en
C++). Ne croyez pas qu’il y a un langage meilleur que l’autre. Ils sont
simplement différents. Si d’ailleurs votre but est d’apprendre le C++,
nous vous encourageons à le faire. Contrairement à ce que l’on pense et
dit souvent, il n’y a pas besoin de connaitre le C pour cela. Ce tutoriel
ne se concentrera quant à lui que sur ce dernier.

### La norme ###

Comme précisé plus haut, le C est un langage qui possède des règles. Ces
règles ont été définies par des informaticiens professionnels et sont
toutes regroupées dans ce que l’on appelle **la norme** du langage. Cette
norme sert de référence à tous les programmeurs. Chaque fois que l’on
a un doute ou que l’on se pose une question, le premier réflexe est de
regarder dans la norme ce qui est dit. Bien entendu, la norme n’est pas
parfaite et ne répond pas à toutes les questions, et ne précise pas tous
les détails. Néanmoins, elle reste la référence du programmeur. 

Cette norme sert aussi de référence pour les compilateurs. En effet, tous
les compilateurs respectent cette norme (en règle générale), ce qui fait
qu’il n’y aura pas différentes interprétations d’un même code. Cette
norme est l’équivalent des règles d’orthographe, de grammaire et de
conjugaison de nos interprètes. Imaginez si chacun écrivait ou conjuguait à
sa guise tout ce qu'il veut. La norme sert donc à officialiser tout un tas de
règles pour que tous les interprètes (et donc les compilateurs) la suivent.

Il existe plusieurs versions de la norme : le C89, le C99 et le C11. Dans ce
cours, nous avons décidé de nous servir de la norme C89. En effet, même
si c’est la plus ancienne et qu’elle semble restrictive à certains,
elle permet néanmoins de développer avec n’importe quel compilateur sans
problèmes, contrairement aux normes C99 et C11 que tous les compilateurs
ne connaissent pas. De plus, il est très facile de passer aux normes plus
récentes par la suite. Voici [le lien](http://flash-gordon.me.uk/ansi.c.txt)
vers le brouillon de cette norme. Cela signifie que ce n’est pas la version
définitive et officielle de la norme, cependant le brouillon est largement
suffisant pour notre niveau et surtout gratuit (la norme officielle coûtant
relativement chère). Bien entendu, cette norme est en anglais.

*[ANSI]: American National Standard Institute
*[ISO]: International Standard Organisation