# La programmation, qu’est-ce que c’est ?

La programmation est une branche de l’informatique qui sert à créer des
**programmes**. Tout ce que vous possédez sur votre ordinateur sont des
programmes : votre navigateur Internet (Internet Explorer, Firefox, Opera,
etc.), votre système d’exploitation (Windows, GNU/Linux, Mac OS, etc.) qui
est un regroupement de plusieurs programmes appelés **logiciels**, votre
lecteur MP3, votre logiciel de discussion instantanée, vos jeux vidéos, etc.

# Les programmes expliqués en long, en large et en travers

Un programme est une séquence d’**instructions**, d’ordres, donnés
à l’ordinateur afin qu’il exécute des actions. Ces instructions sont
généralement assez basiques. On trouve ainsi des instructions d’addition,
de multiplication, ou d’autres opérations mathématiques de base, qui
font que notre ordinateur est une vraie machine à calculer. D’autres
instructions plus complexes peuvent exister, comme des opérations permettant
de comparer des valeurs, traiter des caractères, etc.

Créer un programme, c’est tout simplement créer une suite d’instructions
de base qui permettra de faire ce que l’on veut. Tous les programmes sont
créés ainsi : votre lecteur MP3 donne des instructions à l’ordinateur
pour écouter de la musique, le *chat* donne des instructions pour discuter
avec d’autres gens sur le réseau, le système d’exploitation donne des
instructions pour dire à l’ordinateur comment utiliser le matériel, etc.

Petite remarque : on ne peut pas créer d’instructions. Notre ordinateur
est conçu, câblé, et peut traiter certaines instructions de bases,
précâblées dans ses circuits, sans possibilité d’en inventer d’autres
(sauf cas particulier vraiment tordus). Notre ordinateur contient un
composant électronique particulier, spécialement conçu pour effectuer
ces instructions : il s’agit du **processeur**. Ce qu’il faut retenir,
c’est que notre ordinateur contient un circuit, le processeur, qui permet
d’effectuer de petits traitements de base qu’on appelle instructions et
qui sont la base de tout ce qu’on trouve sur un ordinateur.

[[information]]
| Pour les curieux, il existe [un cours sur le fonctionnement d’un ordinateur](http://www.siteduzero.com/tutoriel-3-509203-fonctionnement-d-un-ordinateur-depuis-zero.html) expliqué depuis zéro.

Les instructions sont stockées dans notre ordinateur sous la forme de
chiffres binaire (appelés *bits* en anglais), autrement dit sous forme de
zéro ou de un. Ainsi, nos instructions ne sont rien d’autre que des suites
de zéro et de un, stockées dans notre ordinateur, et que notre processeur
va interpréter comme étant des ordres à effectuer. Ces suites de zéro
et un sont difficilement compréhensibles pour nous humains, et parler à
l’ordinateur avec des 0 et des 1 est très dur et très long. Autant vous
dire que créer des programmes de cette façon revient à se tirer une balle
dans le pied. 

Pour vous donner un exemple, imaginez que vous devez communiquer avec un
étranger alors que vous ne connaissez pas sa langue. Communiquer avec un
ordinateur reviendrait à devoir lui donner une suite de zéro et de un, ce
dernier étant incapable de comprendre autre chose. Ce langage s’appelle :
le **langage machine**.

Une question doit certainement vous venir à l'esprit : comment communiquer
avec notre processeur sans avoir à apprendre sa langue ?

L’idéal serait de parler à notre processeur en français, en anglais,
etc. Mais disons-le clairement : notre technologie n’est pas suffisamment
évoluée, et nous avons dû trouver autre chose. La solution retenue a été
de créer des langages de programmation plus évolués que le langage machine,
plus faciles à apprendre, et de fournir le traducteur qui va avec. Il s'agit
de langages assez simplifiés, souvent proches des langages naturels, et
dans lesquels on peut écrire nos programmes beaucoup plus simplement qu’en
utilisant le langage machine. Grâce à eux, on peut écrire nos programmes
sous forme de texte, sans avoir à se débrouiller avec des suites de zéro
et de un totalement incompréhensibles. Il existe de nombreux langages de
programmation, et le C est un de ces langages.

Reste que notre processeur ne comprend pas ces langages évolués et
n'en connaît qu’un seul : le sien. Aussi, pour utiliser un langage de
programmation, il faut disposer d'un traducteur qui fera le lien entre celui-ci
et le langage machine du processeur. Autrement dit, le rôle du traducteur
est de transformer un texte écrit dans un langage de programmation évolué
en une suite de zéro et de un que le processeur peut comprendre. Il ne vous
est ainsi plus nécessaire de connaître la langue de votre processeur. En
informatique, ce traducteur est appelé un **compilateur**.

Pour illustrer notre propos, voici un code écrit en C (que nous apprendrons
à connaître) :

```c
#include <stdio.h>

int main(void)
{
    printf("Salut !\n");
    return 0;
}
```

Et le même en langage machine (plus précisémment pour un processeur de
la famille x86-64) :

```text
01010101 01001000 10001001 11100101 10111111 00100100
00101100 01001000 00000000 10111000 00000000 00000000
00000000 00000000 11101000 10011101 00001011 00000000
00000000 10111000 00000000 00000000 00000000 00000000
01011101 01010011 01100001 01101100 01110101 01110100
00100000 00100001 00001010 00000000
```

Nous y gagnons tout de même au change, non ?