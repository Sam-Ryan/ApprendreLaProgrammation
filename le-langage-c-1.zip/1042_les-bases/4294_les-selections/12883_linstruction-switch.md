L'instruction ```switch``` permet de comparer la valeur d'une variable par rapport à une liste de valeurs. Techniquement, elle permet d'écrire de manière plus consise une suite d'instructions `if` et `else if` qui auraient pour objectif d'accomplir différents actions suivant la valeur d'une variable.

```c
if (a == 1)
{
    /* Instructions */
}
else if (a == 2)
{
    /* Instructions */
}
/* Etc. */
else
{
    /* Instructions */
}
```

Avec l'instruction `switch`, cela donne :

```c
switch (a)
{
case 1:
    /* Instructions */
    break;
case 2:
    /* Instructions */
    break;

/* Etc... */

default: /* Si aucune comparaison n'est juste */
    /* Instruction(s) à exécuter dans ce cas */
    break;
}
```

Ici, la valeur de la variable *a* est comparée successivement avec chaque entrée de la liste, indiquées par le mot-clé `case`. En cas de correspondance, les instructions suivant le mot-clé `case` sont exécutées jusqu'à rencontré une instruction `break` (nous la verrons plus en détail un peu plus tard). Si aucune comparaison n'est bonne, alors ce sont les instructions de l'entrée marquée avec le mot-clé `default` qui seront exécutées. 

# Exemple

```c
#include <stdio.h>


int main(void)
{
    int note;

    printf("Quelle note as-tu obtenue ? ");
    scanf("%d", &note);

    switch(note)
    {
    /* si note == 0 */
    case 0:
        printf("No comment.\n");
        break;

    /* si note == 1 */
    case 1:
        printf("Cela te fait 4/20, c'est accablant.\n");
        break;

    /* si note == 2 */   
    case 2:
        printf("On se rapproche de la moyenne, mais ce n'est pas encore ça.\n");
        break;

    /* si note == 3 */
    case 3:
        printf("Tu passes.\n");
        break;

    /* si note == 4*/
    case 4:
        printf("Bon travail, continue ainsi !\n");
        break;

    /* si note == 5 */
    case 5:
        printf("Excellent !\n");
        break;

    /* si note est différente de 0, 1, 2, 3, 4 et 5 */
    default:
        printf("Euh... tu possedes une note improbable...\n");
        break;
    }

    return 0;
}
```

Comme dit précédemment, si la condition est vraie, le ```switch``` exécute toutes les instructions jusqu'au prochain ```break```. Cela permet de réaliser des combinaisons comme celle-ci : 

```c
int main(void)
{
    int note;

    printf("Quelle note as-tu obtenue ? ");
    scanf("%d", &note);

    switch(note)
    {
    /* Si la note est comprise entre 0 et 4 inclus */
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
        printf("Tu n'as pas la moyenne.\n");
        break;

    /* Si au contraire la note est égale ou supérieure à 5 */
    case 5:
    case 6:
    case 7:
    case 8:
    case 9:
    case 10:
        printf("Tu as la moyenne.\n");
        break;

    default:
        printf("Erreur : note impossible\n");
        break;
    }

    return 0;
}
```

[[information]]
| Notez que comme pour l'instruction `else`, une entrée marquée avec le mot-clé `default` n'est pas obligatoire.