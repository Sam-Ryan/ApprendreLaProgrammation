Comme dit au chapitre précédent, les structures de contrôle permettent de modifier le comportement d'un programme suivant la réalisation de différentes conditions. Parmis ces structures de contrôle se trouvent les instructions de sélections (ou sélections en abrégés) qui vont retenir notre attention dans ce chapitre.

Le tableau ci-dessous reprends celles dont dispose le langage C.

Structure de contrôle  | Action
------------- | -------------
***if...***  | exécute une suite d'instructions si une condition est respectée.
***if...else...***  | exécute une suite d'instructions si une condition est respectée ou exécute une autre suite d'instructions si elle ne l'est pas.
***switch...***  | exécute une suite d'instructions différente suivant la valeur testée.