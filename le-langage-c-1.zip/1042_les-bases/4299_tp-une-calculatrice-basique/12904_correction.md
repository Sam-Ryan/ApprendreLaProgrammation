Alors ? Pas trop secoué ? :D  
Bien, voyons à présent la correction.

```c
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

unsigned long pgcd(unsigned long, unsigned long);
unsigned long ppcd(unsigned long, unsigned long);
unsigned long factorielle(unsigned long);


unsigned long pgcd(unsigned long a, unsigned long b)
{
    unsigned long r = a % b;

    while (r != 0)
    {
            a = b;
            b = r;
            r = a % b;
    }

    return b;
}


unsigned long ppcd(unsigned long a, unsigned long b)
{
    unsigned long i;
    unsigned long min = (a < b) ? a : b;

    for (i = 2; i <= min; ++i)
        if (a % i == 0 && b % i == 0)
            return i;

    return 0;
}


unsigned long factorielle(unsigned long a)
{
    unsigned long i;
    unsigned long r = 1;

    for (i = 2; i <= a; ++i)
        r *= i;

    return r;
}


int
main(void)
{
    double a;
    double b;
    double res = 0;
    int n;
    char op;
    
    while (1)
    {
        printf("> ");
        n = scanf("%lf %lf %c", &a, &b, &op);

        if (n <= 1)
        {
            scanf("%c", &op);
            b = a;
            a = res;
        }
        if (op == 'q')
            break;

        switch (op)
        {
        case '+':
            res = a + b;
            break;

        case '-':
            res = a - b;
            break;

        case '*':
            res = a * b;
            break;

        case '/':
            res = a / b;
            break;

        case '%':
            res = (unsigned long)a % (unsigned long)b;
            break;

        case '^':
            res = pow(a, b);
            break;

        case '!':
            res = factorielle((n == 0) ? a : b);
            break;

        case 'g':
            res = pgcd(a, b);
            break;

        case 'p':
            res = ppcd(a, b);
            break;
        }

        printf("%lf\n", res);
    }
    return 0;
}
```

Commençons par la fonction *main*(). Nous définissons plusieurs variables :

* *a* et *b*, qui représentent les éventuels opérandes fournis ;
* *res*, qui correspond au résultat de la dernière opération réalisée (ou zéro s'il n'y en a pas encore eu) ;
* *n*, qui est utilisée pour retenir le retour de la fonction *scanf*() ; et
* *op*, qui retient l'opération demandée.

Ensuite, nous entrons dans une boucle infinie (la condition étant toujours vraie puisque valant 1) où nous demandons à l'utilisateur d'entrer l'opération à réaliser et les éventuels opérandes. Après avoir vérifié si la fonction *scanf*() n'a pas rencontré d'erreur (auquel cas elle retourne une valeur négative), nous vérifions si une seule opérande est fournie ou aucune (ce qui ce déduit, respectivement, d'un retour de la fonction *scanf*() valant 1 ou 0). Si c'est le cas, nous appelons une seconde fois *scanf*() pour récupérer l'opérateur. Puis, la valeur de *a* est attribuée à *b* et la valeur de *res* à *a*.

Si l'opérateur utilisé est `q`, alors nous quittons la boucle et par la même occasion le programme. Notez que nous n'avons pas pu effectuer cette vérification dans le corps de l'instruction `switch` qui suit puisque l'instruction `break` nous aurait fait quitter celui-ci et non la boucle.

Enfin, nous réalisons l'opération demandée au sein de l'instruction `switch`, nous stockons le résultat dans la variable *res* et l'affichons. Remarquez que l'utilisation de conversions explicites n'a été nécessaire que pour le calcul du reste de la division entière. En effet, dans les autres cas (par exemple lors de l'affectation à la variable *res*), il y a conversions implicites.

[[information]]
| Nous avons utilisé le type `unsigned long` lors des calculs nécessitant des nombres entiers afin de disposer de la plus grande capacité possible et parce que l'usage de nombres négatifs n'a pas beaucoup d'intérêt dans ce cadre. Cependant, l'usage de nombres non signés n'est obligatoire que pour la fonction factorielle (puisque celle-ci n'opère que sur des nombres strictement positifs).