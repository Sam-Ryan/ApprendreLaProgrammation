Alors, cela s'est bien passé ? Si oui, félicitations, si non, la correction devrait vous aider à y voir plus clair. ;)

```c
#include <stdio.h>


int
main(void)
{
    unsigned jour;
    unsigned mois;
    unsigned an;
    int njours;

    printf("Entrez une date (jj/mm/aaaa) : ");
    scanf("%u/%u/%u", &jour, &mois, &an);
    njours = (an - 1) * 365;

    if (an > 1582)
    {
        njours += ((an - 1) / 4);
        njours -= ((an - 1) / 100);
        njours += ((an - 1) / 400);
        njours += 2;
    }
    else
        njours += ((an - 1) / 4);

    njours += (mois - 1) * 31;

    if (mois >= 3)
    {
        if (an > 1582)
        {
            if (an % 4 == 0 && (an % 100 != 0 || an % 400 == 0))
                njours -= 2;
            else
                njours -= 3;
        }
        else
        {
            if (an % 4 == 0)
                njours -= 2;
            else
                njours -= 3;
        }

        switch (mois)
        {
        case 5:
        case 6:
            njours -= 1;
            break;

        case 7:
        case 8:
        case 9:
            njours -= 2;
            break;

        case 10:
        case 11:
            njours -= 3;
            break;

        case 12:
            njours -= 4;
            break;
        }
    }

    njours += (jour - 1);

    switch (njours % 7)
    {
    case 0:
        printf("C'est un samedi\n");
        break;

    case 1:
        printf("C'est un dimanche\n");
        break;

    case 2:
        printf("C'est un lundi\n");
        break;

    case 3:
        printf("C'est un mardi\n");
        break;

    case 4:
        printf("C'est un mercredi\n");
        break;

    case 5:
        printf("C'est un jeudi\n");
        break;

    case 6:
        printf("C'est un vendredi\n");
        break;
    }
    
    return 0;
}
```

Tout d'abord, nous demandons à l'utilisateur d'entrer une date au format jj/mm/aaaa et nous attribuons chaque partie aux variables *jour*, *mois* et *an*. Ensuite, nous multiplions par 365 la différence d'années séparant l'année fournie de l'an 1. Toutefois, il nous faut encore prendre en compte les années bissextiles pour que le nombre de jours obtenus soit correct. Nous ajoutons donc un jour par année bissextile en prenant soin d'appliquer les règles du calendrier en vigueur à la date fournie.

Maintenant, il nous faut ajouter le nombre de jours séparant le mois de janvier du mois spécifié par l'utilisateur. Pour ce faire, nous considérons dans un premier temps que tous les mois sont composés de trente et un jours et multiplions donc la différence de mois par trente et un. Une fois ceci fait, nous devons soustraire au nombre obtenu les jours que nous avons compter en trop (puisque tous les mois ne sont pas composés de trente et un jours). Cet ajustement n'est nécessaire que si le mois entré n'est ni janvier ni février puisque dans ce cas le calcul est correct. Suivant le mois fourni par l'utilisateur, nous retranchons deux ou trois jours pour le mois de février (suivant qu'il s'agit d'une année bissextile ou non) et un jour pour les mois d'avril, juin, septembre et novembre.

À présent, il ne nous reste plus qu'à ajouter le nombre de jours séparant le jour entré du premier du mois et à appliquer le modulo au résultat obtenu pour déterminer le jour de la semaine.