# Objectif

Votre objectif est de parvenir à réaliser un programme qui, suivant une date fournie par l'utilisateur sous la forme « jj/mm/aaaa », donne le jour de la semaine correspondant. Autrement dit, voici ce que devrais donner l'exécution de ce programme :

```text
Entrez une date : 11/2/2015
C'est un mercredi

Entrez une date : 13/7/1970
C'est un lundi
```

# Déterminer le jour de la semaine

Pour déterminer le jour de la semaine correspondant à une date, vous allez devoir partir du premier janvier de l'an 1 (c'était un samedi) et calculer le nombre de jours qui sépare cette date de celle fournie par l'utilisateur. Une fois ce nombre obtenu, il nous est possible d'obtenir le jour de la semaine à l'aide de l'opérateur modulo.

En effet, comme vous le savez, les jours de la semaine suivent un cycle et se répètent tous les sept jours. Or, le reste de la division entière est justement un nombre cyclique allant de zéro jusqu'au diviseur diminué de un. Voici ce que donne le reste de la division entière des chiffres 1 à 9 par 3 :

```text
1 % 3 = 1
2 % 3 = 2
3 % 3 = 0
4 % 3 = 1
5 % 3 = 2
6 % 3 = 0
7 % 3 = 1
8 % 3 = 2
9 % 3 = 0
```

Comme vous le voyez, le reste de la division oscille toujours entre zéro et deux. Ainsi, si nous attribuons un chiffre de zéro à six à chaque jour de la semaine (par exemple zéro pour samedi et ainsi de suite pour les autres) nous pouvons déduire le jour de la semaine correspondant à un nombre de jours depuis le premier janvier de l'an 1.

Prenons un exemple : l'utilisateur entre la date du premier mars de l'an 1. Il y a cinquante-neuf jours qui le sépare du premier janvier (trente et un pour le mois de janvier et vingt-huit pour le mois de février). Le reste de la division entière de 59 par 7 est 3, il s'agit donc d'un mardi.

# Les calendriers Julien et Grégorien

Toutefois, il y a un petit bémol : les [années bissextiles](http://fr.wikipedia.org/wiki/Ann%C3%A9e_bissextile). Vous le savez certainement : une année bissextile est une année qui comporte 366 jours au lieu de 365 et qui se voit ainsi ajouté un vingt-neuf février. Ce que vous ne savez en revanche peut-être pas, c'est que la détermination des années bissextile a varié au court du temps.

Jusqu'en 1582, date d'adoption du [calendrier Grégorien](http://fr.wikipedia.org/wiki/Calendrier_gr%C3%A9gorien) (celui qui est en vigueur un peu près partout actuellement), c'est le [calendrier Julien](http://fr.wikipedia.org/wiki/Calendrier_julien) qui était en application. Ce dernier considérait une année comme bissextile si celle-ci était multiple de quatre. Cette méthode serait correcte si une année comportait 365,25 jours. Cependant, il s'est avéré plus tard qu'une année comportait en fait 365,2422 jours.

Dès lors, un décalage par rapport au cycle terrestre s'était lentement installé ce qui posa problème à l'Église catholique pour le calcul de la date de Pâques qui glissait doucement vers l'été. Le calendrier Grégorien fût alors instauré en 1582 pour corriger cet écart en modifiant la règle de calcul des années bissextile : il s'agit d'une année multiple de quatre *et*, s'il s'agit d'une année multiple de 100, également multiple de 400. Par exemple, les années 1000 et 1100 ne sont plus bissextiles à l'inverse de l'année 1200 qui, elle, est divisible par 400.

Toutefois, ce ne sont pas douze années bissextiles qui ont été supprimées lors de l'adoption du calendrier Grégorien (100, 200, 300, 500, 600, 700, 900, 1000, 1100, 1300, 1400, 1500), mais seulement dix afin de rapprocher la date de l'équinoxe de printemps du 21 mars.

# Mode de calcul

Pour réaliser votre programme, vous devrez donc vérifier si la date demandée est antérieure ou postérieure à l'an 1582. Si elle est inférieure ou égale à l'an 1582, alors vous devrez appliquer le calendrier Julien. Si elle est supérieure, vous devrez utiliser le calendrier Grégorien.

Pour vous aider, voici un schéma que vous pouvez suivre :

```text
Si l'année est supérieure à 1582
    Multipler la différence d'années par 365
    Ajouter au résultat le nombre d'années multiples de 4
    Soustraire à cette valeur le nombre d'années multiples de 100
    Ajouter au résultat le nombre d'années multiples de 400
    Ajouter deux à ce nombre (du fait que seules dix années ont été supprimées en 1582)
Si l'année est inférieure ou égale à 1582
    Multipler la différence d'années par 365
    Ajouter au résultat le nombre d'années multiples de 4

Au nombre de jours obtenus, ajouter la différence de jours entre
le mois de janvier et le mois fourni. N'oubliez pas que les mois comportent
trente et un ou trente jours et que le mois de février comporte pour sa
part vingt-huit jours sauf les années bisextiles où il s'en voit ajouter un
vingt-neuvième. Également, faites attention au calendrier en application pour
la détermination des années bissextiles !

Au résultat obtenu ajouter le nombre de jour qui sépare celui entré du premier
du mois.

Appliquer le modulo et déterminer le jour de la semaine.
```

À vous de jouer ! :)