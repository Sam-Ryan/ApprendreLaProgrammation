Nous avons déjà recontré l'instruction ```break``` lors de la présentation de l'instruction ```switch```, cette dernière permettait de quitter le bloc d'un ```switch``` pour reprendre immédiatement après. Cependant, l'instruction `break` peut également être utilisée au sein d'une boucle pour stopper son exécution (autrement dit pour effectuer un saut au-delà du bloc à répéter).

# Exemple

Le plus souvent, une instruction `break` est employée pour sortir d'une itération lorsqu'une condition (différente de celle contrôlant l'exécution de la boucle) est remplie. Par exemple, si nous souhaitons réaliser un programme qui détermine le plus petit diviseur commun de deux nombres, nous pouvons utiliser cette instruction comme suit :

```c
#include <stdio.h>


int main(void)
{
    int a;
    int b;
    int i;
    int min;

    printf("Entrez deux nombres : ");
    scanf("%d %d", &a, &b);
    min = (a < b) ? a : b;

    for (i = 2; i <= min; ++i)
    {
        if (a % i == 0 && b % i == 0)
        {
            printf("le plus petit diviseur de %d et %d est %d\n", a, b, i);
            break;
        }
    }

    return 0;
}
```

```text
Entrez deux nombres : 112 567
le plus petit diviseur de 112 et 567 est 7

Entrez deux nombres : 13 17
```

Comme vous le voyez, la condition principale permet de progresser parmis les diviseurs possibles alors que la seconde détermine si la valeur courante de *i* est un diviseur commun. Si c'est le cas, l'exécution de la boucle est stoppée et le résultat affiché. Dans le cas où il n'y a aucun diviseur commun, la boucle s'arrête lorsque le plus petit des deux nombres est atteint.