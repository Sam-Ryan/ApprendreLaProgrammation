Nous venons de voir qu'il était possible de réaliser des sauts à l'aide des instructions `break` et `continue`. Cependant, d'une part ces instructions sont confinées à une boucle ou à une instruction `switch` et, d'autre part, la destination du saut nous est imposée (la condition avec `continue`, la fin du bloc d'instructions avec `break`).

L'instruction `goto` permet de sauter à un point précis du programme que nous aurons déterminé à l'avance. Pour ce faire, le langage C nous permet de marquer des instructions à l'aide d'étiquettes (*labels* en anglais). Une étiquette n'est rien d'autre qu'un nom choisis par nos soins suivi du catactère `:`. Généralement, par soucis de lisibilité, les étiquettes sont placées en retrait des instructions qu'elles désignent.

# Exemple

Reprenons (encore) l'exemple du calcul du plus petit commun diviseur. Ce dernier aurait pu être écris comme suit à l'aide d'une instruction `goto` :

```c
#include <stdio.h>


int main(void)
{
    int a;
    int b;
    int i;
    int min;

    printf("Entrez deux nombres : ");
    scanf("%d %d", &a, &b);
    min = (a < b) ? a : b;

    for (i = 2; i <= min; ++i)
    {
        if (a % i == 0 && b % i == 0)
        {
            goto trouve;
        }
    }

    return 0;
trouve:
    printf("le plus petit diviseur de %d et %d est %d\n", a, b, i);
    return 0;
}
```

Comme vous le voyez, l'appel à la fonction *printf*() a été marqué avec une étiquette nommée *trouve*. Celle-ci est utilisée avec l'instruction `goto` pour spécifier que c'est à cet endroit que nous souhaitons nous rendre si un diviseur commun est trouvé. Vous remarquerez également que nous avons désormais deux instructions `return`, la première étant executée dans le cas où aucun diviseur commun n'est trouvé.

# Le dessous des boucles

Maintenant que vous savez cela, vous devriez être capable de réecrire n'importe quelle boucle à l'aide de cette instruction. En effet, une boucle ne consiste jamais qu'en deux sauts : un vers une condition et l'autre vers l'instruction qui suit le corps de la boucle. Ainsi, ce code :

```c
#include <stdio.h>


int main(void)
{
    int i = 0;

    while (i < 5)
    {
        printf("La variable i vaut %d\n", i);
        i++;
    }

    return 0;
}
```

Peut parfaitement s'écrire :

```c
#include <stdio.h>


int main(void)
{
    int i = 0;


condition:
    if (i < 5)
    {
        printf("La variable i vaut %d\n", i);
        i++;
        goto condition;
    }

    return 0;
}
```

# Goto Hell ?

Bien qu'utile dans certaines circonstances, sachez que l'instruction `goto` est fortement décriée, principalement pour deux raisons :

* mise à part dans des cas spécifiques, il est possible de réaliser la même action de manière plus claire à l'aide de structures de contrôles ;
* l'utilisation de cette instruction peut amener votre code à être plus difficilement lisible et, dans les pire cas, en faire un [code spaghetti](http://fr.wikipedia.org/wiki/Programmation_spaghetti).

À vrai dire, elle est aujourd'hui surtout utilisée dans le cas de la gestion d'erreur, ce que nous verrons plus tard dans ce cours. Aussi, en entendant, nous vous conseillons d'éviter son utilisation.