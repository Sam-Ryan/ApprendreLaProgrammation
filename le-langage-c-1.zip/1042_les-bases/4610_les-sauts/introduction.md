Dans les chapitres précédents, nous avons vu comment modifier l’exécution de notre programme en fonction du résultat d'une ou plusieurs conditions. Ainsi, nous avons pu réaliser des tâches plus complexes que de simplement exécuter une suite d'instruction de manière linéaire.

Cette exécution non linéaire est possible grâce à ce que l'on appel des **sauts**. Un saut correspond au passage d'un point à un autre d'un programme. Bien que cela vous ait été caché, sachez que vous en avez déjà rencontré ! En effet, une instruction `if` réalise par exemple un saut à votre insu :

```c
if (/* condition */)
{
    /* bloc */
}

/* suite du programme */
```

Dans le cas où la condition est fausse, l'exécution du programme passe le bloc de l'instruction `if` et exécute ce qui suit. Autrement dit, il y a un **saut** jusqu'à la suite du bloc.

Dans la même veine, une boucle `while` réalise également des sauts :

```c
while (/* condition */)
{
    /* bloc à répéter */
}

/* suite du programme */
```

Dans cet exemple, si la condition est vraie, le bloc qui suit est exécuté puis il y a un saut pour revenir à l'évaluation de la condition. Si en revanche elle est fausse, comme pour l'instruction `if`, il y a un saut au-delà du bloc d'instructions.

Tous ces sauts sont cependant automatiques et vous sont cachés. Dans ce chapitre, nous allons voir comment réaliser manuellement des sauts à l'aide de trois instructions : `break`, `continue` et `goto`.