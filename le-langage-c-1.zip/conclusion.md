Ainsi s’achève ce cours, mais pas votre parcours dans le monde de la programmation ! En effet, même si vous avez appris certaines choses, vous ne connaissez pas tout : le C est un langage fabuleux qui réserve bien des surprises. Pour continuer votre apprentissage, voici quelques derniers conseils :

* **Soyez curieux** : fouillez sur Internet pour découvrir de nouvelles méthodes, approfondissez celles que vous connaissez, renseignez-vous, testez de nouveaux outils, etc.
* **Entrainez-vous** : c’est le meilleur moyen de progresser. Faites des projets qui vous tiennent à cœur, mettez en œuvre des algorithmes connus, réalisez des exercices, etc.
* **Lisez des codes produits par d’autres personnes** : découvrez comment elles procèdent, apprenez d’elles de nouvelles techniques ou façons de faire et progressez en suivant leurs conseils. Vous pouvez par exemple commencer en visitant les forums de ce site.
* Enfin, le plus important : **amusez-vous** !  ;)