Jusqu'à présent, vous avez appris à écrire du texte, manipuler des nombres et interagir un tout petit peu avec l'utilisateur. En gros, pour le moment, un programme est quelque chose de sacrément simple et linéaire : il ne permet que d'exécuter des instructions dans un ordre donné. Techniquement, une simple calculatrice peut en faire autant (voire plus). Cependant et heureusement, les langages de programmation actuels fournissent des moyens permettant de réaliser des tâches plus évoluées.

Pour ce faire, diverses **structures de contrôle** ont été inventées. Ces structures de contrôle permettent de modifier le comportement du programme suivant la valeur de différentes conditions. Ainsi, si une condition est vraie, alors le programme se comportera d'une telle façon, si elle est fausse, le programme fera telle ou telle chose, etc.

Et cela demande de savoir faire des comparaisons ou de tester si une condition est vraie ou fausse. Pour cela, il a fallu rajouter deux types d'opérateurs :

- des **opérateurs de comparaison**, qui comparent deux nombres ;
- des **opérateurs logiques**, qui permettent de combiner plusieurs conditions.