Les écritures vues au-dessus peuvent parfois être simplifiées. Le langage C fournit quelques raccourcis d'écriture assez efficaces.

# Les Expressions combinées

Comment vous y prendriez-vous pour multiplier une variable par trois ?  La solution qui devrait vous venir à l'esprit serait d'affecter à la variable son ancienne valeur multipliée par trois. Autrement dit :

```c
variable = variable * 3;
```

Ce qui est parfaitement correct. Cependant, cela implique de devoir écrire deux fois le nom de la variable, ce qui est quelques peu pénible et source d'erreur. Aussi, il existe des opérateurs combinés qui réalise une affectation et une opération en même temps. Les voici :

Opérateur combiné | Équivalent à
----------------- | ------------
variable += nombre | variable = variable + nombre
variable -= nombre | variable = variable - nombre
variable *= nombre | variable = variable * nombre
variable /= nombre | variable = variable / nombre
variable %= nombre | variable = variable % nombre

Ainsi, pour faire une multiplication par trois, on peut raccourcir ainsi :

```c
variable *= 3;
```

Ce code concis marche exactement comme le précédent.

```c
int variable = 3;

variable *= 3;
printf(%d\n", variable);
```

```text
9
```

# Incrémentation et décrémentation

**L'incrémentation** et la **décrémentation** sont deux opérations qui, respectivement, ajoute ou enlève 1 à une variable. Avec les opérateurs vu précédemment, cela se traduit par :

```c
variable += 1;
variable -= 1;
```

Cependant, on a inventé de nouveaux raccourcis pour ces deux opérations, car elles sont très utilisées (vous comprendrez vite pourquoi dans les prochains chapitres). Ces deux raccourcis sont les suivants : 

```c
++variable;
--variable;
```

Le premier opérateur sert pour l'**incrémentation** (ajouter 1), et la seconde pour la **décrémentation** (on enlève 1).

Ce que je viens de vous montrer s’appelle l’[in/dé]crémentation **préfixée**. En effet, il est aussi possible de faire une [in/dé]crémentation **post-fixée** : le signe est alors avant la variable et non après : 

```c
variable++;
variable--;
```

Il y a une subtile différence entre les deux formes. Une [in/dé]crémentation pré-fixée change la valeur de l’expression avant d'envoyer la valeur, alors qu’une [in/dé]crémentation post-fixée renvoie la valeur et la modifie ensuite. Petit exemple pour bien comprendre : si j'ai une variable a qui vaut 5, ```++a``` incrémentera immédiatement la variable a, qui vaudra alors 6. 

```c
int a = 5 ;
int b = ++a ; /* ici, b vaudra 6 */
```

Par contre, ```a++``` attendra avant d'incrémenter la variable : celle-ci sera incrémentée après la prochaine "utilisation". 

```c
int a = 5 ;
int b = a++ ; /* ici, b vaudra 5, et a sera mit à 6 une fois que 
               la valeur de a++ est recopiée dans b */
```


```c
#include <stdio.h>


int main(void)
{
    int a = 10;
    int b = 10;

    printf("a++ = %d\n", a++);
    printf("a-- = %d\n", a--);
    printf("++b = %d\n", ++b);
    printf("--b = %d\n", --b);
    printf("a = %d\n", a);
    printf("b = %d\n", b);
    return 0;
}
```

```text
a++ = 10
a-- = 11
++b = 11
--b = 10
a = 10
b = 10
```

Fondamentalement, utiliser l’une ou l’autre des deux formes ne change pas grand chose, sauf dans quelques cas particuliers. Dans la plupart des cas, les programmeurs utilisent la forme postfixée (```i++```) en permanence. Il n'y a pas vraiment de raisons valables pour faire cela à l'heure actuelle, mais cette pratique est monnaie courante. Aussi, ne soyez pas étonné de voir des codes utilisant la forme post-fixée alors qu'une forme préfixée aurait été plus adéquate.