Comme lorsque nous les utilisons comme argument de *printf*(), il est possible d'affecter le résultat d'une expression à une variable.

```c
#include <stdio.h>


int main(void)
{
    int somme = 5 + 3;

    printf("5 + 3 = %d\n", somme);
    return 0;
}
```

```text
5 + 3 = 8
```

Mais ce n'est pas tout ! Au lieu d'utiliser des nombres pour composer nos expressions, nous pouvons parfaitement utiliser des variables (c'est là tout leur intérêt d'ailleurs).

```c
int a = 5;
int b = 3;
int somme = a + b;

printf("%d + %d = %d\n", a, b, somme);
```

```text
5 + 3 = 8
```

Et bien sûr de combiner les deux méthodes :

```c
int a = 5;
int b = 65;

printf("%d\n", b / a * 2 + 7 % 2);
```

```text
27
```

# La priorité des opérateurs

Cependant, faites attention à la priorité des opérateurs ! Comme en mathématiques, certains opérateurs passent avant d’autres : ```* / %``` ont une priorité supérieure à ```+ -```.

Dans ce code : 

```c
a = b + c * 4;
```

C’est ```c * 4``` qui sera exécuté d’abord, puis ```b``` sera ajouté au résultat. Faites donc attention, sous peine d’avoir de mauvaises surprises. Dans le doute, ajoutez des parenthèses.

# Les opérateurs combinés

À présent, comment vous y prendriez-vous pour multiplier une variable par trois ? La solution qui devrait vous venir à l'esprit serait d'affecter à la variable son ancienne valeur multipliée par trois. Autrement dit :

```c
int variable = 3;

variable = variable * 3;
printf("variable * 3 = %d\n", variable);
```

```text
variable * 3 = 9
```

Ce qui est parfaitement correct. Cependant, cela implique de devoir écrire deux fois le nom de la variable, ce qui est quelques peu pénible et source d'erreur. Aussi, il existe des opérateurs combinés qui réalise une affectation et une opération en même temps. Les voici :

Opérateur combiné | Équivalent à
----------------- | ------------
variable += nombre | variable = variable + nombre
variable -= nombre | variable = variable - nombre
variable *= nombre | variable = variable * nombre
variable /= nombre | variable = variable / nombre
variable %= nombre | variable = variable % nombre

Avec le code précédent, cela donne donc :

```c
int variable = 3;

variable *= 3;
printf("variable * 3 = %d\n", variable);
```

```text
variable * 3 = 9
```

# L'incrémentation et la décrémentation

**L'incrémentation** et la **décrémentation** sont deux opérations qui, respectivement, ajoute ou enlève 1 à une variable. Avec les opérateurs vu précédemment, cela se traduit par :

```c
variable += 1;
variable -= 1;
```

Cependant, ces deux opérations étant très souvent utilisée, elles ont droit chacune à un opérateur spécifique (en fait, deux) :

```c
/* Incrémentation */
variable++;
++variable;
```

```c
/* Décrémentation */
variable--;
--variable;
```

Le résultat des deux paires d'opérateurs est le même : la variable *variable* est incrémentée ou décrémentée, à une différence près : le résultat de l'opération. Dans le premier cas (opérateur dit suffixé) ce sera la valeur de la variable et dans l'autre (opérateur préfixé) ce sera la valeur de la variable augmentée ou diminuée de un. Illustration :

```c
#include <stdio.h>


int main(void)
{
    int a = 10;
    int b = 10;

    printf("a++ = %d\n", a++);
    printf("a-- = %d\n", a--);
    printf("++b = %d\n", ++b);
    printf("--b = %d\n", --b);
    printf("a = %d\n", a);
    printf("b = %d\n", b);
    return 0;
}
```

```text
a++ = 10
a-- = 11
++b = 11
--b = 10
a = 10
b = 10
```