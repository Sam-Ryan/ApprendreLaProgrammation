Le langage C fournit 5 opérations de base sur nos variables.
     
* L'addition **+**.       
* La soustraction **-**.       
* La multiplication *****.       
* La division **/**.        
* Le modulo **%** (le reste d’une division euclidienne).

[[information]]
| Le langage C fournit bien entendu d’autres fonctions mathématiques et d'autres opérateurs, mais il est encore trop tôt pour vous les présenter.

# Généralités

Pour utiliser ces calculs, il suffit d’assigner le résultat du calcul à une variable. Ces opérations peuvent se faire aussi bien sur des constantes que sur des variables.

Avec des constantes :

```c
int somme, difference, produit;

somme = 2 + 3 ;   /* 5 */
difference = 8 - 12 ;   /* -4 */
produit = 6 * 7 ;   /* 42 */
```

Avec des variables :

```c
var = var1 + var2;
d = c / b * a;
```

Avec variables et constantes :

```c
d = c / b * a - s + 7 % 2
```

## Priorité des opérateurs

Cependant, il faut faire attention à la priorité des opérateurs : comme en mathématiques, certains opérateurs passent avant d’autres : ```* / %``` ont une priorité supérieure à ```+ -```.

Dans ce code : 

```c
x = nombre + y * 4;
```

C’est ```y * 4``` qui sera exécuté d’abord, puis on ajoutera ```nombre``` au résultat. Faites donc attention, sous peine d’avoir de mauvaises surprises. Dans le doute, mettez des parenthèses.

# Division

La division en informatique est différente de celle en mathématiques. Si je vous dis $\frac{15}{4}$, vous en déduisez que le quotient est 3,75. Pourtant, le résultat de celle-ci est 3 en langage C.

```c
printf("15 / 4 = %d\n", 15 / 4);
```

```text
15 / 4 = 3
```

Pour l’ordinateur, le résultat de ```15 / 4``` est bien ```3```. Pourquoi ? Parce qu’on lui a demandé de faire une division d’entiers (appelée **division euclidienne**), donc il répond par des entiers. Si l’on veut afficher le résultat complet (à nos yeux), il faut l’indiquer à l’ordinateur. Comment faire ? Essayez de trouver la solution tout seul.

Un indice ? Pensez aux flottants.

La solution :

```c
printf("15 / 4 = %f\n", 15. / 4.);   /* même si pour nous, c’est la même chose que 15 / 4 */
```

```text
15 / 4 = 3.750000
```

Même si pour nous c’est intuitif, pour l’ordinateur il faut bien préciser si ce sont des entiers ou des flottants.

# Modulo

Le modulo est un peu le complément de la division puisqu’il permet de connaitre le reste d’une division euclidienne. C’est une opération de base aux yeux de l’ordinateur, même si elle est assez peu connue. Un petit code pour la route :

```c
printf("11 % 4 = %d\n", 11 % 4);
```

```text
11 % 4 = 3
```

Ici, le résultat de cette instruction est 3, car $11 = 2 \times 4 + 3$. Le modulo est la réponse au problème de la division d’entiers.