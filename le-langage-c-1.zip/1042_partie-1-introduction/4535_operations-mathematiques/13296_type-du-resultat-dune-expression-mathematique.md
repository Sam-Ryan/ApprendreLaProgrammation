On pourrait multiplier les exemples à l’infini, je pense néanmoins que vous avez compris comment utiliser les opérations usuelles dans un code source. Par contre, il est intéressant de montrer des exemples avec printf.

```c
#include <stdio.h>


int main(void)
{
    printf("%d\n", 2 + 3);
    printf("%d\n", 8 - 12);
    printf("%d\n", 6 * 7);
    return 0;
}
```

```text
5
-4
42
```
Vous remarquerez que nous utilisons directement une expression (`2 + 3` par exem
ple) comme argument à la place d'une variable. Rien de bien surprenant me direz-vous... À un détail près : pourquoi l'indicateur de format est `d` ? Cela veut-il dire que le type de cette expression est `int` ?

*Hé* bien, oui. Tout comme les variables, les expressions ont un type. Ce dernier dépend toutefois du type des éléments qui la compose. En l'occurrence, une constante entière comme `2` ou `3` est par défaut de type `int`. Le résultat d'une somme, par exemple, sera donc également de type `int`. Les constantes flottantes comme `5.` ou `78.0` sont, elles, de type `double` et le résultat d'une opération sera alors de type `double`.

[[question]]
| D'accord, mais si j'additionne un `int` avec un `double`, cela me donne quoi ?

Heureusement pour nous, la norme a prévu ces différents cas et à fixer des règles :

* si une opérande est de type `long double`, le résultat est de type `long double` ; si non
* si une opérande est de type `double`, le résultat est de type `double` ; si non
* si une opérande est de type `float`, le résultat est de type `float` ; si non
* si une opérande est de type `unsigned long`, le résultat est de type `unsigned long`; si non
* si une opérande est de type `long`, le résultat est de type `long`; si non
* si une opérande est de type `unsigned int`, le résultat est de type `unsigned int`; si non
* le résultat est de type `int`.

[[question]]
| *Heu*... D'accord, mais vous venez de dire que les constantes entières étaient de type `int` et que les constantes flottantes étaient de type `double`. Du coup, je fais comment pour obtenir une constante d'un autre type ?

À l'aide d'un suffixe. Celui-ci se place à la fin de la constante et permet de modifier son type. En voici la liste :

Type | Suffixe
---- | -------
u ou U | **unsigned**
l ou L | **long**
f ou F | **float**
l ou L | **long double**

[[information]]
| Notez que les suffixes `L` (ou `l`) et `U` (ou `u`) peuvent être combinés.

Allez, un petit récapitulatif :

```c
#include <stdio.h>


int main(void)
{
    printf("78.56 + 5 = %Lf\n", 78.56L + 5);
    printf("5678 + 2.2 = %f\n", 5678L + 2.2);
    printf("2 + 5 = %lu\n", 2L + 5UL);
    return 0;
}
```

```text
78.56 + 5 = 83.560000
5678 + 2.2 = 5680.200000
2 + 5 = 7
```

[[information]]
| Nous vous conseillons d'opter pour les lettres majuscules qui ont l'avantage d'être plus lisible.