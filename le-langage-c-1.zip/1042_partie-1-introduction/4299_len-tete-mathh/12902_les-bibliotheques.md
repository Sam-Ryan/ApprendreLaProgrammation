Je tiens à attirer votre attention sur le fait que la bibliothèque mathématique du langage C est une bibliothèque un peu *spéciale*. Celle-ci se comporte comme une bibliothèque tierce, soit une bibliothèque qui se rajoute par-dessus la bibliothèque standard. Les bibliothèques peuvent être présentés sous forme de code source ou de fichiers binaires à lier à vos programmes. 

Dans les grandes lignes, il existe deux grand types de bibliothèques : les bibliothèques statiques, et les bibliothèques dynamiques. Avec une bibliothèque statique, le code de la bibliothèque est inclus dans l'exécutable lors de la compilation. Ce dernier est donc plus important, il prend plus de place. Une bibliothèque dynamique est un fichier utilisé par un exécutable, mais n'en faisant pas partie. Ce fichier contient des fonctions qui pourront être appelées pendant l'exécution d'un programme, sans que celles-ci soient incluses dans son exécutable. Il faut dans ce cas fournir la bibliothèque avec le programme.

Les systèmes d'exploitations récents sont pratiquement tous multitâche : ils permettent d’exécuter plusieurs programmes "en même temps". Il arrive donc que certains programmes utilisent les mêmes bibliothèques en même temps. Avec des bibliothèques dynamiques, il est possible de ne charger celles-ci qu'une seule fois en mémoire et de laisser tous les programmes en utiliser la même copie. On parle alors de **bibliothèques partagées**.

Ces bibliothèques sont donc des fichiers binaires, qui possèdent généralement les extensions suivantes :

* Bibliothèques statiques :
    * `.a` :  sous UNIX et GNU/Linux (pour **A**rchive) ;	
    * `.lib` : sous Microsoft Windows (**LIB**rary).
* Bibliothèques dynamiques :
    * `.so` : sous UNIX et GNU/Linux (**S**hared **O**bject) ;
    * `.dylib` : sous Mac OS X (**Dy**namic **Lib**rary) ;
    * `.dll` : sous Microsoft Windows (**D**ynamically **L**inkable **L**ibraries).

Notre fameuse bibliothèque mathématique se nomme **libm** et est une bibliothèque statique. Celle-ci ne se lie au programme que sous les systèmes de type UNIX et GNU/Linux (Windows le fait automatiquement).

# Lier une bibliothèque

À savoir, il est courant de voir sur la toile la traduction anglaise du verbe lier : *link*. Certains parlent même de "*linkage* d'une bibliothèque", et utilisent l'expression "J'ai *linké* la bibliothèque mathématique". En bon francophiles, nous allons utiliser le terme *lier* par la suite.

Afin de lier une bibliothèque sous GCC et MinGW, on procède ainsi :

```console
-l<bibliothèque>
```

Si vous compilez en ligne de commande, cela donnera dans notre cas :

```console
gcc main.c -lm    # m comme mathématiques
```

Pour lier une bibliothèque, il faut d'abord mettre les fichiers au bon endroit. S'il s'agit d'une bibliothèque statique, il faut la mettre dans le bon dossier. Nous avons alors deux choix. Le premier, c'est de mettre tous les fichiers dans le dossier du compilateur.

* Avec **Code::Blocks**, il faut la mettre dans le dossier `lib` situé dans le répertoire du compilateur.	
* Avec **Visual C++**, il faut la mettre dans le dossier `C:\Program Files (x86)\Microsoft Visual Studio xx.x\VC\lib`.	
* Avec **xCode**, il faut la mettre dans le dossier ```<Racine Disque>/Bibliothèque/Frameworks```.	
* Pour ceux qui compilent **à la main**, il suffit d'ajouter les fichiers dans le dossier `lib` du compilateur.

Ça semble logique, mais c'est assez embêtant : on se retrouve avec des dossiers remplis de bibliothèques dont on ne sait plus d'où elles viennent, désinstaller un logiciel demande de sauvegarder toutes les bibliothèques installées, etc. Bref, pas très pratique. Pour pallier à ces problèmes, il y a une deuxième solution : on crée un dossier indépendant, dans lequel on crée un sous-dossier par bibliothèque. Cela permet de bien organiser ses fichiers, d'être indépendants des logiciels utilisés et est plus facile à entretenir. Le choix de la méthode est votre.

Si au contraire il s'agit d'une bibliothèque dynamique, c'est tout simple, celle-ci doit être mise dans le répertoire du projet. 

Ensuite, il faut modifier les propriétés du projet pour qu'il lie bien la bibliothèque au projet. La méthode varie selon que vous êtes avec :

* **Code::Blocks** : Ouvrez ou créez un projet puis allez dans *Project -> Build options -> Linker settings -> Other linker options*, insérez ensuite tout le texte nécessaire dans la zone de texte.	
* **Visual Studio** : Il suffit de rajouter la ligne suivante chaque fois que vous voulez lier une bibliothèque, en remplaçant *non_de_la_lib* par le nom de la bibliothèque à linker.

```c
#pragma comment (lib, "nom_de_la_lib.lib")
```

Il est également possible de l'ajouter comme élément du projet.