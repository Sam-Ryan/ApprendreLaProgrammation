Le fichier d'en-tête de la bibliothèque mathématique se nomme : **<math.h\>**. Ce dernier contient un certain nombre de déclarations de fonctions mathématiques. Tout comme **<stdio.h\>** , l'inclusion se réalise à l'aide d'une directive `#include` :

```c
#include <math.h>
```

# Les puissances

```c
double pow(double x, double y);
```

La fonction *pow*() élève le nombre *x* à la puissance *y* ($x^y$). Cette fonction est très lourde et lente à l’exécution, je vous recommande donc de ne pas l'utiliser pour les calculs de faibles puissances. Mais, pourquoi cette fonction est-elle si lente ? La raison est simple : elle est très puissante, puisque elle gère les nombres et les exposant négatifs, ce qui n'est pas une mince affaire. 

Cependant, il existe quelques cas que *pow* est incapable de gérer.

* Il n'est pas possible de lui fournir un nombre négatif et un exposant fractionnaire sans quoi vous lui demandez de calculer la racine d'un nombre négatif (ce qui est impossible dans le cas de nombres réels).
* Il n'est pas possible de lui passer un nombre nul et un exposant nul en même temps ($0^0$ n'est pas calculable).	
* Il n'est pas possible de lui transmettre un nombre nul et un exposant négatif sans quoi vous lui demandez de diviser un nombre par zéro (ce qui est mathématiquement impossible).

```c
#include <math.h>
#include <stdio.h>

int main(void)
{
    double x, y, z;

    x = pow(5, 2);
    y = pow(2, -2);
    z = pow(3.14, 4);

    printf("x = %f\ny = %f\nz = %f\n", x, y, z);
    return 0;
}
```
```console
x = 25.000000
y = 0.250000
z = 97.211712
```

[[attention]]
| L'utilisation de la bibliothèque mathématique requiert d'ajouter l'option `-lm` lors de la compilation, par exemple comme ceci : `zcc -lm main.c`

[[information]]
| Pour rappel (ou non) : $x^{-y} = \frac{1}{x^y}$ et $x^{\frac{y}{z}} = \sqrt[z]{x^y}$

# Racine carrée

L'en-tête ```<math.h>``` fournit aussi une fonction de calcul de la racine carrée d'un nombre. Ils 'agit de la fonction *sqrt*. Son prototype est le suivant : 

```c
double sqrt(double x);
```

La fonction *sqrt* renvoie la racine carrée du réel positif passé en paramètre. Elle renverra une erreur si vous tentez de calculer la racine carrée d'un réel négatif.

```c
#include <math.h>
#include <stdio.h>

int main(void)
{
    double x = sqrt(25);
    printf("x = %f\n", x);
    return 0;
}
```
```console
x = 5.000000
```

# Fonctions d’arrondis

Cette rapide présentation de la bibliothèque mathématiques standard du C touche à sa fin, il ne nous reste plus qu'une poignée de fonctions à voir, notamment les fonctions d'arrondis.

* ```double ceil(double x);```
* ```double floor(double x);```

La première, *ceil*, renvoie la partie entière supérieure du nombre *x*. À l'inverse, la fonction *floor* la partie entière inférieure du nombre passé en paramètre. Voici un petit code d'exemple :

```c
#include <math.h>
#include <stdio.h>

int main(void)
{
    double x, y;

    x = ceil(42.7);
    y = floor(42.7);

    printf("x = %f\ny = %f\n", x, y);
    return 0;
}
```
```console
x = 43.000000
y = 42.000000
```

# Autres fonctions sur les flottants

Il nous reste ensuite quelques fonctions restantes, inclassables. J'ai nommé :

* ```double fabs(double x);```
* ```double fmod(double x, double y);```

La fonction *fabs* retourne la valeur absolue de *x*, soit $|x|$. Pour ceux qui ne connaissent pas, la valeur absolue d'un nombre représente la partie numérique de ce dernier.

*$|1| = 1$	
*$|-42|= 42$

Pour finir la fonction *fmod* quand à elle, divise *x* par *y* puis renvoie le reste. Pour simplifier, elle effectue un modulo sur deux flottants. Elle est utile car le langage C ne nous autorise pas à utiliser l'opérateur % sur des flottants.

```c
#include <math.h>
#include <stdio.h>

int main(void)
{
    double x, y;

    x = fabs(-7);
    y = fmod(42, 5);

    printf("x = %f\ny = %f\n", x, y);
    return 0;
}
```
```console
x = 7.000000
y = 2.000000
```