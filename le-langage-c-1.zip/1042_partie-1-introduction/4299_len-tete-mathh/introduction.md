Dans ce chapitre, nous allons découvrir une nouvelle partie de la bibliothèque standard dédiée aux fonctions mathématiques de bases et en profiter pour réaliser quelques exercices.

[[information]]
| Rassurez-vous : nous ne verrons que des fonctions mathématiques simples.