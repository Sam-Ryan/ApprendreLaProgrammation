Fini la théorie, place à la pratique ! Votre mission, si vous l'acceptez : recoder quelques fonctions de la bibliothèques mathématiques, que vous connaissez bien désormais. Bien entendu, je vous aiderai à chaque fois en vous expliquant l’algorithme à utiliser par exemple. Enfin, avant de commencer, je vous livre une petite astuce : pour tester si votre fonction fonctionne correctement, pourquoi ne pas la comparer avec celle de la bibliothèque standard ? Et pour ce faire, pourquoi ne pas créer une **macro** qui donnerait le résultat retourné par votre fonction et par celle de la bibliothèque standard ?

# Racine carrée

La première fonction que nous allons recoder est la racine carrée d'un réel positif. Pour cela, nous allons utiliser un très vieil algorithme appelé [la méthode de Héron](https://fr.wikipedia.org/wiki/Méthode_de_Héron), du nom du mathématicien grec qui l'a découverte. 

Cette méthode est relativement simple : pour trouver $\sqrt{A}$, on prend un nombre au hasard qu'on nomme $x_{n}$, et on utilise cette formule : $x_{n+1} = \frac{x_n + \frac{A}{x_n}}{2}$. Il suffit de répéter cette opération plusieurs fois, en remplaçant $x_{n}$ par la valeur calculée au tour d'avant. En faisant ainsi, le résultat converge vers $\sqrt{A}$, la précision dépendant du nombre de répétitions de la récurrence. On doit calculer cette suite jusqu’à ce qu'on aie atteint une précision suffisante.

Vous avez maintenant toutes les clefs en main pour recoder la fonction *sqrt*. Si vous avez du mal, jetez un œil à l'algorithme se trouvant [ici](http://paste.awesom.eu/informaticienzero/RXe&ln). Quant à ceux qui veulent comparer leur code à la correction, en voici une :

[[secret]]
| ```c
| /* La fameuse macro dont je vous parlait tantôt */
| #define SQRT(x) printf("%.4f =?= %.4f\n", my_sqrt(x), sqrt(x))
| 
| double my_sqrt(double x)
| {
|     double res = 1;
|     int i;
|     const int prec = 20;
| 
|     for (i = 0; i < prec; ++i)
|     {
|         res = (res + x / res) / 2;
|     }
| 
|     return res;
| }
| 
| int main(void)
| {
|     SQRT(3);
|     SQRT(2);
|     SQRT(100);
|     return 0;
| }
| ```

# Exponentielle

La deuxième fonction que nous allons faire sera l'exponentielle de base $e$, notée $\exp(x)$ ou $e^x$. Une implémentation naïve serait d'utiliser la fonction *pow*. C'est une idée, facile et rapide à coder, mais pas très optimisée : en effet, *pow* est une fonction assez lourde, autant choisir une autre solution : le [développement limité](http://fr.wikipedia.org/wiki/Développement_limité).

La formule est la suivante : $e^x = 1 + x + \frac{x^2}{2!} + \frac{x^3}{3!} + \ldots+ \frac{x^n}{n!} + o(x^n)$. En gros, on doit calculer cette somme jusqu’à ce qu'on aie atteint une précision suffisante. Pour ceux qui ne savent pas, $n!$ est [la factorielle](http://fr.wikipedia.org/wiki/Factorielle) d'un nombre et vaut $1 \times 2 \times 3 \times \ldots \times (n - 1) \times n$ soit $\prod_{i = 0}^n i$.

Avant de vous lancer, je vous donne une dernière astuce : vous n'avez pas besoin de la fonction *pow*, ni de faire une fonction calculant la factorielle d'un nombre. Bon courage, vous pouvez y arriver !

[[secret]]
| Si vous ne voyez pas comment se passer de *pow* ou d'une fonction factorielle, dîtes-vous qu'il n'est pas nécessaire de recalculer toutes les puissances à chaque fois. En effet, $x^{n+1} = x^n \times x$. Il suffit de connaître $x^n$. Le principe est le même pour la factorielle : $(x+1)! = x! \times (x + 1)$.

Pour ceux qui auraient besoin, l'algorithme est disponible [à cette adresse](http://paste.awesom.eu/informaticienzero/IkA&ln). Enfin, pour ceux qui ont fini ou qui veulent s'aider de la correction, la voici :

[[secret]]
| ```c
| double my_exp(double x)
| {
|     double res = 1 + x;
|     double puis = x, fact = 1;
|     const int pres = 25;
|     int i;
| 
| /* Comme res vaut déjà 1 + x, il faut commencer à x^2, soit i = 2 */
|     for(i = 2; i < pres; i++)
|     {
|         puis *= x;
|         fact *= i;
|         res += puis / fact;
|     }
|     return res;
| }
| 
| #define EXP(x) printf("%.10f =?= %.10f\n", my_exp(x), exp(x))
| 
| int main(void)
| {
|     EXP(1);
|     EXP(3);
|     EXP(2.718281828);
|     return 0;
| }
| ```

# Autres

Pour votre information, le calcul des fonctions logarithme, sinus, cosinus, tangente, et leurs réciproque, peut s'effectuer aussi avec des développements limités. Les formules sont facilement trouvables sur la toile : Wikipédia est votre allié.