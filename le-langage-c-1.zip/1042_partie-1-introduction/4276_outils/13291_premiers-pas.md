Maintenant que nous avons installé les outils nécessaires à la compilation et compilé un premier code, voyons celui-ci plus en détails.

```c
int main(void)
{
    return 0;
}
```

Copiez-collez ce code pour que vous et moi ayons le même, puis sauvegardez. Même si c’est un minuscule projet, c’est une bonne habitude à prendre qui peut parfois vous épargner des problèmes de fichiers perdus. 

Ce bout de code est appelé une **fonction**. Un programme écrit en C n’est composé pratiquement que de fonctions : de petits bouts de code qui donnent des instructions à l’ordinateur. Elles ont toujours un objectif, une *fonction* particulière, par exemple calculer la racine carrée d'un nombre.

Notre fonction s’appelle *main*() (prononcez « mèïne »). C’est la fonction de base commune à tous les programmes en C, le point d’entrée du programme, son cœur. Le programme commence et finit toujours par elle.

Une fonction est délimitée par des accolades (**{** et **}**). Après les accolades il n’y a rien, car pour l’instant nous n’avons que la fonction *main*().

À l’intérieur des parenthèses, il y a le mot « ```void``` ». Ce mot-clé signifie : « je ne veux pas de paramètres », nous y reviendrons en temps voulu.

Enfin, la fonction se termine par l'instruction `return 0;` qui signifie en l'occurrence que la fonction a terminé son travail (bon, pour l'instant elle n'en a pas, mais nous y arriveront rapidement) et que tout s'est bien passé.