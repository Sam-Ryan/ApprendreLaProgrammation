Bien que de nombreux IDE soient disponibles pour Windows, nous ne parlerons que de deux d’entre eux : Code::Blocks et Visual C++, sans oublier une partie consacrée à la compilation ''via'' l’invite de commande.

# Avec un IDE

## Code::Blocks

Code::Blocks est un IDE gratuit et libre (vous pouvez obtenir le code source du logiciel si vous le souhaitez), qui fonctionne avec plusieurs compilateurs différents et qui n’est pas très compliqué à prendre en main. Il n’est cependant disponible qu’en anglais (bien qu’il existe des traductions incomplètes en français) ; néanmoins, avec un dictionnaire et de l’intuition, vous vous en sortirez très bien.

Pour télécharger Code::Blocks, rendez-vous sur [le site officiel](http://www.codeblocks.org/ ), dans la section « *[Downloads]([http://www.codeblocks.org/downloads/)* », puis dans la sous-section « *Download the binary release* ». Cette section vous permettra de télécharger le logiciel ; contrairement à la section « *Download the source code*' » qui sert à télécharger le code source de Code::Blocks.

Il va falloir ensuite télécharger la version du logiciel adaptée à votre système d’exploitation.

* **Windows** : choisissez « `codeblocks-XX.XXmingw-setup.exe` » pour télécharger la version de Code::Blocks pour Windows avec un compilateur intégré. Si vous choisissez la première, vous ne pourrez pas compiler vos programmes ! Je le répète donc encore une fois : choisissez la version avec **mingw** dans le nom. Pour information, MinGW est une adaptation pour Windows du compilateur GCC.
* **Linux** : choisissez la version qui correspond à votre distribution. Attention à ne pas confondre les versions 32 bits et 64 bits.
* **Mac** : téléchargez le fichier proposé.

Si cependant vous êtes expérimentés et que vous souhaitez installer votre propre compilateur, vous pouvez prendre la première version. Ensuite pour l’installation, laissez-vous guider, elle est très simple. Une fois l’installation terminée, en lançant Code::Blocks, vous devriez obtenir ceci :

![Page principale au lancement de Code::Blocks](/media/galleries/1501/1748d302-5602-4f8e-8bd1-b8e35fec10c8.png.960x960_q85.jpg)

Cela vous parait compliqué ? Je vais tout vous expliquer dans quelques secondes. Avant, j’aimerais qu’on crée un projet, pour que je puisse vous illustrer tout ça. Pour ce faire, deux possibilités : ou vous cliquez sur « *Create a new project* » dans le menu de démarrage, ou bien vous cliquez sur « *File -> New -> Project* ». Dans tous les cas, vous tombez sur cette fenêtre :

![Fenêtre de choix de création de projet](/media/galleries/1501/e0b91a39-e1ca-4a4f-91d7-142bc9b0bd69.png.960x960_q85.jpg)

Choisissez l’icône « *Console application* », entourée en gras sur l’image. Puis double-cliquez dessus ou cliquez sur le bouton « Go » pour créer un projet de type console.

Le premier menu est juste un menu informatif, cliquez sur « *Next* ». La page suivante vous demande quel langage vous voulez utiliser. Sélectionnez « *C* » puis « *Next* ». Vous arrivez ensuite sur cette fenêtre :

![Première fenêtre lors de la création d'un projet](/media/galleries/1501/e473e4fc-18fc-4fa5-8b6a-1ea2e8431758.png.960x960_q85.jpg)

Là, il y a plusieurs champs.

* **Project title** : c’est le nom que vous souhaitez donner à votre projet. Un même nom ne peut pas être utilisé plusieurs fois, il faut un nom différent pour chaque projet.	
* **Folder to create project in** : c’est le répertoire dans lequel le projet sera créé.	
* **Project filename** et **resulting filename** : ces champs sont remplis automatiquement par Code::Blocks, on ne s'en préoccupe pas.

Ensuite, dernière fenêtre :

![Deuxième fenêtre lors de la création d'un projet](/media/galleries/1501/ed0cb7a8-4dbd-4b7e-b001-b3076cb6238d.png.960x960_q85.jpg)

* **Compiler** : permet de choisir le compilateur que l’on veut utiliser. Ici, comme il n’y a que ce compilateur d’installé, on n’y touche pas.
* **Create "Debug" configuration** : cochez cette case pour avoir un exécutable compilé en mode *Debug*, c’est-à-dire un programme non optimisé qui contiendra toutes les informations nécessaires pour déboguer. L’exécutable ne sera pas portable. 
* **Create "Release configuration'''** : le programme est optimisé, portable et allégé puisqu’il ne possède plus les informations de débogage.

Choisir entre les deux modes importe peu pour l’instant. Il faut simplement que l’un des deux au moins soit coché. Cliquez sur « Finish » pour terminer la création du projet. Maintenant, vous devez avoir une fenêtre comme celle-ci :

![Page principale de Code::Blocks après la création d'un projet](/media/galleries/1501/0eae53d1-71c0-4b06-bb49-0c1957c119cf.png.960x960_q85.png)

Je pense que quelques explications ne seraient pas de refus.

1. C’est la **liste des menus**. Certains seront très utilisés, tandis que d’autres presque pas. Retenez que le menu « *File* » est l’un des plus utilisés.
2. Ce sont les **icônes**. Voici les quatre principales :
    * ![None](http://zestedesavoir.com/media/galleries/1501/54821e79-7353-47c4-9d7b-0fe106d1fff8.png.960x960_q85.jpg) -> c'est l'icône « *Build* », qui sert à compiler le fichier sans le lancer ; le raccourci clavier est **Ctrl + F9**.
    * ![None](http://zestedesavoir.com/media/galleries/1501/7eeafb50-0fe6-47ba-972c-a4d8367d054d.png.960x960_q85.jpg) -> c’est l’icône « *Run* », qui lance le dernier exécutable compilé ; le raccourci clavier est **Ctrl + F10**.
    * ![None](http://zestedesavoir.com/media/galleries/1501/44f28ed4-379f-480e-8bcb-78ec0c0035cf.png.960x960_q85.jpg) -> c’est l’icône « *Build & Run* », la contraction des deux icônes précédentes : elle compile et exécute ; le raccourci clavier est **F9**.
    * ![None](http://zestedesavoir.com/media/galleries/1501/025e5b33-4154-495b-a6bb-ee76386201c5.png.960x960_q85.jpg) -> c’est l’icône « *Rebuild* », qui sert à recompiler tous les fichiers ; par défaut, Code::Blocks ne les recompile pas tous (seuls ceux qui ont été modifiés sont recompilés) ; le raccourci clavier est **Ctrl + F11**.
3. C’est la **zone des projets**. C’est ici que vous pouvez voir tous les fichiers qui composent votre projet. Vous pouvez même avoir plusieurs projets en même temps, mais vous ne pouvez en compiler qu’un à la fois.
4. C’est la **zone principale**, car c’est ici que l’on écrit le code source.
5. C’est la **zone de notification** où apparaissent les erreurs, les messages de compilation, les messages du débogueur, ainsi que les les avertissements.

Vous pouvez voir que Code::Blocks a généré un code par défaut. Nous allons le compiler. Utilisez les icônes ou les raccourcis clavier pour se faire. Il se peut que vous obteniez un message d'erreur comme celui-ci :

```console
"My-program - Release ou Debug" uses an invalid compiler. Skipping...
Nothing to be done.
```

Si cela vous arrive, ne paniquez pas. Il y a deux causes possibles.
	
* **Vous utilisez Code::Blocks et vous avez téléchargé la version sans compilateur** : dans ce cas, retournez sur le site officiel et prenez la version avec MinGW.
* **Vous avez la bonne version et dans ce cas c’est le chemin vers le compilateur MinGW qui est incorrect** : rendez-vous dans « *Settings -> Compiler&Debugger -> Toolchain executable* », cliquez sur « … », et saisissez le répertoire « *MinGW* » dans votre installation (si vous avez installé Code::Blocks avec MinGW, celui-ci se trouve dans le répertoire de Code::Blocks), puis cliquez sur OK.

Une fois le problème réglé (si problème il y avait), le programme est compilé et un message apparait dans la console :

```console
Hello world!

Process returned 0 (0x0)   execution time : x.xxx s
Press any key to continue.
```

La première ligne correspond à ce qu'affiche le programme. Les deux lignes suivantes sont elles spécifiques à Code::Blocks. La première indique à l'utilisateur si le programme s'est bien déroulé ou s'il y a eu erreur et le temps écoulé depuis le lancement. La seconde demande d'appuyer sur une touche pour continuer. En effet, sans cette dernière ligne, nous n'aurions pas pu voir le programme se lancer qu'il serait déjà terminé. Ce comportement est spécifique à Windows.

## Visual C++

Visual C++ est un IDE édité par Microsoft et très efficace, car adapté pour Windows. Il possède aussi un débogueur puissant. Bien qu’il ne soit pas libre, Visual C++ est gratuit (dans sa version express) et disponible en de nombreuses langues, dont le français. Il suffit tout simplement d’enregistrer le logiciel pour l’utiliser sans limites de temps ; c’est gratuit et rapide, vous n’avez besoin que d’une adresse mail.

Pour télécharger Visual C++, rendez-vous sur le [site de Microsoft](http://msdn.microsoft.com/fr-fr/express/aa975050.aspx ). Cliquez ensuite sur l’onglet « *Visual C++ 2010 Express* ». Vous arriverez sur la page de téléchargement. Sélectionnez la langue que vous voulez puis cliquez sur « *Télécharger* ».

Le programme d’installation va se charger de tout télécharger et tout installer. À un moment, vous devrez redémarrer. Acceptez, et une fois le redémarrage terminé, l’installation finira tranquillement.

Voici à quoi ressemble Visual C++ 2010 Express :

![Page principale après le lancement de Visual](http://zestedesavoir.com/media/galleries/1501/04723942-1107-43d5-8c6c-d44ac2cf07a6.png.960x960_q85.jpg)

Comme pour Code::Blocks, j’aimerais vous montrer la création d’un projet avant de vous expliquer l’image. Pour cela, deux possibilités : cliquez sur « *Nouveau projet* » au démarrage, ou bien « *Fichier ->Nouveau -> Projet* ». Vous devriez obtenir cette fenêtre :

![Création de projet page 1](http://zestedesavoir.com/media/galleries/1501/8a01619e-e767-404c-9fa3-183d567ef3e1.png.960x960_q85.jpg)

Pour créer un projet en console, sélectionnez « *Application console Win32* », et donnez un nom à votre projet dans la case « Nom » en bas de la fenêtre. Une fois ceci fait, vous arrivez sur une fenêtre à propos des paramètres de votre projet. Cliquez sur « *Suivant* » en bas ou « *Paramètres de l’application* » dans la colonne à gauche. Vous devez tomber sur une fenêtre comme celle-ci :

![Création projet page 2](http://zestedesavoir.com/media/galleries/1501/42ecfd63-8ab6-4977-a85d-2ea3d9bbf050.png.960x960_q85.jpg)

Sélectionnez « *Projet vide* » pour commencer avec un projet vierge, sinon Visual va créé un projet avec des fichiers dont nous ne voulons pas. 

Pour rajouter des fichiers, la manœuvre est très simple : faites un clic droit sur l’onglet « *Fichiers sources* » dans la colonne de gauche, puis allez dans « *Ajouter -> Nouvel élément…* ». Une petite image pour bien comprendre :

![Ajouter un fichier](http://zestedesavoir.com/media/galleries/1501/940cea9e-7cb2-49e4-812b-76615a2b4212.png.960x960_q85.jpg)

Une nouvelle fenêtre apparait alors pour vous demander quel type de fichier il faut ajouter au projet. Cliquez sur « *Fichiers C++ (.cpp)* » (même si ce type de fichier est normalement réservé au C++), et appelez votre fichier `main.c`. Il faut que le fichier se termine par `.c`, sinon Visual ajoutera automatiquement l’extension `.cpp` qui est celle des fichiers C++. Donc faites-y attention ! 

Et si nous examinions un peu les menus de Visual C++ ? Vous devriez normalement avoir une fenêtre comme celle-ci :

![Page principale après la création d'un projet et l'ajout d'un fichier](http://zestedesavoir.com/media/galleries/1501/70b4d987-8479-499b-855a-aaf6d57bab35.png.960x960_q85.png)

Regardons plus attentivement ces quatre zones.

1. La **barre d’outils** : elle contient tous les menus et les raccourcis (comme la compilation, la génération, etc), certains seront plus utilisés que d’autres.
2. La **zone principale** : c’est ici que l’on écrira le code.
3. L'**explorateur de solutions** : cette zone permet de gérer les fichiers qui composent notre projet. Visual y organise les fichiers en trois types : les fichiers sources, les fichiers ressources et les fichiers d’en-tête (nous verrons tout ça en temps voulu).
4. La **zone de notification** : c’est dans cette zone qu’apparaissent les erreurs, les informations du débogueur, les avertissements et les messages de compilation.

Voici quelques raccourcis claviers pratiques que vous serez souvent amenés à utiliser :

* **F5** : lance l’exécutable en appelant le débogueur ;	
* **Ctrl + F5** : lance l’exécutable sans appeler le *débugger* ;	
* **F7** : génère une solution (compile) sans lancer le programme ;      	
* **Ctrl + Alt + F7** : régénère une solution.

Comme une liste de tous les raccourcis serait trop longue, voici [la liste officielle](http://download.microsoft.com/download/2/9/6/296AAFA4-669A-46FE-9509-93753F7B0F46/VS-KB-Brochure-CPP-A4.pdf) (en anglais). 

Essayons de mettre en pratiques quelques-uns de ces raccourcis en compilant un code minimal. Je vous fournis un code source que nous examinerons dans le chapitre suivant. 

```c
#include <stdio.h>

int main(void)
{
    printf("Hello world!\n");
    return 0;
}
```

Pour le compiler, on doit faire **F7** puis **Ctrl + F5**. Cependant, pour allez plus vite, on peut faire directement **Ctrl + F5**. Si vous utilisez cette combinaison de touches, il se peut que vous tombiez sur une fenêtre semblable à celle-ci :

![Fenêtre d'erreur de recompilation](http://zestedesavoir.com/media/galleries/1501/5f419a2f-d447-4d43-96a3-769dc5592de0.png.960x960_q85.jpg)

Cela signifie qu'il y a eu des modifications dans le code et que la solution n'a pas été régénérée (on a pas recompilé). Dans ce cas, cliquez sur « *Oui* » pour régénérer la solution, ou cliquez sur « *Non* » pour lancer la dernière solution générée (le dernier exécutable compilé).

# Avec l’invite de commande

Même si la programmation à l’aide d’un IDE peut être pratique, certains préfèrent néanmoins programmer *à la main*, c’est-à-dire s’occuper eux-mêmes de la compilation. Pour cela, ils utilisent l’invite de commande. Si jamais cette méthode vous tente et que vous avez les compétences nécessaires pour vous servir de l’invite, lisez cette partie.

## Le compilateur

Le plus important dans tout ça est le compilateur. Je vous propose donc de télécharger MinGW, qui est une adaptation pour Windows du compilateur GCC, je vous le rappelle. 

Rendez-vous sur le [site de MinGW](http://www.mingw.org/), puis dans le cadre de gauche dans la section « *[Download](http://sourceforge.net/projects/mingw/files/)* ». Pour se faciliter le travail, on va télécharger l’installateur. Pour cela, cliquez sur le lien en haut de la page « *Looking for the latest version ? Download mingw-get-inst-xxxxxxxx.exe (xxx.x kB)* ».

Exécutez le programme. Arrivés à la partie « *Repository Catalogues* », choisissez « *Use pre-packaged repository catalogues* » si vous voulez utiliser les outils fournis avec l’installateur, ou bien « *Download latest repository catalogues* » si vous voulez que l’installateur télécharge les tout derniers fichiers.

Ceci fait, acceptez la licence (lisez-la si vous en avez le courage), puis sélectionnez le dossier où vous souhaitez que MinGW soit installé. Ensuite, il faut choisir les composants que l’on veut installer. Normalement, seuls « *MinGW Compiler Suite* » et « *C Compiler* » sont cochés. Les autres cases ne nous intéressent pas puisque elles servent à installer des compilateurs pour d'autres langages. Laissez ensuite le programme finir son travail.

Maintenant il reste une dernière étape : configurer la variable d'environnement (PATH). Cette étape va permettre à l'Invite de Commande de comprendre les commandes de compilation de MinGW, sans quoi il serait impossible de compiler un programme.

* Sous Windows XP et antérieur, il faut faire un clic-droit sur « *Poste de travail* » puis choisir « *Propriétés* ». Dans la fenêtre qui s'ouvre, cliquez sur « *Avancés* » puis sur « *Variables d'environnement* ».
* Sous Windows Vista et Seven, il faut faire un clic-droit sur l'icône « *Ordinateur* » dans le menu Démarrer ou bien sur « *Poste de travail* ». Ensuite, cliquez sur « *Paramètres systèmes avancés* ». Dans la nouvelle fenêtre qui s'ouvre, allez dans « *Paramètres systèmes avancés* » et cliquez sur « *Variable d'environnement* ».

Dans la partie *Utilisateur courant*, créez une nouvelle variable et rentrez `%PATH%;C:\MinGW\bin` (le chemin après le point-virgule peut varier en fonction de où vous avez décidés d'installer MinGW, l'important est de bien avoir le répertoire `bin` à la fin).

## L’éditeur de texte

L’éditeur de texte va nous permettre d’écrire notre code source et de l’enregistrer pour que le compilateur fasse son travail. L’idéal est d’avoir un éditeur de texte facile à utiliser et qui colore le code source, ce qui permet une meilleure relecture. Si jamais vous avez déjà un éditeur de texte et que vous l'appréciez, ne changez pas, il marchera très bien lui aussi.

Si cependant vous ne savez pas lequel prendre, je vais vous aider. Personnellement, j’utilise [Notepad++](http://notepad-plus-plus.org/fr/), qui est simple, pratique et efficace. Pour le télécharger, rendez-vous sur la [page de téléchargement](http://notepad-plus-plus.org/fr/download/v5.9.6.2.html), et sélectionnez « *Notepad++ vX.X.X.X Installer* » pour télécharger l’installateur. Pour l'installation je vous laisse faire, elle est facile.

## Compiler à la main avec l’invite de commande

Testons tout ce que l’on vient d’installer en compilant un petit code simple que nous expliquerons dans le chapitre suivant.

```c
#include <stdio.h>

int main(void)
{
    printf("Hello world!\n");
    return 0;
}
```

Copiez-collez ce code dans l’éditeur de texte, puis enregistrez le fichier sous le nom `main.c`. Ensuite, déplacez-vous dans les répertoires à l’aide de l’invite pour arriver dans le répertoire qui contient le fichier source.

```console
C:\Programmation>dir

Répertoire de C:\Programmation

07/12/2011  13:54    <REP>          .
07/12/2011  13:54    <REP>          ..
07/12/2011  13:54             130   main.c

1 fichier(s)              130 octets
2 Rép(s)  172 089 290 752 octets libres
```

Nous allons compiler ce fichier à l’aide d’une commande : `gcc main.c`. Cette commande va transformer le fichier spécifié en exécutable. Si vous regardez le répertoire de nouveau, vous remarquerez d’ailleurs qu'un fichier `.exe` est apparu. C’est le résultat de la compilation. Si vous le lancez, vous verrez le résultat à l'écran :

```console
C:\Programmation>gcc main.c

C:\Programmation>main.exe
Hello world
```

Si vous obtenez une erreur du type *« 'gcc' n'est pas reconnu en tant que commande interne ou externe, un programme exécutable ou un fichiers de commandes »* c'est que vous vous êtes trompés quelque part.

Nous apprendrons dans le chapitre suivant pourquoi le programme affiche un message à l’écran.

Il existe de nombreuses options de compilation pour MinGW que tout un cours entier ne pourrait pas aborder. Si vous souhaitez découvrir ces options, vous pouvez jeter un œil à la [documentation officielle](http://linux.die.net/man/1/gcc). Même si cette page traite de GCC, la très grande majorité des options marchent pour MinGW.

*[MinGW]: Minimalist GNU for Windows
*[GCC]: GNU Compiler Collection