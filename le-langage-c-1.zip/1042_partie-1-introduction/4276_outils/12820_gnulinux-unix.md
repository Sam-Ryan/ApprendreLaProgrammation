Le C étant très lié à UNIX, il existe de nombreux outils disponibles pour ces deux systèmes d’exploitation. Je vais vous en présenter quelques-uns. Afin d’éviter certains problèmes, je vous conseille fortement d’installer le paquet ''build-essential'' avant toute chose sous Debian et ses dérivés (Ubuntu, Kubuntu, etc. en font partis) : ```# aptitude install build-essential```

# Les IDE

Sous GNU/Linux et UNIX, il y a évidemment de nombreux IDE disponibles. Si vous souhaitez utiliser un IDE, je vous conseille Code::Blocks. Vérifiez dans vos dépôts s’il est disponible, et si jamais il ne l’est pas, rendez-vous sur [la page de téléchargement du site officiel de Code::Blocks](http://www.codeblocks.org/downloads/26). Une fois que vous l’avez installé, regardez plus haut dans ce tutoriel pour vous familiariser avec lui.

Même si les IDE sont pratiques, beaucoup de programmeurs préfèrent compiler à la main sous ces plateformes. Je vous recommande donc de lire également la partie suivante, même si vous ne pensez pas compiler à la main.

# La compilation en ligne de commande

La compilation à la main est prônée par de nombreux programmeurs experts. On dit souvent que ça présente de nombreux avantages. Cependant, pour le programmeur débutant, c’est légèrement différent. En effet, la compilation manuelle présente des avantages et des défauts :

* rapide une fois prise en main et légère ;
* permet d’apprendre plus de choses, voire même d’apprendre plus rapidement certains concepts ;
* on doit cependant tout faire soi-même ;
* parait compliqué et hostile ;
* il faut savoir manipuler le terminal.

Le troisième argument est en orange puisque le fait de tout faire soi-même est très intéressant et est donc un avantage conséquent. Cependant, pour certains cette technique est assez *difficile*. Faire tout soi-même permet au programmeur d’avoir le contrôle absolu sur ce qu’il fait, contrairement à certains IDE qui dissimulent certaines fonctionnalités intéressantes par exemple.

Avant de vous montrer l’utilisation de GCC, le compilateur que nous allons utiliser, il faut d’abord avoir un code source sous la main. Pour créer un code source sans IDE, il faut utiliser un éditeur de texte **et non pas un traitement de texte** ! Un éditeur de texte est un programme qui permet de modifier des fichiers quelconques (tout est fichier, en tout cas sous les GNU/Linux et UNIX, donc avec un éditeur de texte, vous pouvez tout modifier ; cependant, on préfère un éditeur de texte pour programmer, en effet aucune personne saine d’esprit n’irait créer un fichier *.png à la main).

Un traitement de texte comme *LibreOffice Writer* permet non seulement de modifier des fichiers textes, mais offre la possibilité de les mettre en forme, c’est-à-dire mettre en gras du texte, changer la police, ajouter des images, etc.

Il existe des éditeurs de textes graphiques et des éditeurs de textes en console. Voici quelques-uns des plus célèbres et des plus utiles pour un programmeur :

* [Vim](http://www.vim.org/), tutoriel en français : commande ```vimtutor``` ;
* [Emacs](http://www.gnu.org/s/emacs/), tutoriel en français disponible [ici](http://www.tuteurs.ens.fr/unix/editeurs/emacs.html ) ;	
* [jEdit](http://www.jedit.org/), tutoriel en français disponible [ici](http://tousleschats.free.fr/hermes/tuto/index.html) ;
* [Kate](http://kate-editor.org/ ), tutoriel en français disponible [ici](http://www.linuxpedia.fr/doku.php/kate).

jEdit est un très bon éditeur de texte graphique spécialement adapté à la programmation. Vim et Emacs sont des éditeurs de texte extrêmement puissants en pratique, mais assez compliqués, surtout pour un débutant ; ne les laissez pas de côté pour autant, ils ne peuvent que vous être utiles.

Maintenant, créez un fichier **test.c** (que vous pouvez mettre dans un dossier nommé « *prog* » dans votre dossier *home* par exemple) contenant le code suivant :

```c
#include <stdio.h>

int main(void)
{
    printf("Hello world!\n");
    return 0;
}
```

Afin de créer l’exécutable à partir du code source précédent, on fait comme ceci :

```console
gcc test.c
``` 

Ou bien encore :

```console
gcc *.c   # Le joker * permet de raccourcir la commande.
```

Un exécutable s'est créee : **a.out**, que l'on lance ainsi : 

```console
./a.out
```

Pour modifier le nom de l'exécutable, on utilise l’option **-o** comme ceci : 

```console
gcc test.c -o mon_executable
```

Comme on peut s'en douter, il existe énormément d’options de compilation différentes, si bien qu'on ne peux pas toutes les lister ici. Cependant, [ce tutoriel](http://www.siteduzero.com/tutoriel-3-31992-compilez-sous-gnu-linux.html) ainsi que vers [la documentation officielle](http://www.linux-kheops.com/doc/man/manfr/man-html-0.9/man1/gcc.1.html) sont là pour ça. Bien que ces pages contiennent des éléments avancés du C, elles peuvent servir à n'importe quel moment, d'où l'intérêt de les garder.

Il existe bien entendu d'autres compilateurs comme Comeau C/C++, une liste exhaustive étant impossible à faire.

*[GCC]: GNU Compiler Collection