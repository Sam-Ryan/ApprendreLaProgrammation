Avant de commencer à programmer, il nous faut aussi définir ce que nous allons programmer, autrement dit le type de programme que nous allons réaliser. Il existe en effet deux grands types de programmes : les programmes **graphiques** et les programmes **en console**.

Les programmes graphiques sont les plus courants et les plus connus puisqu’il n’y a pratiquement qu’eux sous Windows ou Mac OS X par exemple. Vous en connaissez énormément, peut-être sans le savoir : le lecteur de musique, le navigateur Internet, le logiciel de discussion instantanée, la suite bureautique, les jeux vidéos, ce sont tous des programmes graphiques, ou programmes GUI. En voici un exemple sous GNU/Linux :

![L'éditeur graphique GIMP est un programme graphique](/media/galleries/1501/3bb7ecca-f38e-4c21-8c9d-03969b5faf11.png.960x960_q85.jpg)

Cependant, écrire ce genre de programmes demande beaucoup de connaissances, ce qui nous manque justement pour l'instant. Aussi, nous allons devoir nous rabattre sur le deuxième type de programme : les programmes en console.

Les programmes console sont les premiers programmes, apparus en même temps que l’écran. Ils étaient très utilisés dans les années 1970 / 1980 (certains d’entre vous se souviennent peut-être de MS-DOS), mais ont fini par être remplacés par une interface graphique avec la sortie de Windows et de Mac OS. Cependant, ils existent toujours et redeviennent quelque peu populaires chez les personnes utilisant GNU/Linux ou un *BSD.

Voici un exemple de programme en console :

```console
12 - 7 =   5
Right!
9 - 5 =   4
Right!
1 + 5 =   6
Right!
3 + 3 =   6
Right!
5 + 4 =   9
Right!
10 + 9 =   19
Right!
16 - 10 =   6
Right!
9 - 1 =   8
Right!
18 - 10 =   8
Right!
3 + 3 =   6
Right!


Rights 10; Wrongs 0; Score 100%
Total time 16 seconds; 1.6 seconds per problem

Press RETURN to continue...
```

Ce sera le type de programme que nous allons apprendre à créer. Rassurez-vous, quand vous aurez fini le cours, vous aurez les bases pour apprendre à créer des programmes graphiques. Tout est possible.

*[GUI]: Graphical User Interface