Bien, après ces deux sections assez théoriques et rébarbatives, anticipons un peu sur le chapitre suivant et voyons un comment afficher la valeur de nos variables. Pour ce faire, nous allons avoir besoin d'une **fonction**.

Qu'est-ce qu'une fonction ? Il s'agit d'un morceau de code qui a un but, une *fonction* particulière et qui peut-être appelé à l'aide d'une référence, le plus souvent le nom de cette fonction. En l'occurrence, nous allons utiliser une fonction qui a pour objectif d'afficher du texte à l'écran : la fonction *printf*().

[[information]]
| Notez que depuis le début, vous utilisez une fonction : *main*().

Un exemple valant mieux qu'un long discours, voici un premier exemple :

```c
#include <stdio.h>


int main(void)
{
    printf("Bonjour tout le monde !\n");
    return 0;
}
```

Comme vous le voyez, nous **appelons** la fonction *printf*() (un appel de fonction est toujours suivi d'un groupe de parenthèses) avec comme argument un texte (il s'agit plus précisément d'une **chaîne de caractères** qui est toujours comprise entre deux guillemets double). Le `\n` est un caractère spéciale qui représente un retour à la ligne, cela est plus commode pour l'affichage.

# Les formats

Cependant, c'est bien joli d'afficher un texte, mais *quid* des valeurs de nos variables ? *Hé* bien, pour y parvenir, la fonction *printf*() met à notre disposition des **formats**. Ceux-ci sont en fait des sortes de repères au sein d'un texte qui indique à *printf*() que la valeur d'une variable est attendue à cet endroit. Voici un exemple pour une variable de type `int` :

```c
#include <stdio.h>


int main(void)
{
    int variable = 20;

    printf("%d\n", variable);
    return 0;
}
```

Nous pouvons voir que le texte de l'exemple précédent a été remplacé par `%d`, seul le `\n` été maintenu. Un format commence toujours par le symbole `%` et est suivi par une ou plusieurs lettres qui indiquent le type de données que nous souhaitons voir affiché. Cette suite de lettre est appelée un **indicateur de conversion**. En voici une liste non exhaustive :

Indicateur de conversion | Type attendu
------------------------ | ------------
c | **char**
hd | **short**
hi | **short**
d | **int**
i | **int**
ld | **long**
li | **long**
f | **float**
f | **double**
Lf | **double**