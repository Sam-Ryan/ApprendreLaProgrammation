Nous savons désormais déclarer, affecter et initialiser une variable, mais que diriez-vous d’apprendre à réaliser des opérations dessus ? Il est en effet possible de réaliser des calculs sur nos variables, comme les additionner, les diviser voire même des opérations plus complexes. C’est le but de cette sous-partie. Nous allons donc enfin transformer notre ordinateur en grosse calculette programmable ! Cette partie est importante, donc même si vous détestez les mathématiques, vous devez la lire.

# Calculs de base

Le langage C fournit 5 opérations de base sur nos variables.
     
* L'addition **+**.       
* La soustraction **-**.       
* La multiplication *****.       
* La division **/**.        
* Le modulo **%** (le reste d’une division euclidienne).

Le langage C fournit aussi d’autres fonctions mathématiques préprogrammées, mais qu’on ne peut pas encore utiliser à ce stade. Nous devrons donc reporter à plus tard l’utilisation de fonctions mathématiques plus complexes. Si jamais vous devez utiliser une fonction mathématique plus complexe, il faudra la programmer, pour le moment. 

Commençons par détailler ces 5 opérations de base.

## Addition, soustraction et multiplication

C’est tout simple : pour faire notre calcul, il suffit d’assigner le résultat du calcul à une variable : 

```c
int somme, difference, produit;

somme = 2 + 3;   /* 5 */
difference = 8 - 12;   /* -4 */
produit = 6 * 7;   /* 42 */
```

On pourrait multiplier les exemples à l’infini, je pense néanmoins que vous avez compris le concept. 

## Division

La division en informatique est différente de celle en mathématiques. Si je vous dis $\frac{15}{4}$, vous en déduisez que le quotient est 3,75. Pourtant, le résultat de celle-ci est 3 en langage C.

```c
int division = 15 / 4;
```

Suite à la lecture du chapitre suivant, vous pourrez vérifier cette affirmation en affichant la valeur de cette opération, mais vous n’en êtes pas encore là, et je vous défends de vous y rendre avant la fin de ce chapitre.

Pour l’ordinateur, le résultat de ```15 / 4``` est bien ```3```. Pourquoi ? Parce qu’on lui a demandé de faire une division d’entiers (appelée **division euclidienne**), donc il répond par des entiers. Si l’on veut afficher le résultat complet (à nos yeux), il faut l’indiquer à l’ordinateur. Comment faire ? Essayez de trouver la solution tout seul.

Un indice ? Pensez aux flottants.

La solution :

```c
double division = 15. / 4.;   /* même si pour nous, c’est la même chose que 15 / 4 */
```

Même si pour nous c’est intuitif, pour l’ordinateur il faut bien préciser si ce sont des entiers ou des flottants.

## Modulo

Le modulo est un peu le complément de la division puisqu’il permet de connaitre le reste d’une division euclidienne. C’est une opération de base aux yeux de l’ordinateur, même si elle est assez peu connue. Un petit code pour la route :

```c
int modulo = 11 % 4;
```

Ici, le résultat de cette instruction est 3, car $11 = 2 \times 4 + 3$. Le modulo est la réponse au problème de la division d’entiers.

# Opérations entre variables

Le principe est tout simple : au lieu d’opérer sur des nombres, on opère sur des variables. Ainsi on peut faire les mêmes opérations sur des variables : 

```c
var = var1 + var2;
d = c / b * a;
```

On peut ainsi rajouter autant de variables que l’on veut, et même mélanger avec des nombres :

```c
d = c / b * a - s + 7 % 2
```

Cependant, il faut faire attention à la priorité des opérateurs : comme en mathématiques, certains opérateurs passent avant d’autres : ```* / %``` ont une priorité supérieure à ```+ -```.

Dans ce code : 

```c
x = nombre + y * 4;
```

C’est ```y * 4``` qui sera exécuté d’abord, puis on ajoutera ```nombre``` au résultat. Faites donc attention, sous peine d’avoir de mauvaises surprises. Dans le doute, mettez des parenthèses.

## Les Expressions combinées

Comment vous y prendriez-vous pour multiplier une variable par trois ? La solution « naïve » serait de faire :

```c
variable = variable * 3;
```

Cependant, c’est long, fatigant, et peut vite devenir fastidieux si l'on fait beaucoup d’opérations de ce genre. On a donc inventé des techniques permettant de raccourcir notre code : les **raccourcis**. Ces raccourcis fonctionnent pour toutes les opérations arithmétiques de base. Ainsi, pour faire la même opération que le code précédent, on peut raccourcir ainsi :

```c
variable *= 3;
```

Ce code concis marche exactement comme le précédent. Et le principe est valable pour toutes les opérations, pour n’importe quelle valeur :

```c
variable += 2;
variable -= 9;
variable /= 8;
variable %= 4;
```

Cependant, il existe encore deux autres raccourcis très fréquemment utilisés. 

## Incrémentation et décrémentation

Ce sont deux opérations qui, respectivement, ajoute ou enlève 1 à une variable. On pourrait utiliser les raccourcis vus juste avant : 

```c
variable += 1;
variable -= 1;
```

Cependant, on a inventé de nouveaux raccourcis pour ces deux opérations, car elles sont très utilisées (vous comprendrez vite pourquoi dans les prochains chapitres). Ces deux raccourcis sont les suivants : 

```c
variable++;
```

Pour l’**incrémentation** (on ajoute 1) et :

```c
variable--;
```

pour la **décrémentation** (on enlève 1). Ces deux lignes sont parfaitement équivalentes aux deux premières. Elles permettent simplement de raccourcir le code. Ce que je viens de vous montrer s’appelle l’[in/dé]crémentation **postfixée**. En effet, il est aussi possible de faire une [in/dé]crémentation **pré-fixée** : le signe est alors avant la variable et non après : 

```c
++variable;
--variable;
```

Il y a une subtile différence entre les deux formes. Une [in/dé]crémentation pré-fixée change la valeur de l’expression avant d'envoyer la valeur, alors qu’une [in/dé]crémentation post-fixée renvoie la valeur et la modifie ensuite. Petit exemple pour bien comprendre : si j'ai une variable a qui vaut 5, ```++a``` incrémentera immédiatement la variable a, qui vaudra alors 6. 

```c
int a = 5 ;
int b = ++a ; /* ici, b vaudra 6 */
```

Par contre, ```a++``` attendra avant d'incrémenter la variable : celle-ci sera incrémentée après la prochaine "utilisation". 

```c
int a = 5 ;
int b = a++ ; /* ici, b vaudra 5, et a sera mit à 6 une fois que 
               la valeur de a++ est recopiée dans b */
```

Fondamentalement, utiliser l’une ou l’autre des deux formes ne change pas grand chose, sauf dans quelques cas particuliers. Dans la plupart des cas, les programmeurs utilisent la forme postfixée (```i++```) en permanence. Il n'y a pas vraiment de raisons valables pour faire cela à l'heure actuelle, mais cette pratique est monnaie courante. Aussi, ne soyez pas étonné de voir des codes utilisant la forme post-fixée alors qu'une forme préfixée aurait été plus adéquate.

# Les conversions de type

La conversion de type est une opération qui consiste à changer le type d’une variable en un autre. Je peux ainsi convertir une variable de type ```float``` en type ```int```, par exemple. Il existe deux types de conversions : les **conversions explicites** et les **conversions implicites**.

## Les conversions explicites

Ce sont des conversions voulues et demandées par le programmeur. Elles se déclarent en suivant ce modèle :

```console
(<Type>) <Expression>
```

Voici par exemple un code où l’on demande explicitement la conversion d’un ```double``` en ```int```.

```c
int a;
const double pi = 3.14;

a = (int) pi;
```

La valeur de ```pi``` reste inchangée, elle vaudra toujours 3.14 dans la suite du programme. Par contre, ```a``` vaut maintenant 3, puisque le flottant a été converti en entier. Expliciter une conversion peut nous servir quand on veut forcer le résultat d’une opération par exemple. Imaginons que nous voulons faire une division, mais que les deux opérandes soient de type ```int```.

```c
int a, b;
double c;

a = 5;
b = 9;

c = a / b;
```

Vu qu’on fait une division euclidienne, le résultat sera tronqué. Si on veut avoir un résultat avec la partie décimale, il suffit de faire une conversion explicite d’un des deux opérandes en ```double``` :

```c
c = (double) a / b;
/* ou */
c = a / (double) b;
```

## Les conversions implicites

Ce sont des conversions que fait le compilateur tout seul, sans que l’on ait demandé quoi que ce soit. En général, ça ne gêne pas le programmeur, mais ça peut parfois être problématique si la conversion n’était pas voulue. Par exemple, si l’on reprend le code précédent, il y aura toujours une conversion.

```c
int a;
const double pi = 3.14;

/* Il y a conversion implicite de double en int, mais rien 
n’est précisé, c’est le compilateur qui fait ça de lui-même. */
a = pi;
```

Cependant, les conversions amènent parfois à des pertes d’information si l’on n’y prend pas garde.

## Perte d’information

Une perte d’information survient quand on convertit le type d’une variable en un autre type plus petit et que celui-ci ne peut pas contenir la valeur reçue. Si, par exemple, je convertis un ```double``` de 100 chiffres en un ```short```, il y a perte d’information, car le type ```short``` ne peut pas contenir 100 chiffres. La règle à retenir est la suivante :

> Si on convertit un type T vers un type S plus petit, il y a perte d’information.
> *-- Règle des conversions*

Les conversions, et surtout les conversions implicites qui peuvent être vicieuses, doivent être manipulées avec précaution, au risque de tomber sur des valeurs fausses en cas de perte d’information. Nous découvrirons d’ici quelques chapitres comment connaitre la taille d’un type T pour éviter ces pertes d’information.