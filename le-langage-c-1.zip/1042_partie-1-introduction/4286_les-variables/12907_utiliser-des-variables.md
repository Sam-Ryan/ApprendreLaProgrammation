Nous savons désormais déclarer, affecter et initialiser une variable, mais que diriez-vous d’apprendre à réaliser des opérations dessus ? Il est en effet possible de réaliser des calculs sur nos variables, comme les additionner, les diviser voire même des opérations plus complexes. C’est le but de cette sous-partie. Nous allons donc enfin transformer notre ordinateur en grosse calculatrice programmable !

# Calculs de base

Le langage C nous permets de réaliser cinq opérations de base :
     
* l'addition (opérateur `+`) ;       
* la soustraction (opérateur `-`) ;       
* la multiplication (opérateur `*`) ;       
* la division (opérateur `/`) ;        
* la division entière ou euclidienne (opérateur `%`, aussi appelé « modulo »).

Le langage C fournit d’autres fonctions mathématiques et d'autres opérateurs, mais il est encore trop tôt pour vous les présenter.

## Addition, soustraction et multiplication

C’est tout simple : pour faire notre calcul, il suffit d’assigner le résultat du calcul à une variable : 

```c
int somme, difference, produit;

somme = 2 + 3;   /* 5 */
difference = 8 - 12;   /* -4 */
produit = 6 * 7;   /* 42 */
```

## Division

La division en informatique est différente de celle en mathématiques. Si nous vous disons $\frac{15}{4}$, vous en déduisez que le quotient est 3,75. Pourtant, le résultat de celle-ci est 3 en langage C.

```c
int division = 15 / 4;
```

Suite à la lecture du chapitre suivant, vous pourrez vérifier cette affirmation en affichant la valeur de cette opération, mais vous n’en êtes pas encore là, et nous vous défendons de vous y rendre avant la fin de ce chapitre ! :pirates:

Pour l’ordinateur, le résultat de ```15 / 4``` est bien ```3```. Pourquoi ? Parce qu’on lui a demandé de faire une division d’entiers (appelée **division euclidienne**), donc il répond par des entiers. Si nous voulons afficher le résultat complet (à nos yeux), il faut l’indiquer à l’ordinateur. Comment faire ? Essayez de trouver la solution tout seul.

Un indice ? Pensez aux flottants.

La solution :

```c
double division = 15. / 4.;   /* même si pour nous, c’est la même chose que 15 / 4 */
```

Même si pour nous c’est intuitif, pour l’ordinateur il faut bien préciser s'il s'agit d'entiers ou de flottants.

### Modulo

Le modulo est un peu le complément de la division puisqu’il permet de connaitre le reste d’une division euclidienne. C’est une opération de base aux yeux de l’ordinateur, même si elle est assez peu connue.

```c
int modulo = 11 % 4;
```

Ici, le résultat de cette instruction est 3, car $11 = 2 \times 4 + 3$. Le modulo est la réponse au problème de la division d’entiers.

## Opérations entre variables

Le principe est tout simple : au lieu d’opérer sur des nombres, nous opèrons sur des variables. Ainsi nous pouvons faire les mêmes opérations sur des variables : 

```c
var = var1 + var2;
d = c / b * a;
```

Nous pouvons ainsi ajouter autant de variables que nous le souhaitons, et même les mélanger avec des nombres :

```c
d = c / b * a - s + 7 % 2
```

Cependant, il est nécessaire de faire attention à la priorité des opérateurs : comme en mathématiques, certains opérateurs passent avant d’autres : ```* / %``` ont une priorité supérieure à ```+ -```.

Dans ce code : 

```c
x = nombre + y * 4;
```

C’est ```y * 4``` qui sera exécuté d’abord, puis la valeur de *nombre* sera ajouté au résultat. Faites donc attention, sous peine d’avoir de mauvaises surprises. Dans le doute, mettez des parenthèses.

# Les raccourcis

Comment vous y prendriez-vous pour multiplier une variable par trois ? La solution « naïve » serait de faire :

```c
variable = variable * 3;
```

Cependant, ceci implique de répéter deux fois le nom d'une variable. En vue d'éviter cette répétition, il existe des opérateurs fusionnant les deux opérations. Ainsi, pour faire la même opération que le code précédent, nous pouvons écrire :

```c
variable *= 3;
```

Ce code concis fonctionne exactement comme le précédent. Et le principe est valable pour toutes les opérations, pour n’importe quelle valeur :

```c
variable += 2;
variable -= 9;
variable /= 8;
variable %= 4;
``` 

## Incrémentation et décrémentation

**L'incrémentation** et la **décrémentation** sont deux opérations qui, respectivement, ajoute ou enlève 1 à une variable. Avec les opérateurs vu précédemment, cela se traduit par :

```c
variable += 1;
variable -= 1;
```

Cependant, ces deux opérations étant très souvent utilisée, elles ont droit chacune à un opérateur spécifique (en fait, deux) :

```c
/* Incrémentation */
variable++;
++variable;
```

```c
/* Décrémentation */
variable--;
--variable;
```

Les opérateurs peuvent être placés *avant* ou *après* le nom de la variable et le résultat sera le même : la valeur de la variable *variable* sera augmentée ou diminuée de un. **Cependant**, il y a une subtile différence entre les deux utilisations : une [in/dé]crémentation pré-fixée change la valeur de l’expression avant d'envoyer la valeur, alors qu’une [in/dé]crémentation post-fixée renvoie la valeur et la modifie ensuite. Petit exemple pour bien comprendre : si j'ai une variable a qui vaut 5, ```++a``` incrémentera immédiatement la variable a, qui vaudra alors 6. 

```c
int a = 5 ;
int b = ++a ; /* ici, b vaudra 6 */
```

Par contre, ```a++``` attendra avant d'incrémenter la variable : celle-ci sera incrémentée après la prochaine "utilisation". 

```c
int a = 5 ;
int b = a++ ; /* ici, b vaudra 5, et a sera mit à 6 une fois que 
               la valeur de a++ est recopiée dans b */
```

Fondamentalement, utiliser l’une ou l’autre des deux formes ne change pas grand chose, sauf dans quelques cas particuliers. Dans la plupart des cas, les programmeurs utilisent la forme postfixée (```i++```) en permanence. Il n'y a pas vraiment de raisons valables pour faire cela à l'heure actuelle, mais cette pratique est monnaie courante. Aussi, ne soyez pas étonné de voir des codes utilisant la forme post-fixée alors qu'une forme préfixée aurait été plus adéquate.

# Les conversions de type

La conversion de type est une opération qui consiste à changer le type d’une variable en un autre. Je peux ainsi convertir une variable de type ```float``` en type ```int```, par exemple. Il existe deux types de conversions : les **conversions explicites** et les **conversions implicites**.

## Les conversions explicites

Ce sont des conversions voulues et demandées par le programmeur. Elles se déclarent en suivant ce modèle :

```console
(<Type>) <Expression>
```

Voici par exemple un code où l’on demande explicitement la conversion d’un ```double``` en ```int```.

```c
int a;
const double pi = 3.14;

a = (int) pi;
```

La valeur de ```pi``` reste inchangée, elle vaudra toujours 3.14 dans la suite du programme. Par contre, ```a``` vaut maintenant 3, puisque le flottant a été converti en entier. Expliciter une conversion peut nous servir quand on veut forcer le résultat d’une opération par exemple. Imaginons que nous voulons faire une division, mais que les deux opérandes soient de type ```int```.

```c
int a, b;
double c;

a = 5;
b = 9;

c = a / b;
```

Vu qu’on fait une division euclidienne, le résultat sera tronqué. Si on veut avoir un résultat avec la partie décimale, il suffit de faire une conversion explicite d’un des deux opérandes en ```double``` :

```c
c = (double) a / b;
/* ou */
c = a / (double) b;
```

## Les conversions implicites

Ce sont des conversions que fait le compilateur tout seul, sans que l’on ait demandé quoi que ce soit. En général, ça ne gêne pas le programmeur, mais ça peut parfois être problématique si la conversion n’était pas voulue. Par exemple, si l’on reprend le code précédent, il y aura toujours une conversion.

```c
int a;
const double pi = 3.14;

/* Il y a conversion implicite de double en int, mais rien 
n’est précisé, c’est le compilateur qui fait ça de lui-même. */
a = pi;
```

Cependant, les conversions amènent parfois à des pertes d’information si l’on n’y prend pas garde.

## Perte d’information

Une perte d’information survient quand on convertit le type d’une variable en un autre type plus petit et que celui-ci ne peut pas contenir la valeur reçue. Si, par exemple, je convertis un ```double``` de 100 chiffres en un ```short```, il y a perte d’information, car le type ```short``` ne peut pas contenir 100 chiffres. La règle à retenir est la suivante :

> Si on convertit un type T vers un type S plus petit, il y a perte d’information.
> *-- Règle des conversions*

Les conversions, et surtout les conversions implicites qui peuvent être vicieuses, doivent être manipulées avec précaution, au risque de tomber sur des valeurs fausses en cas de perte d’information. Nous découvrirons d’ici quelques chapitres comment connaitre la taille d’un type T pour éviter ces pertes d’information.