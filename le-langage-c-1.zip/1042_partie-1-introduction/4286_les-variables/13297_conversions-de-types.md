La conversion de type est une opération qui consiste à changer le type d’une variable en un autre. Je peux ainsi convertir une variable de type ```float``` en type ```int```, par exemple. Il existe deux types de conversions : les **conversions explicites** et les **conversions implicites**.

# Les conversions explicites

Ce sont des conversions voulues et demandées par le programmeur. Elles s'utilisent suivant ce modèle :

```text
(<Type>) <Expression>
```

Voici par exemple un code où l’on demande explicitement la conversion d’un ```double``` en ```int```.

```c
int a;
const double pi = 3.14;

a = (int) pi;
```

La valeur de *pi* reste inchangée, elle vaudra toujours 3.14 dans la suite du programme. Par contre, *a* vaut maintenant 3, puisque la valeur de *pi* a été convertie en `int`. 

# Les conversions implicites

Ce sont des conversions que fait le compilateur tout seul, sans que vous ayez demandé quoi que ce soit. En général, cela n'est pas gênant, mais cela peut parfois être problématique si celle-ci n’était pas voulue. Par exemple, si nous reprenons le code précédent, il y aura toujours une conversion.

```c
int a;
const double pi = 3.14;

/* Il y a conversion implicite de double en int, mais rien 
n’est précisé, c’est le compilateur qui fait ça de lui-même. */
a = pi;
```

Cependant, les conversions amènent parfois à des pertes d’information si l’on n’y prend pas garde.

# Perte d’information

Une perte d’information survient quand le type d’une variable est converti vers un autre type ayant une capacité plus faible et que celui-ci ne peut pas contenir la valeur d'origine. Si, par exemple, je convertis un ```double``` de 100 chiffres en un ```short```, il y a perte d’information, car le type ```short``` ne peut pas contenir 100 chiffres. Retenenez donc bien cette assertion : une conversion d'un type T vers un type S de plus faible capacité entraîne une perte d'information.

Les conversions, et surtout les conversions implicites qui peuvent être vicieuses, doivent être manipulées avec précaution, au risque de tomber sur des valeurs fausses en cas de perte d’information. Nous découvrirons d’ici quelques chapitres comment connaitre la taille d’un type pour éviter ces pertes d’information.