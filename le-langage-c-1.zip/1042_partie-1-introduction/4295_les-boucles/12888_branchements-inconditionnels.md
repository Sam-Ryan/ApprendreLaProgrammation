Dans ce chapitre, ainsi que dans le chapitre précédent, on a vu comment modifier l’exécution de notre programme en fonction de certaines conditions. Ainsi, notre programme peut faire autre chose que mécaniquement passer à l'instruction suivante et peut recommencer son exécution à un autre endroit, suivant qu'une condition soit réalisée ou pas. Pour ce faire, on utilise des structures de contrôles. Au niveau de notre processeur, ces structures de contrôle sont fabriquées avec ce qu'on appelle des instructions de branchement conditionnelles : ce sont des instructions qui vont faire reprendre notre programme à un autre endroit si une condition est vraie, et qui ne font rien sinon. Ceux qui veulent savoir comment on utilise ces branchements pour fabriquer ces structures de contrôles peuvent aller lire le début de ce tutoriel (les trois premières sous-parties) : [Structures de contrôle en assembleur](http://www.siteduzero.com/tutoriel-3-563628-un-peu-de-programmation.html).

Mais la plupart du temps, notre ordinateur supporte aussi des instructions de branchement inconditionnels. Ces instructions vont faire reprendre l’exécution de notre programme à un endroit bien précis, quelle que soit la situation. Celles-ci n'agissent pas suivant ce que leur dit une condition, mais vont toujours faire reprendre notre programme à un endroit bien précis. Alors certes, il s'agit d'instructions de notre processeur, qui sont souvent inaccessibles en C. Mais le langage C fournit quelques fonctionnalités qui fonctionnent exactement comme des branchements inconditionnels. Ils sont souvent utilisés de concert avec nos structures de contrôle, pour les améliorer, ou pour qu'elles fassent ce qu'il faut. 

Il existe ainsi trois grands branchements inconditionnels en C :
	
* celui qui permet de passer au tour de boucle suivant, sans finir celui en cours : ```continue``` ;
* celui qui permet (entre autres) de quitter la boucle en cours : ```break``` ;	
* celui qui permet de sauter carrément dans un autre morceau de code ```goto```.

Voyons un peu plus en détail ces branchements inconditionnels.

# break

Nous avons déjà étudié le rôle de ```break``` au sein de l'instruction ```switch``` : il permettait simplement de quitter notre ```switch``` pour reprendre immédiatement après. Eh bien, sachez qu'on peut aussi l'utiliser avec des boucles. Son but ? Permettre de quitter une boucle (ou un ```switch```, comme on l'a déjà vu), pour reprendre immédiatement après. 

## Boucle ou structure de contrôle simple

Pour illustrer ça, prenons un algorithme tout simple :

```console
Pour (i = 0 ; i < 10 ; i++)
{
     Si i == 5
        Quitter la boucle;

     Sinon afficher i;
}
```

Notre but est de quitter si jamais la variable *i* atteint la valeur 5. Alors pour vous entrainer, essayez de coder vous-même la boucle sans regarder la solution.

[secret]{
```c
int i;

for (i = 0 ; i < 10 ; i++)
{
    if (i == 5)
        break;

    printf("i = %d\n", i);
}
```

Et voici le résultat à l'exécution :

```console
i = 0
i = 1
i = 2
i = 3
i = 4
```

L'exécution de la boucle a bien été arrêtée par ```break```. 
}

## Structures de contrôle imbriquées

Il est important de préciser que ```break``` ne permet de sortir que d'une seule boucle (ou d'une seule structure de contrôle de type ```if```, ```else if```, etc.). Ainsi, dans le cas de boucles imbriquées, on reviendra à la précédente.

```c
#include <stdio.h>

int main(void)
{
    int i;

    for (i = 0; i < 10; i++)
    {
        printf("[for] i = %d\n", i);

        while (i < 5)
        {
            if (i == 4)
                break;

            printf("[while] i = %d\n", i);
            i++;
        }
    }

    return 0;
}
```
```console
[for] i = 0
[while] i = 0
[while] i = 1
[while] i = 2
[while] i = 3
[for] i = 5
[for] i = 6
[for] i = 7
[for] i = 8
[for] i = 9
```

Dans ce code, il y a une boucle ```for``` qui contient une boucle ```while```. Au départ, *i* vaut 0, et ainsi la condition est vraie et on rentre dans la boucle. On affiche la variable, et dès que *i* vaut 4, on quitte la boucle. Comme la condition du ```while``` est fausse, on ne rentre plus dedans, mais la boucle ```for``` continue de s'exécuter, et affiche les cinq valeurs suivantes de *i*. 

# continue

Le deuxième mot-clef est ```continue```. Son rôle est d'arrêter l'itération en cours et de passer à la suivante. En gros, on peut dire que ```continue``` permet de terminer le tour de boucle en cours, et fait reprendre immédiatement au tour de boucle suivant. Prenons le même code algorithme que précédemment : 

```console
Pour (i = 0 ; i < 10 ; i++)
{
     Si i == 5
        continue;

     Sinon afficher i;
}
```

Qui est capable me dire ce que le code une fois traduit en C affichera ? 

[secret]{
```console
i = 0
i = 1
i = 2
i = 3
i = 4
i = 6
i = 7
i = 8
i = 9
```
}

On remarque que quand *i* a été mis à 5, la condition ```if (i == 5)``` est devenue vraie et ```continue``` a zappé l'itération en cours.

# goto

Le troisième et dernier mot-clef que je souhaite vous présenter est ```goto```. Ce mot-clef sert à sauter vers une autre partie du code. Il permet de reprendre l’exécution du programme à l'endroit qu'on veut. 

Pour préciser l'endroit où l'on veut reprendre notre programme, le langage C fournit ce qu'on appelle des **labels**. Ces labels permettent de nommer une ligne de code, une instruction particulière, en lui donnant un nom. Pour identifier la ligne de code à laquelle on souhaite faire reprendre notre programme, il suffit ainsi d'ajouter un label à notre ligne de code, en rajoutant le nom du label suivi d'un caractère : devant notre instruction. Pour reprendre l’exécution du programme à une ligne de code bien précise, il suffit d'utiliser le mot-clé ```goto```, suivi du nom du label de la ligne de code correspondante.

## Exemple

Voici un algorithme tout simple :

```console
Pour (i = 0 ; i < 10 ; i++)
{
     Si i == 5
        Sautez à l'étiquette Erreur;

     Sinon afficher i;
}

Erreur:
     Afficher que i vaut 5
```

Dans notre exemple, le label n'est autre que *erreur*. Ce label est défini plus bas dans le code : il est attaché à notre instruction qui affichera à l'écran que la variable vaut 5. Essayez de transposer cet algorithme en C.

[secret]{
```c
int i;

for (i = 0 ; i < 10 ; i++)
{
     if (i == 5)
         goto Erreur;

     printf("i = %d\n", i);
}

Erreur:
     puts("\ni vaut 5");
```

Et voici le résultat à l'exécution :

```console
i = 0
i = 1
i = 2
i = 3
i = 4

i vaut 5
```
}

On voit bien que quand *i* atteint la valeur 5, le programme saute au label *Erreur* et affiche bien *i vaut 5*. Le label est ici après ```goto```, mais peut très bien se trouver avant.

## Goto Statement Considered Harmful

Il me faut cependant vous prévenir : de nos jours, il est tout de même assez rare qu'on utilise des ```goto```, et certains langages de programmation ne permettent même pas de l'utiliser !

Pourquoi ? Eh bien en fait, il faut savoir qu'autrefois, ```goto``` était assez relativement utilisé par les programmeurs. Quand je dis autrefois, c'était avant les années 1960-1970. Nul doute que vous n'étiez pas encore nés à cette époque. À cette époque, on n'utilisait pas vraiment de structures de contrôles, et les programmeurs créaient des programmes en utilisant pas mal de ```goto``` pour compenser. Mais cet usage du ```goto``` a fini par être de plus en plus critiqué au fil du temps.

Première attaque contre le ```goto``` : en 1966, deux mathématiciens, Böhm et Jacopini, prouvèrent que l'on pouvait se passer totalement de ```goto``` en utilisant des structures de contrôle. La déchéance de ```goto``` était en marche. 

Dans notre exemple vu plus haut, ```goto``` est effectivement superflu et peux facilement être remplacé par autre chose.

```c
int i;

/* code plus court et plus lisible */
for (i = 0 ; i < 10 ; i++)
{
     if (i == 5)
     {
         puts("i vaut 5");
         break;
     }

     printf("i = %d\n", i);
}
```

Mais certains programmeurs continuèrent d'utiliser du ```goto```, en disant que c'était plus facile de programmer ainsi. Alors vint le coup de grâce final ! En mars 1968, un informaticien du nom d'*Edsger Dijkstra* écrivit un article qui fit sensation. Cet article portait le nom suivant : *Goto Statement Considered Harmful*. Dans cet article, Dijkstra porta de nombreuses critiques sur le ```goto```, et préconisait de remplacer celui-ci par une utilisation judicieuse des structures de contrôles qu'on vient de voir dans ce chapitre et dans le chapitre précédent. Cet article lança un véritable débat dans les milieux académiques ainsi que parmi les programmeurs. Au final : ```goto``` perdit la bataille, l'usage des structures de contrôle usuelles se répandit dans le monde comme une trainée de poudre.

Le principal reproche qui est fait à ce pauvre ```goto``` est qu'il a tendance à rendre le code illisible. En comparaison, un code dans lequel on trouve des structures de contrôle est beaucoup plus compréhensible par un humain. C'est pour ce genre de raisons que l'usage de ```goto``` en C est très fortement déconseillé, en particulier pour les débutants.

Je vous parle de ```goto``` par souci d'exhaustivité, mais sachez qu'il est aujourd'hui rarement utilisé. L'un des très rares cas dans lesquels ce mot-clef prend son intérêt, c'est la gestion des erreurs. Cependant, nous ne verrons pas ce cas dans ce tutoriel. En attendant de découvrir comment bien utiliser ```goto```, je vous recommande de ne pas l'utiliser.