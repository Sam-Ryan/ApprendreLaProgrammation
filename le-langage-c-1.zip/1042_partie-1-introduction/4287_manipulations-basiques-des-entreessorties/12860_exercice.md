Vous êtes prêts pour un exercice ? Essayez de coder une minicalculatrice qui :

* Dit bonjour ;
* Demande deux nombres entiers à l’utilisateur ;	
* Les additionne, les soustrait, les multiplie et les divise (au millième près) ;	
* Dit au revoir.

Un exemple d'utilisation pourrait être :

```text
Bonjour !
Veuillez saisir le premier nombre : 4
Veuillez saisir le deuxième nombre : 7
Calculs :
        4 + 7 = 11
        4 - 7 = -3
        4 * 7 = 28
        4 / 7 = 0.571
Au revoir !
```

Une petite remarque avant de vous laissez faire : nous avons vu qu'une division ne donnait un résultat flottant que si l'un des opérandes est de type flottant (comme dans l'expression `5. / 2.`). Cependant, nous n'avons pas vu comment convertir une variable d'un type vers un autre. Pour ce faire, il est nécessaire d'employer l'opérateur de conversion qui prends la forme : `(type)`. Par exemple, comme ceci : `a / (double)b`.

Bien, vous avez maintenant toutes les cartes en main donc : au boulot ! :)

[[secret]]
| ```c
| #include <stdio.h>
|
|
|int main(void)
|{
|    int a;
|    int b;
| 
|    printf("Bonjour !\n");
| 
|    /* Nous demandons deux nombres à l'utilisateur */
|    printf("Veuillez saisir le premier nombre : ");
|    scanf("%d", &a);
|    printf("Veuillez saisir le deuxième nombre : ");
|    scanf("%d", &b);
|
|    /* Puis nous effectuons les calculs */
|    printf("Calculs :\n");
|    printf("\t%d + %d = %d\n", a, b, a + b);
|    printf("\t%d - %d = %d\n", a, b, a - b);
|    printf("\t%d * %d = %d\n", a, b, a * b);
|    printf("\t%d / %d = %.3f\n", a, b, a / (double)b);
|    printf("Au revoir !");
|    return 0; 
|}
|```

Vous y êtes arrivé sans problème ? Bravo ! Dans le cas contraire, ne vous inquiétiez pas, ce n'est pas grave. Relisez bien tous les points qui ne vous semblent pas clairs et ça devrait aller mieux.