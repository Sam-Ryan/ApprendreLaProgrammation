Jusqu'à présent, nous nous sommes contenter d'afficher du texte et de manipuler très légèrement les variables. Voyons à présent comment nous pouvons réaliser quelques opérations de base. Le langage C nous permets d'en réaliser cinq :
     
* l'addition (opérateur `+`) ;       
* la soustraction (opérateur `-`) ;       
* la multiplication (opérateur `*`) ;       
* la division (opérateur `/`) ;        
* la division entière ou euclidienne (opérateur `%`, aussi appelé « modulo »).

[[information]]
| Le langage C fournit bien entendu d’autres fonctions mathématiques et d'autres opérateurs, mais il est encore trop tôt pour vous les présenter.

# Addition, soustraction et multiplication

C’est tout simple :

```c
#include <stdio.h>


int main(void)
{
    printf("2 + 3 = %d\n", 2 + 3);
    printf("8 - 12 = %d\n", 8 - 12);
    printf("6 x 7 = %d\n", 6 * 7);
    return 0;
}
```

```text
2 + 3 = 5
8 - 12 = -4
6 x 7 = 42
```

# Le type des expressions

Vous remarquerez que nous utilisons directement une expression (`2 + 3` par exem
ple) comme argument à la place d'une variable. Rien de bien surprenant me direz-vous... À un détail près : pourquoi l'indicateur de format est `d` ? Cela veut-il dire que le type de cette expression est `int` ?

*Hé* bien, oui. Tout comme les variables, les expressions ont un type. Ce dernier dépend toutefois du type des éléments qui la compose. En l'occurrence, une constante entière comme `2` ou `3` est par défaut de type `int`. Le résultat d'une somme, par exemple, sera donc également de type `int`. Les constantes flottantes comme `5.` ou `78.0` sont, elles, de type `double` et le résultat d'une opération sera alors de type `double`.

[[question]]
| D'accord, mais si j'additionne un `int` avec un `double`, cela me donne quoi ?

Heureusement pour nous, la norme a prévu ces différents cas et à fixer des règles :

* si une opérande est de type `long double`, le résultat est de type `long double` ; si non
* si une opérande est de type `double`, le résultat est de type `double` ; si non
* si une opérande est de type `float`, le résultat est de type `float` ; si non
* si une opérande est de type `unsigned long`, le résultat est de type `unsigned long`; si non
* si une opérande est de type `long`, le résultat est de type `long`; si non
* si une opérande est de type `unsigned int`, le résultat est de type `unsigned int`; si non
* le résultat est de type `int`.

[[question]]
| *Heu*... D'accord, mais vous venez de dire que les constantes entières étaient de type `int` et que les constantes flottantes étaient de type `double`. Du coup, je fais comment pour obtenir une constante d'un autre type ?

À l'aide d'un suffixe. Celui-ci se place à la fin de la constante et permet de modifier son type. En voici la liste :

Type | Suffixe
---- | -------
u ou U | **unsigned**
l ou L | **long**
f ou F | **float**
l ou L | **long double**

[[information]]
| Notez que les suffixes `L` (ou `l`) et `U` (ou `u`) peuvent être combinés.

Allez, un petit récapitulatif :

```c
#include <stdio.h>


int main(void)
{
    printf("78.56 + 5 = %Lf\n", 78.56L + 5);
    printf("5678 + 2.2 = %f\n", 5678L + 2.2);
    printf("2 + 5 = %lu\n", 2L + 5UL);
    return 0;
}
```

```text
78.56 + 5 = 83.560000
5678 + 2.2 = 5680.200000
2 + 5 = 7
```

[[information]]
| Nous vous conseillons d'opter pour les lettres majuscules qui ont l'avantage d'être plus lisible.

# Division

La division en informatique est différente de celle en mathématiques. Si nous vous disons $\frac{15}{4}$, vous en déduisez que le quotient est 3,75. Pourtant, le résultat de celle-ci est 3 en langage C.

```c
printf("15 / 4 = %d\n", 15 / 4);
```

```text
15 / 4 = 3
```

Pour l’ordinateur, le résultat de ```15 / 4``` est bien ```3```. Pourquoi ? Parce que nous lui avons demandé de faire une division d’entiers (appelée **division euclidienne**), donc il répond par des entiers. Si nous voulons afficher le résultat complet (à nos yeux), il faut l’indiquer à l’ordinateur. Comment faire ? Essayez de trouver la solution tout seul.

Un indice ? Pensez aux flottants.

La solution :

```c
printf("15 / 4 = %f\n", 15. / 4.);   /* même si pour nous, c’est la même chose que 15 / 4 */
```

```text
15 / 4 = 3.750000
```

Même si pour nous c’est intuitif, pour l’ordinateur il faut bien préciser s'il s'agit d'entiers ou de flottants.

# Modulo

Le modulo est un peu le complément de la division puisqu’il permet de connaitre le reste d’une division euclidienne. C’est une opération de base aux yeux de l’ordinateur, même si elle est assez peu connue.

```c
printf("11 % 4 = %d\n", 11 % 4);
```

```text
11 % 4 = 3
```

Ici, le résultat de cette instruction est 3, car $11 = 2 \times 4 + 3$. Le modulo est la réponse au problème de la division d’entiers.