# Présentation

Pour terminer ce chapitre, un petit apparté sur deux indicateurs de conversions un peu particulier : `o` et `x`. Ceux-ci permettent, respectivement, d'afficher/récupérer un nombre entier en représentation octale ou hexadécimale. Autrement dit, le nombre affiché/récupéré le sera en base huit ou en base seize.

Nous avons déjà vu la représentation binaire dans le chapitre sur les variables, les représentations octale et hexadécimale obéissent au même schéma : au lieu d'utiliser dix chiffres pour représenter un nombre, nous en utilisons respectivement huit ou seize.

[[question]]
| Seize chiffres ?! Mais... Je n'en connais que dix moi ! o_O

La représentation hexadécimale est un peu déroutante de prime abord, celle-ci ajoute six chiffres (en fait, six lettres) : a, b, c, d, e et f. Pour vous aider, voici un tableau présentant les nombres de 1 à 16 en binaire, octal, décimal et hexadécimal.

Binaire | Octal | Décimal | Hexadécimal
------- | ----- | ------- | -----------
00001 | 1 | 1 | 1
00010 | 2 | 2 | 2
00011 | 3 | 3 | 3
00100 | 4 | 4 | 4
00101 | 5 | 5 | 5
00110 | 6 | 6 | 6
00111 | 7 | 7 | 7
01000 | 10 | 8 | 8
01001 | 11 | 9 | 9
01010 | 12 | 10 | a
01011 | 13 | 11 | b
01100 | 14 | 12 | c
01101 | 15 | 13 | d
01110 | 16 | 14 | e
01111 | 17 | 15 | f
10000 | 20 | 16 | 10

[[information]]
| Notez que 10 dans n'importe quelle base équivaut à cette base.

[[question]]
| Quel est l'intérêt de ces deux bases exactement ?

L'avantage des représentations octale et hexadécimale est qu'il est facilement possible de les convertir en binaire contrairement à la représentation décimale. En effet, un chiffre en base huit ou en base seize peut-être facilement traduit, respectivement, en trois ou quatre *bits*.

Prenons l'exemple du nombre 35 qui donne 43 en octal et 23 en hexadécimal. Nous pouvons nous focaliser sur chaque chiffre un à un pour obtenir la représentation binaire. Ainsi, du côté de la représentation octale, 4 donne `100` et 3 `011`, ce qui nous donne finalement : `00100011`. De même, pour la représentation hexadécimale, 2 nous donne `0010` et 3 `0011` et nous obtenons : `00100011`. Il n'est pas possible de faire pareil en décimal.

Finalement, les représentations octales et hexadécimales permettent de représenter un nombre binaire de manière plus concise et plus lisible.

# Utilisation des indicateurs de conversion

## Avec printf

Il vous est possible d'afficher la représentation octale ou hexadécimale d'un nombre à l'aide des indicateur `o` et `x`.

```c
#include <stdio.h>


int main(void)
{
    printf("%o, %x\n", 35, 35);
    return 0;
}
```

```text
43, 23
```

[[information]]
| En fait, il existe deux indicateurs pour la représentation hexadécimale : l'indicateur `x` qui affiche les lettres en minuscule et l'indicateur `X` qui affiche les lettres en majuscule.

À l'inverse vous pouvez afficher la représentation décimal de nombres en base huit ou en base seize. Pour ce faire, vous devez utiliser des préfixes devant vos constantes pour signaler leur base. Ces préfixes sont `0` pour les constantes octales et `0x` ou `0X` pour les constantes hexadécimales.

```c
#include <stdio.h>


int main(void)
{
    printf("%d, %d\n", 043, 0x23);
    return 0;
}
```

```text
35, 35
```

[[question]]
| Il n'est pas possible d'afficher la représentation binaire d'un nombre ?

Malheureusement, non, rien n'est fourni de ce côté par *printf*() et *scanf*().

## Avec scanf

Vous pouvez demander à l'utilisateur d'entrer des nombres en base huit ou en base seize, ceux-ci seront alors converti en décimal par *scanf*().

```c
#include <stdio.h>


int main(void)
{
    int a;
    int b;

    scanf("%o, %x", &a, &b);
    printf("%o = %d, %x = %d\n", a, a, b, b);
    return 0;
}
```

```text
43, 23
43 = 35, 23 = 35
```

[[erreur]]
| À l'inverse de la fonction *printf*(), la fonction *scanf*() ne gère que l'indicateur `x` pour ce qui est de la représentation hexadécimale.