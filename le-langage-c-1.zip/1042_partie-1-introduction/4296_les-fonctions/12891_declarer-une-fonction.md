Pour déclarer une fonction, nous allons devoir donner quelques informations sur celle-ci, en fait quatre :

* son **nom** : les règles sont les mêmes que pour les variables ;
* son **corps** (autrement dit, son contenu) : il s'agit du bloc d'instructions à exécuter ;
* son **type de retour** : il s'agit du résultat de la fonction (nous y reviendrons bientôt) ;
* ses éventuels **paramètres** : il s'agit de valeur reçue par la fonction lors de l'appel (nous allons y venir également).

La syntaxe est la suivante :

```texte
type nom(paramètres)
{
     /* corps de la fonction */
}
```

Prenons un exemple : créons une fonction qui affiche « bonjour ! » à l'écran.

```c
#include <stdio.h>


void bonjour(void)
{
    printf("bonjour !\n");
}


int main(void)
{
    bonjour();
    return 0;
}
```

Comme vous le voyez, notre fonction se nomme *bonjour* et est composée d'une seule instruction : l'appel à *printf*(). Reste les deux mots-clés `void` :

* dans le cas du type de retour, il spécifie que la fonction ne retourne rien ;
* dans le cas des paramètres, il spécifie que la fonction n'en reçoit aucun (cela se manifeste lors de l'appel : il n'y a rien entre les parenthèses).

# Le type de retour

Le type de retour permet d'indiquer deux choses : si la fonction retourne une valeur et le type de cette valeur.

```c
#include <stdio.h>


int deux(void)
{
    return 2;
}


int main(void)
{
    printf("Retour : %d\n", deux());
    return 0;
}
```

```text
Retour : 2
```

Dans l'exemple ci-dessus, la fonction *deux*() est définie comme retournant une valeur de type `int`. Vous retouvez l'instruction `return` que nous avons déjà vue, mais pas encore expliquée. Celle-ci est en fait une instruction de saut (comme `break`, `continue` et `goto`), cependant nous ne pouvions en parler sans avoir expliquer le concept de fonction.

L'instruction `return` provoque l'arrêt de l'exécution de la fonction courante et provoque un retour (techniquement, un saut) vers l'appel à cette fonction qui se voit alors attribuer la valeur de retour (s'il y en a une). Autrement dit, dans le cas de notre exemple : l'instruction `return 2` stoppe l'exécution de la fonction *deux()* et ramène l'exécution du programme à l'appel qui vaut désormais 2, ce qui donne finalement : printf("Retour : %d\n", 2)`

À l'intérieur de notre fonction (dans ce qui est nommé le corps de la fonction dans l'exemple du dessus), on va y placer le code de notre fonction. Pour illustrer ce concept, prenons un exemple tout banal :

```c
int ma_fonction(int parametre)
{
    /* Instructions */
}
```

J'ai ici défini une fonction appelée *ma_fonction*. Elle prend un ```int``` comme paramètre, et a pour résultat un ```int```.

## void

Il se peut que l'on est besoin de coder une fonction qui ne retourne aucun résultat. C'est un cas courant en C. Ce genre de fonction est appelé **procédure**. Pour écrire une procédure, il faut indiquer à la fonction en question qu'elle ne doit rien retourner. Pour ce faire, il existe un "type de retour" spécial : ```void```. Ce type signifie "vide", et sert à indiquer que la fonction n'a pas de résultat.

Ce mot-clef sert aussi à indiquer qu'une fonction ne prend aucun paramètre. C'est assez rare, mais cela arrive. Dans ce cas, il suffit de définir la fonction en mettant ```void``` dans la liste des paramètres.

## Paramètres

Un paramètre sert à fournir des informations à la fonction lors de son exécution. La fonction *printf* par exemple récupère ce qu'elle doit afficher dans la console à l'aide de paramètres. Vous pouvez envoyer autant de paramètres à une fonction que vous voulez, il suffit de les séparer à l'aide d'une virgule. Cependant, ils doivent avoir des noms différents, tout comme les variables. Il est aussi possible de ne pas mettre d'arguments dans notre fonction, comme indiqué plus haut.

## Exemples 

Pour vous faire bien saisir toutes ces notions, entrainez vous à déclarer des fonctions. Essayez de déclarer une fonction :

* retournant un ```double``` et prenant un ```char``` et un ```int``` en argument ;
* retournant un ```unsigned short``` et ne prenant aucun paramètre ;
* retournant un ```float``` et prenant un ```int```, un ```long``` et un ```double``` en paramètres ;
* retournant un ```int``` et prenant un ```int``` constant et un ```unsigned long``` en paramètre ;
* ne retournant rien et ne prenant aucun paramètre ;

Je pense qu'avec tous ces exemples vous commencez à bien saisir comment déclarer une fonction.

# Le corps d'une fonction

Intéressons-nous maintenant au corps de la fonction, le code qu'il y a à l'intérieur. Comme pour la fonction *main*, le code est à l'intérieur des accolades. Et ce code, c'est nous qui allons l'écrire. Alors que doit-on écrire ? En bref, ce que vous voulez que la fonction fasse.

## return

À ce stade, vous savez comment déclarer une fonction sans problème. Il vous manque juste une dernière information : comment faire pour préciser quel est le résultat de la fonction ? Comment lui dire : *« Le résultat que tu dois renvoyer, c'est ça »* ? Pour cela, on doit utiliser le mot-clef ```return```. Une fois que vous avez une variable qui contient le résultat que vous voulez, il suffit  d'écrire ```return```, suivi du nom de la variable, le tout suivi d'un point-virgule. À ce moment-là, la fonction s’arrêtera et renverra son résultat immédiatement. Cela signifie que tout le code qui est écrit après le ```return``` ne sera pas exécuté : notre fonction a déjà son résultat de disponible, pourquoi faire quoi que ce soit de plus ?

Petite remarque : un ```return``` peut parfaitement renvoyer une valeur qui est une constante. Pour donner un exemple, on va prendre une fonction assez simple, qu'on nommera *valueSign*. Notre fonction va prendre un argument de type ```int``` en entrée et va renvoyer :

* 0 si cet argument est nul ;	
* 1 si celui-ci est positif ;	
* et -1 si celui-ci est négatif.

Une version naïve de cette fonction s'écrirait comme ceci :

```c
int valueSign (int a)
{
    if ( a > 0 )
    {
        return 1 ;
    }

    else if ( a < 0 )
    {
        return -1 ;
    }

    else
    {
        return 0 ;
    }
}
```

## Variables locales

Autre détail, qui concerne les variables que vous déclarez à l'intérieur du corps d'une fonction. Autant vous prévenir tout de suite : n'essayez pas d’accéder à une variable qui est déclarée dans une fonction en dehors de celle-ci. Si vous faites cela, vous allez au-devant de graves ennuis.

En effet, sauf cas exceptionnels, il faut savoir que ces variables ne sont accessibles que dans notre fonction, et pas de l'extérieur. C'est ainsi : les variables déclarées à l'intérieur de la fonction sont des données temporaires qui lui permettent de faire ce qu'on lui demande. Ces données sont des données internes à notre fonction, qu'elle seule doit manipuler et qui ne doivent généralement pas être accessibles à d’autres programmes ou d'autres fonctions. Si ce n'est pas le cas, c'est que cette variable doit être passée en paramètre ou qu'elle doit être renvoyée en tant que résultat. 

En fait, vous pouvez considérer que dans la majorité des cas, ces variables déclarées dans une fonction sont créées quand on commence l’exécution de la fonction, et qu'elles sont enlevées de la mémoire une fois que la fonction renvoie son résultat. Si je dis la majorité des cas, c'est qu'il y a une exception. Mais laissons cela de côté pour le moment : le temps de parler des variables statiques n'est pas encore arrivé.

# Exemple

Prenons un exemple tout bête. Vous voulez faire une fonction qui renvoie le carré d'un nombre passé en paramètre. Commençons déjà par traduire notre fonction en pseudo-code :

```console
Entrée : nombre

Carré :
       Multiplier nombre par lui-même
       Retourner nombre
```

Maintenant, exerçons-nous en codant cet algorithme. Je vous encourage à le faire avant de regarder la solution, cela vous fera progresser. Sinon, celle-ci ce trouve [ici](http://paste.awesom.eu/informaticienzero/1j4&ln).

Maintenant que vous avez saisi le principe, nous allons apprendre à utiliser nos fonctions, car pour l'instant elles ne font rien.