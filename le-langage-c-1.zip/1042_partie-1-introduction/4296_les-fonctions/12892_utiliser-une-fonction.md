Nous avons déjà utilisé quelques fonctions, notamment *printf* et *scanf*. Pour les utiliser, il suffit de taper le nom de la fonction suivi des paramètres entre parenthèses. Eh bien, pour nos fonctions c'est exactement la même chose. Prenons pour illustration la fonction *carre* vue dans la partie précédente. Voici le programme complet :

```c
#include <stdio.h>

int carre(int nombre)
{
    return nombre * nombre;
}

int main(void)
{
    int nombre, nombre_au_carre;

    puts("Entrez un nombre : ");
    scanf("%d", &nombre);
 
    nombre_au_carre = carre(nombre);

    printf("Voici le carre de %d : %d\n", nombre, nombre_au_carre);
    return 0;
}
```

On demande à l'utilisateur de rentrer un nombre entier. Une fois ceci fait, on appelle la fonction avec cette ligne :

```c
nombre_au_carre = carre(nombre);
```

On dit que *nombre* est un argument de la fonction *carre*. Paramètres et arguments sont très liés ; la différence entre les deux est que les premiers apparaissent lors que la définition de la fonction alors que les seconds apparaissent lors de son l'appel. On demande ensuite à attribuer à la variable *nombre_au_carre* la valeur retournée par la fonction *carre*. Ainsi, si *nombre* vaut 4, on appelle la fonction, et celle-ci retournera alors 16 (car $4^2 = 16$).

Un petit code commenté ?

```c
#include <stdio.h>

/* d) le nombre passé en paramètre en c) est récupéré */

int carre(int nombre)
{
    /* e) on fait le calcul et on renvoie la valeur */
    return nombre * nombre ;
}

int main(void)
{
    /* a) on déclare nos variables */
    int nombre, nombre_au_carre;

    puts("Entrez un nombre : ");
    /* b) on récupère la valeur de nombre */
    scanf("%d", &nombre);
 
    /* c) on appelle la fonction carre */
    nombre_au_carre = carre(nombre);
    /* f) nombre_au_carre vaut maintenant la valeur retournée par la fonction carre */
    
    /* g) on affiche le résultat */
    printf("Voici le carre de %d : %d\n", nombre, nombre_au_carre);
    return 0;
}
```

Ça va, vous suivez ? C'est simple : lors de l'appel de la fonction, on lui donne des arguments et le programme s'occupe du reste. C'est lui qui fera les calculs et qui renverra la valeur à afficher.

Sachez qu'il est possible d'optimiser notre code en se passant de cette variable intermédiaire qui stocke le résultat. En effet, on peut très bien appeler la fonction directement dans le *printf*, comme ceci :

```
#include <stdio.h>

int carre(int nombre)
{
    return nombre * nombre;
}

int main(void)
{
    int nombre;

    puts("Entrez un nombre :");
    scanf("%d", &nombre);

    printf("Voici le carre de %d : %d\n", nombre, carre(nombre));
    return 0;
}
```

Ce code revient au même que le précédant, car le deuxième paramètre de *printf* sera la valeur retournée par la fonction. Autrement dit, c'est un nombre dans les deux cas, et affichera bien la même chose à l'écran :

```console
Entrez un nombre :
10
Voici le carré de 10 : 100
```

La fonction *main* appelle la fonction *printf*, qui elle-même appelle la fonction *carre*. C'est une imbrication de fonctions. Ainsi, une fonction peut en appeler une autre ; c'est ainsi que tout programme écrit en C fonctionne. Entrainez-vous à appeler des fonctions en utilisant toutes les fonctions que nous avons vues au cours de ce chapitre. Nous verrons d'autres exercices en fin de chapitre.

# Appel de fonctions

Il faut aussi préciser une chose importante sur les arguments : si on passe une variable en argument d'une fonction, la variable en elle-même ne sera pas modifiée. La fonction utilisera à la place une copie de la variable ! C'est très important, et c'est source de comportements bizarres si on ne fait pas attention. Retenez bien : **les arguments d'une fonction sont copiés et c'est cette copie qui est manipulée par notre fonction**. Considérons l'exemple suivant.

```c
#include <stdio.h>

void fonction(int nombre)
{
    ++nombre;
    printf("Variable nombre dans la fonction : %d\n", nombre);
}

int main(void)
{
    int nombre = 5;

    fonction(nombre);
    printf("Variable nombre dans le main : %d\n", nombre);

    return 0;
}
```
```console
Variable nombre dans la fonction : 6
Variable nombre dans le main : 5
```

Vous avez vu ? La fonction manipule bien une copie de la variable, car lorsque l'on revient dans la fonction *main*, la valeur de la variable est toujours la même : l'original n'a pas été modifié. Nous verrons néanmoins dans quelques chapitres comment modifier l'original dans la fonction et non une copie.

On peut légitimement se demander pourquoi un tel comportement. La raison est assez complexe, mais je peux au moins vous dire que la raison est fortement liée au matériel de notre ordinateur. La façon dont les fonctions sont exécutées au niveau de notre ordinateur impose que ces arguments soient copiés. Pour le moment, ce n'est pas de votre niveau, mais vous aurez surement la réponse plus tard.