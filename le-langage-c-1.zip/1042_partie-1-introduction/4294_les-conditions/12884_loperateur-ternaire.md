L'opérateur ternaire, qui est une autre façon de faire un test de condition, tient son nom du fait qu'il est le seul à avoir trois opérandes. En effet, il se compose comme suit :

```console
(condition) ? instruction si vrai : instruction si faux
```

Les parenthèses ne sont pas obligatoires. Ce qu'il y a à retenir, c'est qu'il se comporte comme un ```if / else```, tout en étant plus condensé et plus rapide à écrire. Voyez par vous-mêmes :

```c
#include <stdio.h>

int main(void)
{
    int heure;

    scanf("%d", &heure);

    (heure > 8 && heure < 20) ? printf("Il fait jour.") : printf("Il fait nuit.");

    return 0;
}
```

Il est également possible de l'écrire sur plusieurs lignes, même si cette pratique est moins courante :

```c
(heure > 8 && heure < 20) ?
    printf("Il fait jour.")
    : printf("Il fait nuit.");
```

Les ternaires peuvent sembler inutiles, surtout que s'ils sont mal employés ils rendent un programme moins lisible. Cependant, l'exercice suivant va vous prouvez que quand on les emploie bien, ce sont de bons alliés.

### Exercice ###

Pour bien comprendre cette nouvelle notion, nous allons faire un petit exercice. Imaginez qu'on veuille faire un mini jeu vidéo dans lequel on affiche le nombre de coups du joueur. Seulement voilà, vous êtes maniaques du français et vous ne supportez pas qu'il y ait un ```'s'``` en trop ou en moins. Essayez de coder un programme dans lequel on demande à l'utilisateur le nombre de coups puis on affiche le résultat.

Fini ? Voici la correction :

[[secret]]
| | ```c
| #include <stdio.h>
| 
| int main(void)
| {
|     int nb_coups;
| 
|     printf("Donnez le nombre de coups : ");
|     scanf("%d", &nb_coups);
| 
|     printf("\nVous gagnez en %d coup%c", nb_coups, nb_coups > 1 ? 's' : ' ');
|     return 0;
| }
| ```

Ce programme utilise les ternaires pour condenser l'expression et aller plus vite dans l'écriture du code. Sans les ternaires il aurait fallu faire quelque chose comme :

```c
#include <stdio.h>

int main(void)
{
    int nb_coups;

    printf("Donnez le nombre de coups : ");
    scanf("%d", &nb_coups);

    printf("\nVous gagnez en %d coup", nb_coups);

    if (nb_coups > 1)
        putchar('s');
    else
        putchar(' ');

    return 0;
}
```