Vous savez désormais manipuler des conditions, c'est bien, cependant l'intérêt de la chose reste assez limité pour l'instant. Rendons à présent cela plus intéressant en voyant comment exécuter un bloc d'instruction quand une ou plusieurs conditions sont respectées. C'est le rôle de l'instruction ```if``` et de ses consœurs.

# L'instruction if

L'instruction ```if``` permet d'exécuter un bloc d'instructions si une condition est vérifiée ou de le passer si ce n'est pas le cas.

![Structure If](http://zestedesavoir.com/media/galleries/1501/454dae77-cfa3-4bda-8e46-6551e3c94945.png.960x960_q85.jpg)

L'instruction ```if``` ressemble à ceci :

```c
if (/* Condition */)
{
    /* Une ou plusieurs instructions */
}
```

Si la condition n'est pas vérifiée, le bloc d'instruction est passé et le programme recommence immédiatement à la suite du bloc d'instruction délimité par l'instruction ```if```. 

Si vous n'avez qu'une seule instruction à réaliser, vous avez la possibilité de ne pas mettre d'accolades.

```c
if (/* Condition */)
    /* Une seule instruction */
```

Cependant, nous vous conseillons de mettre les accolades systématiquement afin de ne pas vous poser de problèmes si vous décidez de rajouter des instructions par la suite en oubliant d'ajouter des accolades. Bien sûr, ce n'est qu'un conseil, vous êtes libre de ne pas le suivre.

À présent, voyons quelques exemples d'utilisation.

## Exemple 1

```c
#include <stdio.h>


int main(void)
{
    int a = 10;
    int b = 20;

    if (a < b)
    {
        printf("%d est inférieur à %d\n", a, b);
    }

    return 0;
}
```

```text
10 est inférieur à 20
```

L'instruction ```if``` évalue l'expression logique ```a < b```, conclue qu'elle est valide, et exécute le bloc d'instruction.

## Exemple 2

```c
#include <stdio.h>


int main(void)
{
    int a = 10;
    int b = 20;

    if (a > b)
    {
        printf("%d est supérieur à %d\n", a, b);
    }

    return 0;
}
```

```text
```

Ce code n'affiche rien. La condition étant fausse, le bloc contenant l'appel à la fonction *printf*() est ignoré.

# L'instruction else

Avec l'instruction ```if```, nous savons exécuter un bloc d'instruction quand une condition est remplie. Toutefois, si nous souhaitons réaliser une action en cas d'échec de l'évaluation de la condition, nous devons ajouter une autre instruction ```if``` à la suite. Par exemple :

```c
if (a > 5)
{
    /* du code */
}

if (a <= 5)
{
    /* code alternatif */
}
```

Le seul problème, c'est qu'il est nécessaire d'ajouter une instruction ```if``` et d'évaluer une nouvelle condition, ce qui n'est pas très efficace et assez long à taper. Pour limiter les dégâts, le C fournit une autre instruction : ```else```, qui signifie « sinon ». Celle-ci se place immédiatement après le bloc d'une instruction ```if``` et permet d’exécuter un bloc d'instruction alternatif si la condition testée n'est pas vérifiée. Sa syntaxe est la suivante :

```c
if (/* Condition */)
{
    /* Une ou plusieurs instructions */
}
else
{
    /* Une ou plusieurs instructions */
}
```

Et elle doit être comprise comme ceci :

![Structure if else](http://zestedesavoir.com/media/galleries/1501/e517e100-c6b9-4049-8ea8-8981ca429725.png.960x960_q85.jpg)

[[information]]
| Notez que l'instruction ```else``` ne possède aucune parenthèse.

## Exemple

Supposons que nous voulions créer un programme très simple auquel nous fournissons une heure et qui indique s'il fait jour ou nuit à cette heure-là. Nous supposerons qu'il fait jour de 9 heures à 20 heures, et qu'il fait nuit sinon.

```c
int main(void)
{
    int heure;
    scanf("%d", &heure);

    if (heure > 8 && heure < 20)
    {
        printf("Il fait jour.\n");
    }
    else
    {
        printf("Il fait nuit.\n");
    }

    return 0;
}
```

# If / else if

Il est parfois nécessaire d'imbriquer plusieurs instructions ```if``` et ```else``` les unes dans les autres. Ainsi, de tels codes sont possibles :

```c
if (condition)
{
    /* du code */
}
else
{
    /* plusieurs instructions */

    if (autre condition)
    {
        /* du code */
    }
}
```

Cependant, c'est assez longs à écrire, d'autant plus s'il y a beaucoup d'imbrications. Pour éviter ces inconvénients, il existe une autre instruction : ```else if```. Les imbrications simplifiables avec un ```else if``` sont celles qui s'écrivent comme ceci : 

```c
if (/* Expression logique */)
{
    /* Une ou plusieurs instructions */
}
else 
{
    if (/* Expression logique */)
    {
        /* Une ou plusieurs instructions */
    }
}
```

Faites bien attention : le bloc d'instruction du ```else``` doit contenir un ```if```, éventuellement avec un ```else```, mais rien d'autre. Celles-ci peuvent alors être simplifiées comme suit :

```c
if (/* Expression logique */)
{
    /* Une ou plusieurs instructions */
}
else if (/* Expression logique */)
{
    /* Une ou plusieurs instructions */
}
```

Tout se passe comme si nous avions enlevé les accolades du ```else```. De la même manière qu'une instruction `else`, une instruction `else if` suit toujours une instruction ```if``` ou une autre  instruction ```else if```.

Dès lors, hors d'une instruction ```if``` suivie de plusieurs instructions ```else if``` (le tout éventuellement terminé par une instruction ```else```), un seul bloc d'instruction sera exécuté. L'ordinateur va tester la condition de l'instruction ```if```, puis celle de l'instruction ```else if``` suivante si elle est fausse et ainsi de suite jusqu'à ce qu'une condition soit vraie (ou jusqu'à l'instruction `else` si elles sont toutes fausses).

[[information]]
| Notez qu'il n'est pas obligatoire d'ajouter une instruction `else`.

```c
#include <stdio.h>


int main(void)
{
    int heure = 11;

    if (heure < 7)
    {
        printf("Zzz... \n");
    }
    else if (heure >= 7 && heure <= 12)
    {
        printf("C'est le matin !\n");
    }
    else if (heure == 12)
    {
        printf("Il est midi !\n");
    }
    else if (heure > 12 && heure <= 17)
    {
        printf("C'est l'après-midi !\n");
    }
    else if (heure >= 18 && heure < 24)
    {
        printf("C'est le soir !\n");
    }
    else if (heure == 24 || heure == 0)
    {
        printf("Il est minuit, dormez brave gens !\n");
    }
    else
    {
        printf("Il est l'heure de réapprendre à lire l'heure !\n");
    }

    return 0;
}
```

```text
11
On est le matin !
0
Il est minuit, dormez brave gens !
-2
Il est l'heure de réapprendre à lire l'heure !
```

## Exercice

Imaginez que vous avez un score de jeu vidéo sous la main :

* si le score est inférieur à 2000, affichez « *C'est la catastrophe !* » ;
* si le score est supérieur ou égal à 2000 et que le score est inférieur à 5000, affichez : « *tu peux mieux faire* ! » ;
* si le score est supérieur ou égal à 5000 et que le score est inférieur à 9000, afficherz : « *tu es sur la bonne voie !* » ;
* sinon, affichez : « *tu es le meilleur !* ».

Au boulot ! :)

[[secret]]
| ```c
| #include <stdio.h>
|
|
| int main(void)
| {
|     int score;
| 
|     printf("Quel est le score du joueur : ");
|     scanf("%d", &score);
| 
|     if (score < 2000)
|     {
|         printf("C'est la catastrophe !\n");
|     }
|     else if (score >= 2000 && score < 5000)
|     {
|         printf("Tu peux mieux faire !\n");
|     }
|     else if (score >= 5000 && score < 9000)
|     {
|         printf("Tu es sur la bonne voie !\n");
|     }
|     else
|     {
|         printf("Tu es le meilleur !\n");
|     }
| 
|     return 0;
| }
| ```