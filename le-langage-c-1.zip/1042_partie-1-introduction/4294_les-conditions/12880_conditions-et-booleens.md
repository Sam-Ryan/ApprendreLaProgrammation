Avant de pouvoir utiliser des structures de contrôle, il est nécessaire de pouvoir rédiger des conditions. Pour ce faire, le langage C fournis différents opérateurs qui permettent d'effectuer des comparaisons entre des nombres. Ces opérateurs peuvent s'appliquer aussi bien à des nombres écrits en dur dans le code qu'à des variables (ou un mélange des deux). Ces derniers permettent donc par exemple de vérifier si une variable est supérieure à une autre, si elles sont égales, etc.

# Comparaisons

L'écriture de conditions est similaire aux écritures mathématiques que vous voyez en cours : l'opérateur est entre les deux expressions à comparer. Par exemple, dans le cas de l'opérateur `>` (« strictement supérieur à »), il est possible d'écrire des expressions du type : ```a > b``` , qui vérifie si la variable *a* est strictement supérieure à la variable *b*.

Le tableau ci-dessous reprends les différents opérateurs de comparaisons.

Opérateur  | Signification
------------- | -------------
==| Égalité
!=| Inégalité
<| Strictement inférieur à
<=| Inférieur ou égal à
>| Strictement supérieur à
>=| Supérieur ou égal à

Ces opérateurs ne semblent pas très folichons : avec, nous ne pouvons faire que quelques tests basiques sur des nombres. Cependant, rappelez-vous : pour un ordinateur, tout n'est que nombre et comme pour le stockage des données (revoyez le début du chapitre 4 si cela ne vous dit rien) il est possible de ruser et d'exprimer toutes les conditions possibles avec ces opérateurs (cela vous paraîtra plus clair quand nous passerons aux exercices).

# Les booléens

Comme nous l'avons dit : les opérateurs de comparaison vont donner un résultat. Celui-ci sera « vrai » si la condition est vérifiée, et « faux » si la condition est fausse. Toutefois, encore une fois, notre ordinateur ne voit que des nombres. Aussi, il est nécessaire de représenter les valeurs « vrai » et « faux » avec des nombres. 

Certains langages fournissent pour cela un type distinct pour stocker le résultat des opérations de comparaisons et deux valeurs spécifiques : `true` (vrai) et `false` (faux). Néanmoins, dans les premières versions du langage C, ce type spécial n'existe pas. Il a donc fallu ruser et trouver une solution pour représenter les valeurs « vrai » et « faux ». Pour cela, la méthode la plus simple a été privilégiée : utiliser directement des nombres pour représenter ces deux valeurs. Ainsi, le langage C impose que :
 
* la valeur « faux » soit représentée par zéro ;
* et que la valeur « vrai » soit représentée par tout sauf zéro.

Les opérateurs de comparaisons suivent cette convention pour représenter leur résultat. Dès lors, une opération de comparaison va donner 0 si elle est fausse et donnera 1 si elle est vraie.

## Exemple 

Pour illustrer ceci : vérifions quels sont les résultats renvoyés par différentes comparaisons.

```c
int main(void)
{
    printf("10 == 20 renvoie %d\n", 10 == 20);
    printf("10 != 20 renvoie %d\n", 10 != 20);
    printf("10 < 20 renvoie %d\n", 10 < 20);
    printf("10 > 20 renvoie %d\n", 10 > 20);

    return 0;
}
```

```text
10 == 20 renvoie 0
10 != 20 renvoie 1
10 < 20 renvoie 1
10 > 20 renvoie 0
```

Le résultat confirme bien ce que nous avons dit ci-dessus : une condition vaut 0 si elle est fausse et 1 si elle est vraie.