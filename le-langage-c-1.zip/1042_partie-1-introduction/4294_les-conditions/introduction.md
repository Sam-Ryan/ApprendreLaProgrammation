Comme dit au chapitre précédent, les structures de contrôle permettent, entre autres, d'exécuter un ensemble d'instructions dans le cas où une condition est remplie ou de répéter une portion de code un certains nombre de fois.

Le tableau ci-dessous reprends celles dont dispose le langage C.

Structure de contrôle  | Action
------------- | -------------
***if...***  | exécute une suite d'instructions si une condition est respectée.
***if...else...***  | exécute une suite d'instructions si une condition est respectée ou exécute une autre suite d'instructions si elle ne l'est pas.
***switch...***  | exécute une suite d'instructions différente suivant la valeur testée.
***while...***  | répète une suite d'instructions tant qu'une condition est respectée.
***do...while...***  | répète une suite d'instructions tant qu'une condition est respectée. Le groupe d'instructions est exécuté au moins une fois.
***for...***  | répète un nombre fixé de fois une suite d'instructions.

Dans ce chapitre, nous allons voir comment utiliser les structures de contrôles les plus basiques disponibles en C, à savoir les trois premières du tableau ci-dessus. Nous allons également découvrir et utiliser les conditions.