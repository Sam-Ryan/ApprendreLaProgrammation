Pour l’instant, nous n’avons présenté que le code C minimal. Néanmoins, il existe des notions très importantes et communes à tous les langages de programmation, et nous allons vous les présenter, en les appliquant au C bien entendu. Soyez donc concentré, cette partie est basique, mais importante pour la suite.

# Les mots-clés

Les **mots-clés** sont des mots spéciaux, réservés par le compilateur, que l’on ne peut pas utiliser comme on veut. Ils servent à déclarer des variables, concept que l’on découvrira dans le chapitre suivant, à préciser des attributs, et réaliser d’autres actions encore. Le C a réservé 32 mots-clés, que voici :

```c
auto     double   int      struct
break    else     long     switch
case     enum     register typedef
char     extern   return   union
const    float    short    unsigned
continue for      signed   void
default  goto     sizeof   volatile
do       if       static   while
```
> *Norme C89 — A.1.1.2 Keywords*

Nous les verrons tous au fur et à mesure de la progression de ce cours. Certains vous seront plus utiles que d’autres, mais tous ont un rôle.

D’ailleurs, ces mots-clés sont colorés par votre IDE. Cela permet au programmeur de mieux voir, et disons-le, c’est toujours plus joli que du code entièrement en noir. 

### Les opérateurs ###

Les **opérateurs** sont des symboles à la base des expressions (nous verrons plus bas de quoi il s’agit). Ils permettent de faire des opérations comme l’addition, la multiplication, la comparaison de deux valeurs, l’opposé d’une valeur, etc. De même qu’en mathématiques, tous n’ont pas la même priorité : certains passent avant d’autres. 

Les opérateurs en C sont les suivants :

```c
[  ]  (  )  .  ->
++  --  &  *  +  -  ~  !  sizeof
/  %  <<  >>  <  >  <=  >=  ==  !=  ^  |  &&  ||
?  :
=  *=  /=  %=  +=  -=  <<=  >>=  &=  ^=  |=
, 
```
> *Norme C89 — A.1.1.6 Operators*
*Vous noterez que ```sizeof``` est à la fois un mot-clé et un opérateur.*

Les opérateurs peuvent être classés en C en sept catégories :

* les opérateurs arithmétiques ;
* les opérateurs d’affectation ;	
* les opérateurs logiques ;	
* les opérateurs de comparaison ;	
* l’opérateur conditionnel ;	
* les opérateurs bit-à-bit ;
* et quelques opérateurs inclassables.

Nous examinerons toutes ces catégories au fur et à mesure que nous progresserons dans le tutoriel. Comme pour les mots-clés, vous en utiliserez certaines plus que d’autres, mais toutes ont leur utilité.

# Instructions

Une **instruction** est un ordre qui permet d’exécuter telle ou telle action. Pour vous aider, chaque instruction peut se traduire par une phrase verbale en français.

```c
printf("Hello world!");   /* Affiche « Hello world! ». */
x = 2;    /* Affecte la valeur 2 à x. */
```

Toutes les instructions se terminent par un point-virgule (nous apprendrons au fur et à mesure les quelques-unes qui n’en requièrent pas). 

Un **bloc d’instructions** est formé d’une suite d’instructions délimitée par des accolades, et tout ce qu’il y a entre les accolades est par conséquent à l’intérieur d’un bloc d’instructions. La fonction ```main``` est par exemple suivie d’un bloc d’instructions composé de deux instructions.

# Les séparateurs

Lorsque l’on écrit, on met des espaces entre les mots pour rendre le tout plus clair. Pour la programmation, c’est pareil. On insère des espaces et des retours à la ligne dans un code source pour le rendre plus clair et plus lisible. Par exemple, les deux codes ci-dessous sont identiques pour le compilateur, mais le second est plus lisible pour le programmeur que le premier.

```c
int x=0,y,rep;

int x = 0, y, rep;
```

Ce dernier point m’amène donc à l’indentation.

# L’indentation

L’**indentation** est vraiment quelque chose de très important. Elle consiste en l’ajout de tabulations ou d’espaces dans un code source. Un code bien indenté est un code clair et agréable à lire. Le style d’indentation définit comment les programmeurs se débrouillent afin de faire ressortir du code.

Parce qu’un code vaut 1000 mots :

```c
#include<stdio.h>
int main(void)
{ printf("Hey !\n");
  printf("Bien ?");
  return 0;}
```

En comparaison avec :

```c
#include <stdio.h>

int main(void)
{
    printf("Hey !\n");
    printf("Bien ?");

    return 0;
}
```

Il existe de [nombreux styles d'intendation](http://en.wikipedia.org/wiki/Indent_style) différents. C'est à vous de choisir celui que vous préférez, et surtout de vous y tenir. Ce cours utilisera quant à lui le style Allman (ou style ANSI).

Il faut aussi que vous sachiez qu’il existe une *règle* concernant le nombre de colonnes (de caractères entre autres) à ne pas dépasser par ligne. C’est une très ancienne règle, qui limite le nombre de caractères par ligne à 80. Vous n’êtes pas obligé de la suivre, loin de là. Mais sachez que certains l’affectionnent encore, et ne soyez pas surpris si certains codes suivent cette règle. Dans ce tutoriel, ce ne sera pas le cas.

# Les commentaires

Il est souvent nécessaire de **commenter son code source** pour décrire des passages un peu moins lisibles ou tout simplement pour offrir quelques compléments d’information au lecteur du code. Un commentaire est ignoré par le compilateur : il disparait et n’est pas présent dans l’exécutable. Il ne sert qu’au programmeur et aux lecteurs du code.

Un commentaire en C est écrit entre les signes ```/*``` et ```*/``` :

```c
/* Ceci est un commentaire */
```

Il peut très bien prendre plusieurs lignes :

```c
/* Ceci est un commentaire qui
   prend plusieurs lignes. */
```

Le plus dur quand on utilise les commentaires, c’est de trouver un juste milieu : trop de commentaires tue le commentaire, et bien souvent la grande majorité des commentaires sont inutiles. À l’inverse, pas assez de commentaires peuvent rendre la relecture du code plus difficile, surtout pour du code compliqué. 

Pour trouver ce juste milieu, il faut savoir plusieurs choses. Premièrement, pas besoin de commenter chaque ligne : si certaines instructions sont évidentes, les commenter sera superflu. Deuxièmement, essayer de faire des blocs de commentaires donnant une explication générale plutôt que de commenter chaque ligne une à une. Les commentaires doivent servir à décrire quelque chose de flou, ne vous sentez donc pas poussés à en mettre partout.

L’idée de base est que **les commentaires doivent aider le lecteur et éviter de redire ce que le code dit**.

Voilà à quoi ressemblerait notre code (excessivement) commenté : 

```c
/* Directive de préprocesseur qui permet de charger des fonctions utiles */
#include <stdio.h>

/* La fonction principale */
int main(void)
{
    /* Et des instructions */
    printf("Hello world!\n");
    return 0;
}

/* Fin du code, le programme s’achève ici */
```

Bien sûr, en pratique, ces commentaires sont inutiles.

En outre, vous pouvez rencontrer un autre style de commentaires, dit "commentaire de style C++" , qui provient du langage C++. Ce type de commentaire, noté `//` n'est autorisé en C que depuis le C99, je vous conseille donc de ne pas les utiliser en C et de les remplacer par les bon vieux `/*...*/`. Ces commentaires C++ commentent tout ce qui est situé entre eux et la fin de la ligne. Je les mentionne uniquement parce que vous risquez d'en voir parfois dans les codes des autres programmeurs.