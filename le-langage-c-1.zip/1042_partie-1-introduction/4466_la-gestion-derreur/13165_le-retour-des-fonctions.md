Peut-être l'avez vous déjà remarqué : certaines fonctions, comme *scanf*() et *printf*(), retournent un nombre (souvent un entier) alors que nous n'attendons finalement aucune valeur de celles-ci. Pourquoi diable ces dernières retournent-elles quelque chose alors qu'elles ne calculent par exemple pas un résultat comme la fonction *pow*() ? *Hé* bien, je vous le donne en mille : ces valeurs servent en fait à vous signifier si l'exécution de la fonction s'est bien déroulée. 

# Scanf

Prenons l'exemple de la fonction *scanf*() : cette dernière retourne le nombre de conversions réussies ou un nombre inférieur si elles n'ont pas toutes été réalisée ou enfin un nombre négatif en cas d'erreur.

Ainsi, si nous souhaitons récupérer deux entiers et être certains que *scanf*() les a récupéré, nous pouvons utiliser le code suivant :

```c
#include <stdio.h>


int main(void)
{
    int x;
    int y;

    printf("Entrez deux nombres : ");
    if (scanf("%d %d", &x, &y) == 2)
    {
        printf("Vous avez entre : %d et %d\n", x, y);
    }
    return 0;
}
```

```text
Entrez deux nombres : 1 2
Vous avez entre : 1 et 2

Entrez deux nombres : 1 a
```

Comme vous pouvez le constater, le programme n'exécute pas l'affichage des nombres dans les deux derniers cas, car *scanf*() n'a pas réussi à réaliser deux conversions.

# Main

Maintenant que vous savez tout cela, regarder bien votre fonction *main*() :

```c
int main(void)
{
    return 0;
}
```

Vous ne voyez rien qui vous interpelle ? :)

Oui, vous avez bien vu, elle retourne un entier qui, comme pour *scanf*(), sert à indiquer la présence d'erreur. En fait, il y a deux valeurs possibles : 

- EXIT_SUCCESS (ou zéro, cela revient au même), qui indique que tout s'est bien passé ;
- et EXIT_FAILURE, qui indique un échec du programme.

Ces deux macroconstantes sont définies dans l'en-tête **<stdlib.h\>**).

# Les autres fonctions

Ah, et au fait : *scanf*(), *printf*() et *main*() ne sont pas les seules fonctions qui retournent des entiers.

[[question]]
| Ok, mais je fais comment pour savoir ce que retourne une fonction ?

À l'aide de la documentation. Vous disposez de [la norme](http://flash-gordon.me.uk/ansi.c.txt) (enfin, du brouillon de celle-ci) qui reste la référence ultime, sinon vous pouvez également utiliser un moteur de recherche avec la requête `man nom_de_fonction` afin d'obtenir les informations dont vous avez besoin.

[[information]]
| Si vous êtes anglophobe, une traduction française de diverses descriptions est disponible à [cette adresse](http://perkamon.traduc.org/), vous les trouverez à la section trois.