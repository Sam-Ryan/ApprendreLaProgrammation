Peut-être l'avez vous déjà remarqué : certaines fonctions, comme *scanf*() et *printf*(), retourne un nombre (souvent un entier) alors que nous n'attendons finalement aucune valeur de celles-ci,  nous voulons uniquement qu'elles récupèrent ou écrivent des données. Pourquoi diable ces dernières retournent-elles quelque chose alors qu'elles ne calculent par exemple pas un résultat comme la fonction *pow*() ?

*Hé* bien, je vous le donne en mille : ces valeurs servent en fait à vous signifier si l'exécution de la fonction s'est bien déroulée. Prenons l'exemple de la fonction *scanf*() : cette dernière retourne le nombre de conversions réussies ou un nombre inférieur si elles n'ont pas toutes été réalisée ou enfin un nombre négatif en cas d'erreur.

Ainsi, si nous souhaitons récupérer deux entiers et être certains que *scanf*() les a récupéré, nous pouvons utiliser le code suivant :

```c
#include <stdio.h>


int main(void)
{
    int x;
    int y;

    printf("Entrez deux nombres : ");
    if (scanf("%d %d", &x, &y) == 2)
    {
        printf("Vous avez entre : %d et %d\n", x, y);
    }
    return 0;
}
```

```text
Entrez deux nombres : 1 2
Vous avez entre : 1 et 2

Entrez deux nombres : 1 a

Entrez deux nombres : b c
```

Comme vous pouvez le constater, le programme n'exécute pas l'affichage des nombres dans les deux derniers cas, car *scanf*() n'a pas réussi à réaliser deux conversions.