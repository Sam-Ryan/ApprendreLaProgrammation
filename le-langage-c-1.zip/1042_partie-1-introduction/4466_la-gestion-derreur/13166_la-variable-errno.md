Le retour des fonctions est un vecteur très pratique pour signaler une erreur. Cependant, il n'est pas toujours utilisable. En effet, nous avons vu au chapitre précédent différentes fonctions mathématiques. Or, ces dernières utilisent *déjà* leur retour pour transmettre le résultat d'une opération. Comment faire dès lors pour signaler un problème ?

Une première idée serait d'utiliser une valeur particulière, comme zéro par exemple. Toutefois, ce n'est pas satisfaisant puisque, par exemple, les fonctions *pow*() ou *sin*() peuvent parfaitement retourner zéro lors d'un fonctionnement normal. Que faire alors ?

Dans une telle situation, il ne reste qu'une seule solution : utiliser un autre canal, en l'occurrence une variable globale. La bibliothèque standard fourni une variable globale nomée *errno* (elle est déclarée dans l'en-tête **<errno.h\>**) qui permet à différentes fonctions d'indiquer une erreur en modifiant la valeur de celle-ci.

[[information]]
| Une valeur de zéro indique qu'aucune erreur n'est survenue.

Les fonctions mathématiques recourent abondamment à cette fonction. Prenons l'exemple suivant :

```c
#include <errno.h>
#include <stdio.h>


int main(void)
{
    double x;

    errno = 0;
    x = pow(-1, 0.5);
    if (errno == 0)
    {
        printf("x = %f\n", x);
    }
    return 0;
}
```

Le calcul demandé revient à demander le résultat de l'expression $-1^\frac{1}{2}$, autrement dit, de cette expression : $\sqrt{-1}$, ce qui est impossible dans l'essemble des réels. Aussi, la fonction *pow*() modifie la variable *errno* pour vous signifier qu'elle n'a pas pu calculer l'expression demandée.

Une petite précision concernant ce code et la variable *errno* : celle-ci doit *toujours* être mise à zéro *avant* d'appeler une fonction qui est susceptible de la modifier, ceci afin de vous assurez qu'elle ne contient pas la valeur qu'une autre fonction lui a assignée. Imaginez que vous ayez auparavant appelé *pow*() et que cette dernière à échoué, si vous l'appelez à nouveau, la valeur de *errno* sera toujours celle assignée par lors de l'appel précédent.