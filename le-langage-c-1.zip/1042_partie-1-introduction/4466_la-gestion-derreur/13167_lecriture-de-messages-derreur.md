Savoir qu'une erreur s'est produite, c'est bien, le signaler à l'utilisateur, c'est mieux. Ne laisser pas votre utilisateur dans le vide, s'il se passe quelque chose, dite le lui.

```c
#include <stdio.h>

int main(void)
{
    int x;
    int y;

    printf("Entrez deux nombres : ");
    if (scanf("%d %d", &x, &y) == 2)
    {
        printf("Vous avez entre : %d et %d\n", x, y);
    }
    else
    {
        printf("Vous devez saisir deux nombres !\n");
    }
    return 0;
}
```

```text
Entrez deux nombres : a b
Vous devez saisir deux nombres !

Entrez deux nombres : 1 2
Vous avez entre : 1 et 2
```

Simple, mais tellement plus agréable. ;)

Dans l'exemple situé plus haut, nous avons affiché les messages d'erreurs à grand coup de printf(). Nous verrons plus tard dans le tutoriel qu'il existe d'autres façons un peu plus propres d'afficher des messages d'erreurs. Nous ne pouvons pas en dire plus pour le moment, vu qu'il nous faudrait aborder les notions de flux (et notamment le flux stderr),ce qui ne peut être fait que bien plus tard dans ce cours.