Maintenant que vous savez tout cela, il vous est possible de modifier le code utilisant la fonction *scanf*() pour vérifier si celle-ci a réussi et, si ce n'est pas le cas; préciser à l'utilisateur qu'une erreur est survenue, *et* quitter la fonction *main*() en retournant la valeur EXIT_FAILURE.

```c
#include <stdio.h>


int main(void)
{
    int x;
    int y;

    printf("Entrez deux nombres : ");
    if (scanf("%d %d", &x, &y) != 2)
    {
        printf("Vous devez saisir deux nombres !\n");
        return EXIT_FAILURE;
    }
    printf("Vous avez entre : %d et %d\n", x, y);
    return 0;
}
```

Ceci nous permet même de réduire un peu la taille de notre code en éliminant directement les cas d'erreurs.