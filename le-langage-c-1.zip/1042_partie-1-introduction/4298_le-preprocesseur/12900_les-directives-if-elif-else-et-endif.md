Ces quatre directives de préprocesseur font partie de ce que l'on appelle des **directives conditionnelle**. Ces dernières permettent de conserver ou non une potion de code en fonction de la validité d'une condition (si la condition est vraie, le code est gardé sinon il est passé). Les trois premières correspondent à ```if```, ```else if``` et ```else``` ; la dernière est obligatoire et conclue toute condition.

Voici un exemple dans lequel on teste si une macro est négative, nulle ou positive.

```c
#include <stdio.h>

#define A   2

#if (A) < 0
#define B puts("A < 0")
#elif (A) > 0
#define B puts("A > 0")
#else
#define B puts("A == 0")
#endif

int main(void)
{
    B;
    return 0;
}
```

[[erreur]]
| Les conditions du préprocesseur sont différentes des conditions classiques ! En effet, elles ne peuvent comporter que des expressions *entières constantes* (ce qui exclu les opérateurs à effets de bord comme `=`). Aussi, les mots-clés et autres identificateurs (hors macro) présent dans la définition *sont ignorés* (plus précisémment, ils sont remplaçés par 0).

L'exemple ci-dessous explicite ceci.

```c
#if 1.89 > 1.88 /* Incorrect, ce ne sont pas des entiers */
#if sizeof(int) == 4 /* Équivalent à 0(0) == 4, `sizeof' et `int' étant des mots-clés */
#if (a = 20) == 20 /* Équivalent à (0 = 20) == 4, `a' étant un identificateur */
```

# L'opérateur defined

Le préprocesseur fourni un opérateur supplémentaire utilisable dans les condtions : **defined**. Celui-ci prends comme operande un nom de macro et retourne 1 ou 0 suivant que ce nom correspond ou non à une macro définie.

Celui-ci est utilisé pour produire des programmes portables. En effet, chaque système et chaque compilateur définissent une constante qui lui est propre. Nous avons donc une constante pour Windows, une pour Mac, une pour Linux, mais également des constantes pour GCC, Visual Studio, MinGW, etc. En testant si une constante existe, nous pouvons déterminer sur quelle plate-forme et avec quel compilateur nous compilons et adapter le code en conséquence. 

Il est cependant important de noter que *ces constantes ne sont pas spécifiée par la norme*. Autrement dit, elles peuvent varier selon plusieurs paramètres. Renseignez-vous bien lorsque vous voudrez les utiliser.

Voici un exemple de code qui teste si le système cible est Windows (32 ou 64 *bits*) ou bien Linux ou MacOS pour inclure un fichier d'en-tête spécifique (celui-ci étant le même pour Linux et MasOS).

```c
/* si on est sous Mac ou Linux */
#if defined __APPLE__ || defined linux
#include <unistd.h>

/* ou bien si on est sous Windows 32 bits ou 64 bits */
#elif defined __WIN32__ || defined __WIN64__
#include <windows.h>

#endif
```

[[information]]
| Notez ici l'utilisation de l'opérateur logique `||`, comme pour les conditions classiques.

# Les directives #ifdef et #ifndef

La première directive signifie « si la constante est définie », la deuxième étant son contraire, « si la constante n'est pas définie ». Elles sont en quelque sorte des "raccourcis" de ```#if defined```. En effet, si vous n'avez qu'une seule constante à tester, il est plus rapide d'utiliser ces deux directives que ```#if defined```.

Illustration :

```c
#ifdef __WIN32__  /* à la place de #if defined __WIN32__ */
#include <windows.h>
#endif

#ifdef linux  /* à la place de #elif defined linux */
#include <unistd.h>
#endif
```

## Sécurisation d'un fichier d'en-tête

L'avantage de cette technique est que l'on peut sécuriser les fichiers d'en-tête. En effet, lorsque l'on créé un tel fichier, il faut toujours faire attention aux **inclusions infinies**. Cela peut arriver quand un fichier d'en-tête A inclut un fichier d'en-tête B qui lui-même inclut A. Le préprocesseur rentre dans une sorte de boucle infinie qui fait finalement échouer la compilation. Pour éviter cela, nous vous avions présentés dans le chapitre précédent des directives à placer obligatoirement dans chaque fichier d'en-tête. Il est maintenant temps d'expliquer exactement leur fonctionnement. Nous vous remettons le code en dessous, essayez de l'expliquer sans regarder la réponse.

```c
#ifndef FICHIER_H
#define FICHIER_H

#endif
```

* ```#ifndef FICHIER_H``` : si la constante associée au fichier n'a jamais été définie, le préprocesseur rentre dans la condition et poursuit la lecture du fichier. 
* ```#define FICHIER_H``` : on définit la constante du fichier. La prochaine fois, la condition sera fausse et le reste sera passé.  
* ```#endif``` : termine la condition.

Ce code est simple, mais il permet d'éviter des problèmes. Veillez donc bien à l'utiliser chaque fois que vous créez un fichier d'en-tête.