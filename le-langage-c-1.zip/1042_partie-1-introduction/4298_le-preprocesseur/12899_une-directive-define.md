Comme nous l'avons dit dans la partie précédente, le préprocesseur permet la définition de macros, c'est à dire des substituts à des morceaux de code. Pour créer une macro, il faut trois éléments.

* ```#define``` : cette directive va nous permettre de définir une macro.
* Le **nom de la macro** : par convention, celui-ci est écrit **en majuscules**. On peut choisir le nom que l'on veut, à condition de respecter les mêmes règles que pour les noms de variable ou de fonction.
* La **définition** : c'est le code que l'on souhaite substituer.

Nous verrons qu'il est également possible de rajouter des paramètres à nos macros.

# Des macros simples

## Une définition simple

Prenons un exemple très simple : je définis une macro qui substitue l'identificateur TAILLE à la valeur 100. 

```c
/* Dans le cas d'une définition simple comme celle-ci, on parle souvent de constante
   de préprocesseur ou de macroconstante. */

#define TAILLE 100
```

Ce code signifie que chaque fois que l'on appellera TAILLE dans le code, le préprocesseur remplacera la macro (TAILLE) par sa définition (100). Voici un code illustrant le principe.

```c
#include <stdio.h>
#define TAILLE 100

int main(void)
{
    int variable = 5;

    /* On multiplie par TAILLE */
    variable *= TAILLE;
    printf("Variable vaut : %d\n", variable);

    /* On additionne TAILLE */
    variable += TAILLE;
    printf("Variable vaut : %d\n", variable);
    return 0;
}
```

Ce code sera remplacé, après le passage du préprocesseur, par celui ci-dessous.

```c
int main(void)
{
    int variable = 5;

    variable *= 100;
    printf("Variable vaut : %d\n", variable);
    variable += 100;
    printf("Variable vaut : %d\n", variable);
    return 0;
}
```

Je n'ai pas inclus le contenu de **<stdio.h\>** car celui-ci est trop long et trop compliqué pour le moment. Néanmoins, l'exemple permet d'illustrer le principe des macros et surtout leur avantage : il suffit de changer la définition de la macro pour que le reste du code s'adapte. Illustrons : on veut changer 100 par 200. Le seul problème est qu'on utilise beaucoup cette valeur, disons 50 fois dans le code. Sans macro, il faudrait changer toutes les valeurs une par une, donc faire 50 modifications. Avec une macro, il suffit de changer la définition et tout le code s'adapte ensuite.

## Macros dans d'autres macros

Il est même possible de faire mieux : utiliser une macro dans une autre macro. Imaginez que vous souhaitiez calculer le nombre de pixels d'une fenêtre. Vous avez trois macros : la largeur, la hauteur et le total. *Hé* bien, les macros LARGEUR et HAUTEUR peuvent être directement utilisées dans la définition de la macro TOTAL et ainsi permettre d'obtenir le nombre de pixels. 

```c
#define HAUTEUR 1440
#define LARGEUR 700
#define TOTAL (HAUTEUR * LARGEUR)

printf("Total = %d pixels\n", TOTAL);
```

Si j'explicite les étapes, j'obtiens les codes suivants.

```c
printf("Total = %d pixels\n", (HAUTEUR * LARGEUR));
```
```c
printf("Total = %d pixels\n", (1440 * 700));
```

Nous obtienons bien finalement le nombre total de pixels. L'avantage ? Non seulement nous évitons des modifications en cas de changement, mais également nous évitions d'écrire une expression plus longue : `HAUTEUR * LARGEUR`. Les parenthèses ne sont pas obligatoires, mais elles sont fortement recommandées et nous verrons pourquoi par la suite.

Ce qu'il faut retenir, c'est qu'il est possible d'utiliser des macros dans la définition d'autres macros et que celle-ci (la définition) peut comprendre n'importe quel bout de code valide.

Allez, exercice ! Faites-moi une macro qui additionne le résultat de deux autres macros. La première macro multiplie un nombre choisi (disons 100) par trois et la deuxième le divise par deux.

[[secret]]
|```c
|#define MACRO1  (100 * 3)
|#define MACRO2  (100 / 2)
|#define MACRO3  (MACRO1 + MACRO2)
|```

## D'autres définitions

Jusqu'à maintenant, nous nous sommes contentés de macros qui n'ont pour définition que des valeurs numériques. Fort heureusement, il est possible d'avoir d'autres définitions. Nous venons de voir qu'il était possible qu'une définition soit composée d'une ou plusieurs macros, mais ce n'est pas tout. Elle peut également être composée de caractères voire même de fonctions, de boucles et de conditions. Illustrons cela.

```c
#define BONJOUR  puts("Bonjour !")
```

La macro BONJOUR est définie comme étant un substitut du code ```puts("Bonjour !")```. Vous noterez qu'il n'y a pas de point-virgule à la fin de la définition. Il s'agit d'une convention, afin de pouvoir appeler la macro comme n'importe quelle fonction.

```c
#include <stdio.h>

#define BONJOUR  puts("Bonjour !")

int main(void)
{
    BONJOUR;
    return 0;
}
```

En effet, si nous ajoutons un point virgule à la fin de la définition, il est nécessaire de ne pas l'ajouter lors de l'appel sans quoi nous risquons des erreurs de syntaxe, comme ici :

```c
#include <stdio.h>

#define BONJOUR puts("Bonjour !");
#define AUREVOIR puts("Au revoir !");

int main(void)
{
    if (1)
        BONJOUR; /* erreur ! */
    else
        AUREVOIR;

    return 0;
}
```

Le code donnant en réalité ceci :

```c
int main(void)
{
    if (1)
        puts("Bonjour !");;
    else
        puts("Au revoir !");;

    return 0;
}
```

Qui est incorrect. Pour faire simple : le corps d'une condition ne peut comprendre qu'une instruction, or `puts("Bonjour !");` en est une, le point-virgule seul en est une autre. Dès lors, il y a une instruction entre le `if` et le `else`, ce qui n'est pas permis. L'exemple ci-dessous pose le même problème en étant un peu plus limpide.

```c
#include <stdio.h>


int main(void)
{
    if (1)
        puts("Bonjour !");

    puts("Je suis une instruction mal placee !");

    else
        puts("Au revoir !");

    return 0;
}
```

# Avec paramètre(s)

Pour l'instant, nous n'avons manipuler que des macro contenant des constantes. Cependant, il serait bien de pouvoir faire comme pour les fonctions, c'est à dire transmettre des paramètres à la macro. C'est possible et c'est même la principale utilisation des macros. Pour déclarer une macro avec des paramètres, c'est très simple : ajoutez des parenthèses, comme pour les fonctions, en séparant les paramètres par des virgules.

```c
/* Une macrofonction */

#define MACRO(paramètres) définition
```

Illustrons ce nouveau concept avec un exemple ludique : nous allons écrire deux macros : RAD qui convertira un angle en radian et DGR qui fera l'inverse. Pour ceux qui ne connaissent pas, un radian vaut approximativement 57.29 degrés. Pour passer de l'un à l'autre, nous utilisons ces deux formules :

* Conversion de $x$ degrés en radians : $\frac{\pi \times x}{180}$
* Conversion de $x$ radians en degrés : $\frac{180 \times x}{\pi}$

Voici un exemple d'exécution de ce code.

```console
Donnez un angle en degrés :
57.29
57.290 degrés = 1.000 radians

Donnez un angle en radians :
3.1415
3.142 radians = 180.024 degrés
```

[[secret]]
|```c
|#define RAD(x) (3.1415 * (x) / 180)
|#define DGR(x) (180 * (x) / 3.1415)
|```

Appliquons encore ce concept avec un deuxième exercice : créons la macro MIN qui renvoie le minimum entre deux nombres.

[[secret]]
|```c
|#include <stdio.h>
|
|#define MIN(a, b)  ((a) < (b) ? (a) : (b))
|
|int main(void)
|{
|    printf("Le minimum entre 2+9+7 et 3*8 est %d\n", MIN(2+9+7, 3*8));
|    return 0;
|}
|```

## Les inconvénients

Quelque chose vous a peut-être frappé dans les corrections : pourquoi écrire ```(x)``` et pas simplement ```x``` ? 

En fait, il s'agit d'une protection en vue d'éviter certaines ambigüités. En effet, si l'on n’y prend pas garde, on peut par exemple avoir des surprises dues à la priorité des opérateurs. Prenons l'exemple d'une macro MUL.

```c
#define MUL(a, b)  (a * b)
```

Tel quel, le code peut poser des problèmes. En effet, si nous appellons la macro comme ceci :

```c
MUL(2+3, 4+5)
```

J'obtiens comme résultat 19 (la macro sera remplacée par ```2 + 3 * 4 + 5```) et non 45, le résultat attendu. Pour garantir la bonne marche de la macro, je dois rajouter des parenthèses.

```c
#define MUL(a, b)  ((a) * (b))
```

Dans ce cas, nous obtenons bien le résultat souhaité, c'est-à-dire 45 (```(2 + 3) * (4 + 5)```). Nous vous conseillons de rajouter des parenthèses en cas de doute pour éviter toute erreur.

Pour finir, une petite mise en garde : évitez d'utiliser plus d'une fois un paramètre dans la définition d'une macro en vue d'éviter de multiplier d'éventuels **effets de bord**.

[[question]]
| Des effets de quoi ?

Un effet de bord est une modification du contexte d'exécution. Vous voilà bien avancé nous direz-vous... En fait, vous en avez déjà rencontré, l'exemple le plus typique étant une affectation.

```c
a = 10;
```

Dans cet exemple, le contexte d'exécution du programme (qui comprends ses variables) est modifié puisque la valeur d'une variable est changée. Ainsi, imaginez que la macro MUL soit appelée comme suit :

```c
MUL(a = 10, a = 20)
```

ce qui donne : `((a = 10) * (a = 20))`. Quelle sera la valeur de *a* à la fin ? C'est impossible à dire sans fixer une règle d'évaluation et la norme n'en prévoi aucune dans ce cas ci. Aussi, pour éviter ce genre de problèmes tordus, essayez de n'utiliser les paramètres qu'une seule fois.

# Sur plusieurs lignes

Si jamais notre macro est un peu longue, plutôt que de la définir sur une seule ligne, il est possible de le faire sur plusieurs. On utilise pour cela le symbole ```\``` chaque fois que l'on veut aller à la ligne.

```c
#define MACRO  puts("Hello world!"); \
    putchar('a'); \
    printf("%d", 2 + 3)

int main(void)
{
   MACRO;
   return 0;
}
```

Après le passage du préprocesseur, le fichier source ressemblera à celui ci-dessous.

```c
int main(void)
{ 
    puts("Hello world!");
    putchar('a');
    printf("%d", 2 + 3);
    return 0;
}
```

Cependant, les macros sur plusieurs lignes présentent le même problème que précédemment : étant composées de plusieurs instructions, elles sont susceptibles de produire des erreurs de syntaxe.

```c
#include <stdio.h>

#define ECHANGE(a, b, tmp)\
    (tmp) = (a);\
    (a) = (b);\
    (b) = (tmp);

int
main(void)
{
    int a[3]= { 1, 2, 3 };
    int b[3]= { 2, 4, 6 };
    int tmp;
    int i;

    for (i = 0; i < 3; ++i)
        ECHANGE(a[i], b[i], tmp);
    for (i = 0; i < 3; ++i)
        printf("%d %d\n", a[i], b[i]);

    return 0;
}
```

Contrairement à ce qui est souhaité, seule la première instruction de la macro fera partie du corps de la boucle, les trois autres seront situés en dehors de celui-ci. En effet, le remplacement produira en vérité le code suivant (notez l'instruction vide à la fin qui résulte de l'ajout d'un point-virgule à la fin de l'appel à la macro ECHANGE) :

```c
for (itr=0; itr<3; ++itr)
    (tmp) = (a);
(a) = (b);
(b) = (tmp);
;
```

Une solution simple à ce problème consiste à utiliser une boucle ```do { } while```. De cette manière, le corps de la macro ne constitue plus qu'une seule instruction *avec le point-virgule suivant l'appel à la macro*, celui-ci étant nécessaire pour terminer une instruction ```do {} while``` (ce qui, comme auparavant, permet d'appeler une macro de la même manière qu'une fonction)

```c
#include <stdio.h>

#define SWAP(a, b, tmp)\
do {\
    (tmp) = (a);\
    (a) = (b);\
    (b) = (tmp);\
} while (0)

int
main(void)
{
    int a[3]= { 1, 2, 3 };
    int b[3]= { 2, 4, 6 };
    int tmp;
    int i;

    for (i = 0; i < 3; ++i)
        ECHANGE(a[i], b[i], tmp);
    for (i = 0; i < 3; ++i)
        printf("%d %d\n", a[i], b[i]);

    return 0;
}
```

# Des macros sans définition

Comme l'indique le titre, le corps d'une macro peut parfaitement être vide. Exemple :

```c
#define MACRO
```

Bien que cela paraisse étrange, cette technique est souvent utilisée. Nous allons voir comment dans la partie suivante.