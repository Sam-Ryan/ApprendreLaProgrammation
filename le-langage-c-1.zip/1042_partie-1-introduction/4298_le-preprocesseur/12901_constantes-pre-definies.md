La norme prévoit que quatre constantes de préprocesseur sont prédéfinies (cf norme C89 - 3.8.8 Predefined macro names). Ces quatre macros sont ```__LINE__``` (le numéro de la ligne actuelle), ```__FILE__``` (le nom de fichier courant), ```__DATE__``` (la date de compilation du fichier, sous la forme Mois / Jour / Année) et ```__TIME__``` (l'heure de la compilation, sous la forme hh:mm:ss). La première est une constante entière, les trois autres sont des chaines de caractères.

Je vous invite à tester le code ci-dessous chez vous.

```c
#include <stdio.h>

int main(void)
{
    puts(__FILE__);
    puts(__DATE__);
    puts(__TIME__);
    printf("%d\n", __LINE__);

    return 0;
}
```

# Détecter le compilateur et le système

Pour conclure ce chapitre, voici une liste de quelques constantes courantes. Bien entendu, cette liste n'est pas exhaustive, mais elle contient la plupart des constantes servant à définir le système d'exploitation et / ou le compilateur. Toutefois, gardez-bien ceci à l'esprit : ces constantes ne sont pas standards et peuvent donc varier.

## Systèmes d'exploitation

* **Windows** : ```_WIN32``` (32 bits) ou ```_WIN64``` (64 bits)
* **GNU/Linux** : ```Linux``` ou ```__linux__```
* **Apple** : ```__APPLE__``` ou ```__MACH__```
* **FreeBSD** : ```__FreeBSD__```
* **NetBSD** : ```__NetBSD__```
* **Solaris** : ```sun``` ou ```__SVR4```

Une liste plus complète des systèmes d'exploitation est disponible [ici](http://sourceforge.net/p/predef/wiki/OperatingSystems/).

## Compilateurs

* **Visual C++** : ```_MSC_VER```
* **GCC** : versions : ```__GNUC__```, ```__GNUC_MINOR__``` ou ```__GNUC_PATCHLEVEL__```
* **Borland** : ```__TURBOC__``` ou ```__BORLANDC__```
* **MinGW** : ```__MINGW32__```
* **Cygwin** : ```__CYGWIN__``` ou ```__CYGWIN32__```

Une liste plus compète des compilateurs est disponible [ici](http://sourceforge.net/p/predef/wiki/Compilers/).

Il existe encore beaucoup d'autres constantes prédéfinies, comme pour connaitre la version du compilateur ou le nom de la fonction courante par exemple. Néanmoins, nous ne vous les présentons pas ici, ces dernières étant très nombreuses et fort spécifiques.