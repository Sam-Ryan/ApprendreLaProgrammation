Nous avons vu dès le début du cours comment inclure des fichiers d'en-tête avec la directive ```#include```, mais sans jamais expliquer ce qu'elle faisait. Son but est très simple : inclure le contenu d'un fichier dans un autre. Ainsi, si jamais l'on se retrouve avec deux fichiers comme ceux-ci avant la compilation :

```c
/* Fichier d'en-tête fichier.h */

#ifndef FICHIER_H
#define FICHIER_H

extern int glob_var;

extern void Func1(int);
extern long Func2(double, char);

#endif
```
```c
/* Fichier source fichier.c */

#include "fichier.h"

void Func1(int arg)
{
    /* du code */
}

long Func2(double arg, char c)
{
    /* du code */
}
```

On ne se retrouve qu'avec un seul fichier à l'arrivée :

```c
/* Fichier source fichier.c */

extern int glob_var;

extern void Func1(int arg);
extern long Func2(double arg, char c);

void Func1(int arg)
{
    /* du code */
}

long Func2(double arg, char c)
{
    /* du code */
}
```

On peut voir que le contenu de **fichier.h** (une variable globale et deux prototypes) a été inclus dans **fichier.c** et toutes les directives de préprocesseur ont disparu. C'est ce qui se passe chaque fois que l'on inclut un fichier d'en-tête. 

[[information]]
| Vous pouvez utiliser l'option `-E` lors de la compilation pour requérir uniquement l'utilisation du préprocesseur. Ainsi, vous pouvez voir ce que donne votre code *après* son passage.