Le préprocesseur est un programme qui réalise des traitements sur le code source *avant* que ce dernier ne soit réellement compilé. Il a trois grands rôles :

* réaliser des **inclusions** ;
* définir des **macros** qui sont des substituts à des morceaux de code. Après le passage du préprocesseur, tous les appels à ces macros seront remplacés par le code associé ;
* permettre la **compilation conditionnelle**, c'est-à-dire de moduler le contenu d'un fichier source suivant certaines conditions.

# Exemple d'utilisation avec les inclusions

Nous avons vu dès le début du cours comment inclure des fichiers d'en-tête avec la directive ```#include```, mais sans jamais expliquer ce qu'elle faisait. Son but est très simple : inclure le contenu d'un fichier dans un autre. Ainsi, si jamais l'on se retrouve avec deux fichiers comme ceux-ci avant la compilation :

```c
/* Fichier d'en-tête fichier.h */

#ifndef FICHIER_H
#define FICHIER_H

extern int glob_var;

extern void Func1(int);
extern long Func2(double, char);

#endif
```
```c
/* Fichier source fichier.c */

#include "fichier.h"

void Func1(int arg)
{
    /* du code */
}

long Func2(double arg, char c)
{
    /* du code */
}
```

On ne se retrouve qu'avec un seul fichier à l'arrivée :

```c
/* Fichier source fichier.c */

extern int glob_var;

extern void Func1(int arg);
extern long Func2(double arg, char c);

void Func1(int arg)
{
    /* du code */
}

long Func2(double arg, char c)
{
    /* du code */
}
```

On peut voir que le contenu de **fichier.h** (une variable globale et deux prototypes) a été inclus dans **fichier.c** et toutes les directives de préprocesseur ont disparu. C'est ce qui se passe chaque fois que l'on inclut un fichier d'en-tête. 

D'ailleurs, si vous utilisez *gcc*, vous pouvez compiler avec l'option *-E* pour voir le code source **après** le passage du préprocesseur. Pour ceux qui utilisent Code::Blocks comme IDE, il est possible de faire pareil : allez dans *Project -> Build Options -> Other Options* et ajouter *-save-temps -masm=intel*. Cette option sauvegardera tous les fichiers générés par la compilation. Le code après le passage du préprocesseur est contenu dans les fichiers **.i**.

Mais comme nous l'avons dit, le préprocesseur ne se limite pas à des inclusions. Examinons sans plus tarder ses possibilités.