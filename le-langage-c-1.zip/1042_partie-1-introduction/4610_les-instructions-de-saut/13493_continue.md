Le deuxième mot-clef est ```continue```. Son rôle est d'arrêter l'itération en cours et de passer à la suivante. En gros, on peut dire que ```continue``` permet de terminer le tour de boucle en cours, et fait reprendre immédiatement au tour de boucle suivant. Prenons le même code algorithme que précédemment : 

```console
Pour (i = 0 ; i < 10 ; i++)
{
     Si i == 5
        continue;

     Sinon afficher i;
}
```

Qui est capable me dire ce que le code une fois traduit en C affichera ? 

[secret]{
```console
i = 0
i = 1
i = 2
i = 3
i = 4
i = 6
i = 7
i = 8
i = 9
```
}

On remarque que quand *i* a été mis à 5, la condition ```if (i == 5)``` est devenue vraie et ```continue``` a zappé l'itération en cours.