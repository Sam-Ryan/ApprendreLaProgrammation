Nous avons déjà étudié le rôle de ```break``` au sein de l'instruction ```switch``` : il permettait simplement de quitter notre ```switch``` pour reprendre immédiatement après. Eh bien, sachez qu'on peut aussi l'utiliser avec des boucles. Son but ? Permettre de quitter une boucle (ou un ```switch```, comme on l'a déjà vu), pour reprendre immédiatement après. 

# Boucle ou structure de contrôle simple

Pour illustrer ça, prenons un algorithme tout simple :

```console
Pour (i = 0 ; i < 10 ; i++)
{
     Si i == 5
        Quitter la boucle;

     Sinon afficher i;
}
```

Notre but est de quitter si jamais la variable *i* atteint la valeur 5. Alors pour vous entrainer, essayez de coder vous-même la boucle sans regarder la solution.

[secret]{
```c
int i;

for (i = 0 ; i < 10 ; i++)
{
    if (i == 5)
        break;

    printf("i = %d\n", i);
}
```

Et voici le résultat à l'exécution :

```console
i = 0
i = 1
i = 2
i = 3
i = 4
```

L'exécution de la boucle a bien été arrêtée par ```break```. 
}

# Structures de contrôle imbriquées

Il est important de préciser que ```break``` ne permet de sortir que d'une seule boucle (ou d'une seule structure de contrôle de type ```if```, ```else if```, etc.). Ainsi, dans le cas de boucles imbriquées, on reviendra à la précédente.

```c
#include <stdio.h>

int main(void)
{
    int i;

    for (i = 0; i < 10; i++)
    {
        printf("[for] i = %d\n", i);

        while (i < 5)
        {
            if (i == 4)
                break;

            printf("[while] i = %d\n", i);
            i++;
        }
    }

    return 0;
}
```
```console
[for] i = 0
[while] i = 0
[while] i = 1
[while] i = 2
[while] i = 3
[for] i = 5
[for] i = 6
[for] i = 7
[for] i = 8
[for] i = 9
```

Dans ce code, il y a une boucle ```for``` qui contient une boucle ```while```. Au départ, *i* vaut 0, et ainsi la condition est vraie et on rentre dans la boucle. On affiche la variable, et dès que *i* vaut 4, on quitte la boucle. Comme la condition du ```while``` est fausse, on ne rentre plus dedans, mais la boucle ```for``` continue de s'exécuter, et affiche les cinq valeurs suivantes de *i*.