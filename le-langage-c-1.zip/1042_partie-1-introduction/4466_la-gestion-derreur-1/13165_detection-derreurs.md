La première chose à faire pour gérer d'éventuelles erreurs lors de l'exécution, c'est avant tout de les détecter. Par exemple, quand vous executez une fonction, et qu'une erreur a lieu lors de son exécution, celle-ci doit vous prévenir d'une manière ou d'une autre. Et elle peut le faire de deux manières différentes.

# Valeurs de retour

Nous l'avons vu au chapitre précédent : certaines fonctions, comme *scanf*(), retournent un nombre (souvent un entier) alors qu'elles ne calculent pas un résultat comme la fonction *pow*() par exemple. Vous savez dans le cas de *scanf*() que cette valeur représente le nombre de conversions réussies, cependant cela va plus loin que cela : cette valeur vous signifie si l'exécution de la fonction s'est bien déroulée. 

## Scanf

En fait, la fonction *scanf*() retourne le nombre de conversions réussies ou un nombre inférieur si elles n'ont pas toutes été réalisée *ou* enfin un nombre négatif en cas d'erreur.

Ainsi, si nous souhaitons récupérer deux entiers et être certains que *scanf*() les a récupéré, nous pouvons utiliser le code suivant :

```c
#include <stdio.h>


int main(void)
{
    int x;
    int y;

    printf("Entrez deux nombres : ");

    if (scanf("%d %d", &x, &y) == 2)
        printf("Vous avez entre : %d et %d\n", x, y);

    return 0;
}
```

```text
Entrez deux nombres : 1 2
Vous avez entre : 1 et 2

Entrez deux nombres : 1 a
```

Comme vous pouvez le constater, le programme n'exécute pas l'affichage des nombres dans les deux derniers cas, car *scanf*() n'a pas réussi à réaliser deux conversions.

## Main

Maintenant que vous savez cela, regarder bien votre fonction *main*() :

```c
int main(void)
{
    return 0;
}
```

Vous ne voyez rien qui vous interpelle ? :)

Oui, vous avez bien vu, elle retourne un entier qui, comme pour *scanf*(), sert à indiquer la présence d'erreur. En fait, il y a deux valeurs possibles : 

- EXIT_SUCCESS (ou zéro, cela revient au même), qui indique que tout s'est bien passé ; et
- EXIT_FAILURE, qui indique un échec du programme.

Ces deux constantes sont définies dans l'en-tête **<stdlib.h\>**).

## Les autres fonctions

Sachez que *scanf*(), *printf*() et *main*() ne sont pas les seules fonctions qui retournent des entiers, en fait quasiment toutes les fonctions de la bibliothèque standard le font.

[[question]]
| Ok, mais je fais comment pour savoir ce que retourne une fonction ?

À l'aide de la documentation. Vous disposez de [la norme](http://flash-gordon.me.uk/ansi.c.txt) (enfin, du brouillon de celle-ci) qui reste la référence ultime, sinon vous pouvez également utiliser un moteur de recherche avec la requête `man nom_de_fonction` afin d'obtenir les informations dont vous avez besoin.

[[information]]
| Si vous êtes anglophobe, une traduction française de diverses descriptions est disponible à [cette adresse](http://perkamon.traduc.org/), vous les trouverez à la section trois.

# Variable globale errno

Le retour des fonctions est un vecteur très pratique pour signaler une erreur. Cependant, il n'est pas toujours utilisable. En effet, nous avons vu au chapitre précédent différentes fonctions mathématiques. Or, ces dernières utilisent *déjà* leur retour pour transmettre le résultat d'une opération. Comment faire dès lors pour signaler un problème ?

Une première idée serait d'utiliser une valeur particulière, comme zéro par exemple. Toutefois, ce n'est pas satisfaisant puisque, par exemple, les fonctions *pow*() ou *sin*() peuvent parfaitement retourner zéro lors d'un fonctionnement normal. Que faire alors ?

Dans une telle situation, il ne reste qu'une seule solution : utiliser un autre canal, en l'occurrence une variable globale. La bibliothèque standard fourni une variable globale nomée *errno* (elle est déclarée dans l'en-tête **<errno.h\>**) qui permet à différentes fonctions d'indiquer une erreur en modifiant la valeur de celle-ci.

[[information]]
| Une valeur de zéro indique qu'aucune erreur n'est survenue.

Les fonctions mathématiques recourent abondamment à cette fonction. Prenons l'exemple suivant :

```c
#include <errno.h>
#include <stdio.h>


int main(void)
{
    double x;

    errno = 0;
    x = pow(-1, 0.5);

    if (errno == 0)
        printf("x = %f\n", x);

    return 0;
}
```

Le calcul demandé revient à demander le résultat de l'expression $-1^\frac{1}{2}$, autrement dit, de cette expression : $\sqrt{-1}$, ce qui est impossible dans l'essemble des réels. Aussi, la fonction *pow*() modifie la variable *errno* pour vous signifier qu'elle n'a pas pu calculer l'expression demandée.

Une petite précision concernant ce code et la variable *errno* : celle-ci doit *toujours* être mise à zéro *avant* d'appeler une fonction qui est susceptible de la modifier, ceci afin de vous assurez qu'elle ne contient pas la valeur qu'une autre fonction lui a assignée. Imaginez que vous ayez auparavant appelé *pow*() et que cette dernière a échoué, si vous l'appelez à nouveau, la valeur de *errno* sera toujours celle assignée par lors de l'appel précédent.

[[information]]
| Notez que la bibliothèque standard ne prévoit en fait que deux valeurs d'erreur possibles pour *errno* : EDOM (pour le cas où le résultat d'une fonction mathématique est impossible) et ERANGE (en cas de dépassement de capacité, nous y reviendrons plus tard). Ces deux constantes sont définies dans l'en-tête **<errno.h\>**.